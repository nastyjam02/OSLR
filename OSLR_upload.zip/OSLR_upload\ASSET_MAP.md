# 论文证据与资产映射

本文档将论文中的每项可验证主张关联到代码、固定输入、已归档结果和必要的外部权重。所有包内路径均相对于本目录。

## 通用资产

- OSLR 实现：`src/sar2opt_onestep/{train.py,infer.py,evaluate.py,focal_frequency_loss.py}`。
- 多步 latent diffusion / LCD / 求解器：`src/sar2opt_latent/{train.py,inference.py,evaluate.py,scheduler_utils.py,model_ldm.py}`。
- 统一的 SSIM、PSNR、LPIPS、FID 指标：`src/sar2opt_latent/evaluate.py`；已有基线预测目录可使用 `src/baselines/eval_folder_metrics.py`。
- MI 与 Chamfer：`src/archive/evaluate_sar_opt_metrics.py`。
- SEN12 完整配对索引：`assets/manifests/sen12_pair_index_relative.json`；QXS 固定 4,000 张清单：`assets/manifests/qxs_valtest4000_seed42_relative.json`。

## 表 I：SEN12 主比较

- OSLR（full）的审计结果：`assets/results/oslr_full_sen12.json`，对应外部权重 `sar2opt_onestep_b0_lpips_ffl/model_step_30000_final.pth`。
- 50 步扩散与表 II/III 共用 `sar2opt_ldm_mse_e1/model_step_50000_final.pth`；其 50 步 DDIM 审计结果：`assets/results/ldm_ddim50_sen12.json`。
- VAE oracle：`assets/results/vae_oracle_sen12.json`。
- 文献转引的 NiceGAN、CycleGAN、CRAN、S2ODPM、S2ODPM-ACD 不在本包中重训；正文必须明确它们不是同一实现和硬件环境下的直接排序。

## 表 II、III：NFE / 求解器 / LCD

- 少步调度器实现与名称规则：`src/sar2opt_latent/scheduler_utils.py`。
- 扩散评测入口：`src/sar2opt_latent/evaluate.py`；使用同一 50k LDM 权重改变 `--scheduler` 和 `--num-inference-steps`。
- LCD 训练、权重和评测均使用相同入口，通过 checkpoint 元数据确定模型类型；发布时须在 `DATA_AND_WEIGHTS.md` 补上 `sar2opt_consistency_c1/model_step_50000_final.pth` 的下载地址与 SHA256。
- 论文表格中的每个 NFE 工作点应在发布时把其 `metrics.json` 和 `timing.json` 放入 `assets/results/solver_sweep/`。当前服务器上的全量扫描结果不应整体打包；只纳入论文最终选用的工作点。

## 表 IV：训练目标消融

- L1：`assets/results/oslr_l1_sen12.json`，外部权重 `sar2opt_onestep_b0_30k_l1/model_step_30000_final.pth`。
- 完整 L1 + FFL + LPIPS：`assets/results/oslr_full_sen12.json`，训练入口 `src/sar2opt_onestep/launch_train_b0_lpips_ffl.sh`。
- FFL-only 与 LPIPS-only 使用相同目录下的 `launch_train_b0_ffl_only.sh`、`launch_train_b0_lpips_only.sh`。它们的最终审计 JSON 应在对外发布前从服务器选定工作点复制到 `assets/results/ablations/`。

## 表 V、VI：跨数据集与数据属性

- SEN12 / QXS 的 MI 与 Chamfer 汇总：`assets/statistics/{sen12_test3k_mi_summary.json,qxs_valtest4k_mi_summary.json,registration_noise_compare.json}`。
- 可用于重算分位数、长尾或类别统计的逐样本证据：`assets/statistics/{sen12_test3k_mi.csv,qxs_valtest4k_mi.csv}`。
- QXS 5k OSLR：`assets/results/oslr_l1_qxs_5k.json`，外部权重 `sar2opt_onestep_b0_qxs/model_step_5000.pth`。
- QXS 50 步 DDIM：`assets/results/ldm_ddim50_qxs.json`，外部权重 `sar2opt_ldm_qxs_origin/model_step_50000_final.pth`。
- QXS VAE oracle：`assets/results/vae_oracle_qxs.json`。

## 图与定性样例

论文 Markdown 仅引用了外部图片路径，当前服务器目录中没有可随包复制的 `grsl_experiments_draft.assets/`。对外发布前应把图 1–4 的最终 PNG/PDF、生成脚本、每个拼图的样本 ID 和对应的 SAR/GT/预测文件名放入 `assets/figures/`；未完成前不要宣称本包可重建论文图。
