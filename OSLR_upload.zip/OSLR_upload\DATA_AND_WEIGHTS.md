# 数据、权重与校验清单

本包不分发原始遥感数据、Stable Diffusion 权重、FID Inception 权重或论文训练检查点。下列条目给出官方/受控获取渠道与完整性校验值；不要发布服务器绝对路径、访问令牌或云盘临时链接。

## 数据集

- **SEN1-2（论文中的 SEN12 来源）**
  - 官方页面：<https://mediatum.ub.tum.de/1436631>（TUM mediaTUM，CC-BY 4.0）
  - 命令行下载（网页下载不稳定，推荐 rsync，密码 `m1436631`）：
    ```bash
    rsync -av rsync://m1436631@dataserv.ub.tum.de/m1436631/ /your/local/path
    ```
  - 获得后整理为 `SEN12_ROOT/{train,test}/{agri,barrenland,grassland,urban}/{s1,s2}/`。论文使用 13,000 训练对和 3,000 测试对；实际文件身份见 `assets/manifests/sen12_pair_index_relative.json`。
- **QXS-SAROPT**
  - 官方仓库：<https://github.com/yaoxu008/QXS-SAROPT>（CC-BY；下载链接需先填写问卷 <https://www.wenjuan.com/s/UZBZJv5GwL/> 获取）
  - 获得后整理为 `QXS_ROOT/splits/{train,valtest}/qxs/{s1,s2}/`。完整 QXS 评测使用 `QXS_ROOT/splits/valtest` 的固定 4,000 对；样本选择见 `assets/manifests/qxs_valtest4000_seed42_relative.json`。
- 对数据进行任何 resize、重编码、筛除或重配准前，必须记录命令、输入版本、输出 SHA256 和样本数量。论文协议是将图像 resize 至 256×256。

## 外部基础权重

- **SD2.1 VAE / UNet**：HuggingFace [`stabilityai/stable-diffusion-2-1-base`](https://huggingface.co/stabilityai/stable-diffusion-2-1-base)（CreativeML OpenRAIL-M 许可）。下载后通过 `VAE_MODEL_DIR=<本地模型目录>` 传入，目录须含 `vae/`、`unet/`、`text_encoder/`、`tokenizer/` 子目录。训练和评测均须使用同一冻结 SD2.1 自编码器；该目录不可只靠模型名隐式联网下载。
- **FID Inception v3**：torch-fidelity 官方发布文件
  - URL：<https://github.com/toshas/torch-fidelity/releases/download/v0.2.0/weights-inception-2015-12-05-6726825d.pth>
  - 本地副本 SHA256（与文件名内嵌前缀一致）：`6726825d0af5f729cebd5821db510b11b1cfad8faad88a03f1befd49fb9129b2`
  - 所有报告 FID 的运行必须通过 `FID_WEIGHTS=<本地 .pth 文件>` 明确传入同一文件。
- **LPIPS**：运行时使用 AlexNet 评测网络；OSLR 训练脚本使用 VGG。对应 `lpips` 包版本锁定见 `environment/requirements-nasty-home.txt`（lpips==0.1.4，首次运行自动下载骨干权重）。

## 论文检查点登记

以下条目是对外发布所需的最小集合。SHA256 已从服务器原始文件计算（`sha256sum`，2026-08-11）；URL 待权重上传后统一替换 `PENDING_UPLOAD`，所有哈希必须对应最终对外可下载的字节内容（若上传前重新序列化或转存格式，必须重算哈希并更新本表）。

```text
id: oslr_full_sen12
relative_server_source: checkpoints/sar2opt_onestep_b0_lpips_ffl/model_step_30000_final.pth
purpose: 表 I、II、IV、VI 的 OSLR full
SHA256: b8138b3e52b8ade7db8b10bfffc56859d73ea93eb7a020a5ab64554cfa5ab93e
URL: PENDING_UPLOAD

id: oslr_l1_sen12
relative_server_source: checkpoints/sar2opt_onestep_b0_30k_l1/model_step_30000_final.pth
purpose: 表 IV L1 only
SHA256: 56b3794c93dc0dcdaaca70f5d2f046044fdc799b9c09ca1ad0f6c58e1321dd73
URL: PENDING_UPLOAD

id: ldm_sen12
relative_server_source: checkpoints/sar2opt_ldm_mse_e1/model_step_50000_final.pth
purpose: 表 II、III 的 DDIM/DPM-Solver++ 多步基线
SHA256: 05769122e8b9b4b42db568734d79bfb43e3862f312d97dc39ec61bbb9b048295
URL: PENDING_UPLOAD

id: lcd_sen12
relative_server_source: checkpoints/sar2opt_consistency_c1/model_step_50000_final.pth
purpose: 表 II 的 LCD 工作点
SHA256: 6347ce06698026d0191d51ca3983a7a8782598296673669eadb7e351a25594f0
URL: PENDING_UPLOAD

id: oslr_l1_qxs_5k
relative_server_source: checkpoints/sar2opt_onestep_b0_qxs/model_step_5000.pth
purpose: 表 V QXS OSLR (L1 only)
SHA256: 05c3f8c4856fbaf87f910d99f85fb589adc797e41019d06e17f0c2d993d65eaf
URL: PENDING_UPLOAD

id: ldm_qxs
relative_server_source: checkpoints/sar2opt_ldm_qxs_origin/model_step_50000_final.pth
purpose: 表 V QXS 50-step DDIM
SHA256: c004ff5ff9628b56ccbd428e78a17cbba3c28eb1b032c09bcc5caab2eb089ca7
URL: PENDING_UPLOAD
```

上传完成后，对对外文件重新执行：

```bash
sha256sum model_step_*.pth
```

并把输出逐行与本表核对。下载方执行 `sha256sum -c` 前，应把每行组织为 `<hash>  <filename>`。
