# OSLR：面向 SAR 到光学翻译的一步潜空间回归

OSLR 用**一次网络前向**把 SAR 图像翻译成光学图像。它在冻结的 [Stable Diffusion 2.1](https://huggingface.co/stabilityai/stable-diffusion-2-1-base) 自编码器潜空间里，学习从 SAR 潜变量到光学潜变量的确定性映射。推理时没有噪声输入、没有时间步、也没有迭代采样。

配对的 SAR–光学评测用一张参考图给每张预测打分，采样多样性没有收益。OSLR 因此去掉条件分布采样，直接回归这张参考。在 SAR 与光学信息充足、空间也对齐的数据上，它在 SSIM、PSNR、LPIPS 上比多步扩散更贴近参考，推理代价也低得多。FID 上的小幅差距是感知–失真权衡，不是配对指标失效。

> 论文：*Rethinking Sampling for SAR-to-Optical Translation: When One-Step Regression Suffices*  
> 代码：<https://github.com/nastyjam02/OSLR>  
> 作者：陈瑞、刘鹏（复旦大学）

定性对比（SAR、8 步 DPM-Solver++、OSLR、光学真值）见论文图 3。发布前把 PNG 放到 `assets/figures/teaser.png`，再取消下面一行的注释。

<!-- ![SEN12 定性对比](assets/figures/teaser.png) -->

## SEN12 上的结果

下表是 SEN12 测试集（3,000 对）。推理时间是单张 NVIDIA A800-SXM4-80GB、batch size 32、预热 20 次、CUDA 同步后的摊销毫秒/张。计时包含 SAR 编码、UNet 前向和 VAE 解码，不含磁盘 I/O。其他 GPU 或 batch size 测得的 `ms/img` 不要和本表比较。

| 方法 | 类型 | NFE | SSIM ↑ | PSNR ↑ | LPIPS ↓ | FID ↓ | ms/img |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| LDM (DPM-Solver++) | 扩散 | 8 | 0.3599 | 18.43 | 0.3226 | **35.47** | 60.7 |
| **OSLR (full)** | 回归 | **1** | **0.4724** | **20.31** | **0.2612** | 37.69 | **21.4** |

相对 8 步扩散参考，SSIM 提高 0.113，PSNR 提高 1.88 dB，LPIPS 下降 0.061。吞吐约 2.8 倍，FID 升高 2.2。

OSLR (full) 的损失是潜空间 \(\ell_1\) + 焦点频率损失（FFL）+ LPIPS。论文里的 NiceGAN、CycleGAN、CRAN、S2ODPM、S2ODPM-ACD 转引自已有 SEN12 报告，本仓库没有重训，也不与上表两行混排。

这两行的审计 JSON：`assets/results/oslr_full_sen12.json`、`assets/results/ldm_ddim50_sen12.json`。每张表对应的命令、检查点和结果文件见 [ASSET_MAP.md](ASSET_MAP.md)。

## 什么时候值得试一步回归

训练之前，只用配对图像算出两个统计量，用来判断确定性回归是否值得作为第一次尝试：

| 数据集 | 像素互信息 ↑（nat） | Chamfer ↓（px） | 结果 |
| --- | ---: | ---: | --- |
| SEN12 | 0.133 | 1.88 | OSLR 的 SSIM、PSNR、LPIPS 更好，FID 只略升。 |
| QXS-SAROPT | 0.085 | 3.67 | SSIM、PSNR 仍上升，但结果发糊，LPIPS 和 FID 一起变差。 |

互信息高、Chamfer 距离小，说明光学目标能从 SAR 预测出来，配对也空间一致，值得训一次前向。两个量都不利时，保留生成式方法，或先改善配准。它们是辅助判据，不是保证。

0.133 / 0.085 是灰度像素互信息 `mi`（单位 nat），由 `src/archive/evaluate_sar_opt_metrics.py` 计算，不是其他诊断脚本里的归一化互信息 `nmi`。逐张证据在 `assets/statistics/`。

## 环境

Python 3.10。记录的环境名是 `nasty-home`。

```bash
conda env create -f environment/environment.nasty-home.yml
conda activate nasty-home
pip install -r environment/requirements-nasty-home.txt
```

下面的变量都指向**本地**文件。SD 2.1 目录里必须已经有 `vae/`、`unet/`、`text_encoder/`、`tokenizer/`。评测不会按模型名联网下载。

```bash
export SEN12_ROOT=/path/to/SEN12/splits
export QXS_ROOT=/path/to/QXSLAB_SAROPT
export VAE_MODEL_DIR=/path/to/sd21-base
export FID_WEIGHTS=/path/to/weights-inception-2015-12-05-6726825d.pth
export OSLR_FULL_CKPT=/path/to/oslr_full_sen12.pth
```

凡是要报告 FID，都必须设置 `FID_WEIGHTS`。文件是 torch-fidelity 发布的 Inception v3 权重，SHA256 为 `6726825d0af5f729cebd5821db510b11b1cfad8faad88a03f1befd49fb9129b2`。

## 数据

本仓库不分发 SAR / 光学原图。

| 数据集 | 论文中的用法 | 获取途径 |
| --- | --- | --- |
| SEN1-2（论文中称 SEN12） | 13,000 对训练、3,000 对测试，四类地物，resize 到 256×256 | [TUM mediaTUM](https://mediatum.ub.tum.de/1436631)（CC-BY 4.0）。配对清单：`assets/manifests/sen12_pair_index_relative.json`。 |
| QXS-SAROPT | 16,000 对训练，以及 seed 42 固定的 4,000 对测试子集 | [yaoxu008/QXS-SAROPT](https://github.com/yaoxu008/QXS-SAROPT)。子集清单：`assets/manifests/qxs_valtest4000_seed42_relative.json`。 |

目录约定：

```text
SEN12_ROOT/{train,test}/{agri,barrenland,grassland,urban}/{s1,s2}/
QXS_ROOT/splits/{train,valtest}/qxs/{s1,s2}/
```

下载命令、目录说明和校验值见 [DATA_AND_WEIGHTS.md](DATA_AND_WEIGHTS.md)。

环境变量设置好之后，生成路径清单：

```bash
python scripts/prepare_runtime_manifests.py \
  --sen12-root "$SEN12_ROOT" --qxs-root "$QXS_ROOT" \
  --output-dir runtime_manifests --validate
```

## 检查点

发布地址还没填。在填上之前，SHA256 用来确认哪一份文件对应论文表格。公开仓库前把 `PENDING` 换成真实地址；如果文件字节变了，要重算哈希。

| ID | 论文中的用途 | SHA256 | URL |
| --- | --- | --- | --- |
| `oslr_full_sen12` | 表 I、II、IV：OSLR (full)，`model_step_30000_final.pth` | `b8138b3e52b8ade7db8b10bfffc56859d73ea93eb7a020a5ab64554cfa5ab93e` | PENDING |
| `oslr_l1_sen12` | 表 IV：仅 L1 | `56b3794c93dc0dcdaaca70f5d2f046044fdc799b9c09ca1ad0f6c58e1321dd73` | PENDING |
| `ldm_sen12` | SEN12 上的多步 DDIM / DPM-Solver++ | `05769122e8b9b4b42db568734d79bfb43e3862f312d97dc39ec61bbb9b048295` | PENDING |
| `lcd_sen12` | SEN12 上的潜空间一致性蒸馏 | `6347ce06698026d0191d51ca3983a7a8782598296673669eadb7e351a25594f0` | PENDING |
| `oslr_l1_qxs` | 表 V：QXS 上的 OSLR（仅 L1），5k 步检查点 | `05c3f8c4856fbaf87f910d99f85fb589adc797e41019d06e17f0c2d993d65eaf` | PENDING |
| `ldm_qxs` | 表 V：QXS 上的 50 步 DDIM | `c004ff5ff9628b56ccbd428e78a17cbba3c28eb1b032c09bcc5caab2eb089ca7` | PENDING |

把 `OSLR_FULL_CKPT`、`LDM_SEN12_CKPT`、`OSLR_QXS_CKPT`、`LDM_QXS_CKPT` 指到对应的本地文件。SD 2.1-base 本身从 Hugging Face 下载，许可是 CreativeML OpenRAIL-M，不在上表里。

## 快速开始

冒烟测试用 16 张类别均衡的 SEN12 图像（`seed=42`）检查环境、OSLR (full) 检查点和指标管线是否一致。它不能用来复现论文里的 FID。

```bash
bash scripts/run_oslr_smoke.sh
```

三个层级都固定 `seed=42`：

| 层级 | 命令 | 样本 | 用途 |
| --- | --- | --- | --- |
| smoke | `bash scripts/run_oslr_smoke.sh` | 16 | 确认安装 |
| fixed | `bash scripts/run_oslr_fixed_eval.sh` | 100 | 只看相对趋势 |
| full | `bash scripts/run_full_protocol.sh <name>` | SEN12 3,000 或 QXS 4,000 | 论文表格 |

`<name>` 取 `oslr-sen12`、`ldm-sen12`、`oslr-qxs`、`ldm-qxs`、`pair-statistics` 之一。SEN12 扩散检查点的求解器和步数扫描用 `src/sar2opt_latent/evaluate.py`，通过 `--scheduler` 和 `--num-inference-steps` 指定。

## 论文中的训练设置

图像 resize 到 256×256。唯一可训练的模块是 SD 2.1-base 的潜空间 UNet（865.9M 参数），第一层卷积从 4 通道加宽到 8 通道。VAE 编码器和解码器保持冻结。单通道 SAR 先复制成三通道，编码为 \(z_{\mathrm{sar}}\in\mathbb{R}^{4\times 32\times 32}\)，再与同形状的全零张量拼接。一次前向预测光学潜变量。

完整目标为

\[
\mathcal{L} = \mathcal{L}_{\mathrm{latent}} + \lambda_{\mathrm{ffl}}\mathcal{L}_{\mathrm{ffl}} + \lambda_{\mathrm{lpips}}\mathcal{L}_{\mathrm{lpips}},
\quad \lambda_{\mathrm{ffl}}=\lambda_{\mathrm{lpips}}=1.
\]

\(\mathcal{L}_{\mathrm{latent}}\) 是潜空间上的均值 \(\ell_1\)。FFL 和 LPIPS 在解码之后计算，梯度穿过冻结的解码器。

| 项目 | 取值 |
| --- | --- |
| 优化器 | AdamW，\(\beta_1=0.9\)，\(\beta_2=0.999\)，权重衰减 0.01 |
| 学习率 | \(1\times 10^{-4}\)，100 步线性 warmup，余弦衰减 |
| 硬件 | 2× A800-SXM4-80GB，每卡 batch size 16（全局 32） |
| SEN12 上的 OSLR | 先 30,000 步潜空间 \(\ell_1\)，再 20,000 步第二阶段目标。OSLR (full) 是 L1+FFL+LPIPS 这一行。 |
| SEN12 扩散基线 | 单独训练 50,000 步 |
| 跨数据集表中的 QXS 模型 | 50,000 步 |

训练入口是 `src/sar2opt_onestep/train.py`（OSLR）和 `src/sar2opt_latent/train.py`（潜空间扩散）。复现表中指标不需要重训，用上面的检查点即可。

## 目录

```text
src/sar2opt_onestep/     OSLR 的训练、推理和评测
src/sar2opt_latent/      潜空间扩散、求解器和共用指标
src/archive/             像素互信息和 Chamfer
src/baselines/           对已有预测目录计算指标
assets/manifests/        固定的 SEN12 与 QXS 样本清单
assets/results/          论文表格的审计 JSON
assets/statistics/       MI / Chamfer 汇总和逐张 CSV
environment/             nasty-home 的 conda 环境与锁定依赖
scripts/                 清单生成，以及 smoke / fixed / full 评测
```

## 引用

```bibtex
@article{chen2026oslr,
  author  = {Chen, Rui and Liu, Peng},
  title   = {Rethinking Sampling for {SAR}-to-Optical Translation: When One-Step Regression Suffices},
  journal = {IEEE Geoscience and Remote Sensing Letters},
  year    = {2026},
  note    = {Manuscript received April 9, 2026}
}
```

文章有卷期和 DOI 之后，再更新这段 BibTeX。

## 许可

| 材料 | 许可 |
| --- | --- |
| 本仓库代码 | 待定。公开前补上 `LICENSE`。 |
| SEN1-2 | CC-BY 4.0 |
| QXS-SAROPT | CC-BY，需通过作者问卷获取 |
| Stable Diffusion 2.1 | CreativeML OpenRAIL-M |
| FID Inception 权重 | 遵循 torch-fidelity 的发布许可 |

代码、数据和预训练权重不是同一份许可。不要把 SEN12、QXS、SD 2.1 或论文检查点提交进这个 git 仓库。
