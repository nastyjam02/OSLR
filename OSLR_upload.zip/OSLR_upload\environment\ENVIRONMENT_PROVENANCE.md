# `nasty-home` 环境记录

本文包以服务器 Conda 环境 `nasty-home` 为主环境基线，而不是当时激活的 `PyTorch-1.12.1` 环境。

- Conda environment：`nasty-home`
- Python：3.10.20
- 关键 PyPI 版本：PyTorch 2.5.1+cu121、TorchVision 0.20.1+cu121、Diffusers 0.38.0、Transformers 5.9.0、TorchMetrics 1.9.0、Torch-Fidelity 0.4.0、LPIPS 0.1.4
- 服务器 GPU：3 × NVIDIA A800-SXM4-80GB
- 驱动：535.183.01

`environment.nasty-home.yml` 只锁定 Conda 基线；`requirements-nasty-home.txt` 锁定论文代码需要的 Python 依赖。主机中存在的 ModelArts SDK、可视化插件和 `file:///modelarts/...` 包均与本论文代码无关，且在外部机器不可安装，因此未纳入发布依赖。

建议在目标机器上先按目标 CUDA 平台安装官方 PyTorch wheel，再安装 requirements：

```bash
conda env create -f environment.nasty-home.yml
conda activate nasty-home
pip install --index-url https://download.pytorch.org/whl/cu121 torch==2.5.1+cu121 torchvision==0.20.1+cu121
pip install -r environment/requirements-nasty-home.txt
python -c "import torch; print(torch.__version__, torch.version.cuda)"
```

若 CUDA、GPU 或驱动不同，允许替换 PyTorch wheel，但必须在新增结果旁报告替换后的版本；不要把不同硬件的吞吐量与论文 A800 计时直接比较。
