#!/usr/bin/env python3
"""Convert portable relative manifests into manifests usable on a local machine."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
ASSET_DIR = PACKAGE_ROOT / "assets" / "manifests"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sen12-root", type=Path, required=True)
    parser.add_argument("--qxs-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--smoke-per-category", type=int, default=4)
    parser.add_argument("--fixed-per-category", type=int, default=25)
    parser.add_argument("--validate", action="store_true")
    return parser.parse_args()


def load_json(path: Path) -> dict:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def dump_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)


def materialize_sen12(source: dict, root: Path) -> dict:
    result = dict(source)
    result["splits_root"] = str(root)
    for split in ("train", "test"):
        entries = []
        for item in source[split]:
            entry = dict(item)
            entry["sar"] = str(root / entry["sar"])
            entry["opt"] = str(root / entry["opt"])
            entries.append(entry)
        result[split] = entries
    return result


def materialize_qxs(source: dict, root: Path) -> dict:
    result = dict(source)
    result["data_root"] = str(root / "splits" / "valtest")
    entries = []
    for item in source["samples"]:
        entry = dict(item)
        entry["sar_path"] = str(root / entry["sar_path"])
        entry["opt_path"] = str(root / entry["opt_path"])
        entries.append(entry)
    result["samples"] = entries
    return result


def select_balanced(samples: list[dict], per_category: int) -> list[dict]:
    selected: list[dict] = []
    categories = sorted({str(item["category"]) for item in samples})
    for category in categories:
        pool = [item for item in samples if item["category"] == category]
        if len(pool) < per_category:
            raise ValueError(f"{category} only has {len(pool)} samples; need {per_category}")
        selected.extend(pool[:per_category])
    selected.sort(key=lambda item: int(item["order"]))
    return [dict(item, order=index) for index, item in enumerate(selected)]


def validate_paths(entries: list[dict], fields: tuple[str, ...]) -> list[Path]:
    missing: list[Path] = []
    for entry in entries:
        for field in fields:
            path = Path(entry[field])
            if not path.is_file():
                missing.append(path)
    return missing


def main() -> None:
    args = parse_args()
    sen12 = materialize_sen12(
        load_json(ASSET_DIR / "sen12_pair_index_relative.json"),
        args.sen12_root.expanduser().resolve(),
    )
    qxs = materialize_qxs(
        load_json(ASSET_DIR / "qxs_valtest4000_seed42_relative.json"),
        args.qxs_root.expanduser().resolve(),
    )

    test_samples = [
        {
            "order": order,
            "index": order,
            "category": item["category"],
            "sar_path": item["sar"],
            "opt_path": item["opt"],
        }
        for order, item in enumerate(sen12["test"])
    ]
    smoke = select_balanced(test_samples, args.smoke_per_category)
    fixed = select_balanced(test_samples, args.fixed_per_category)
    output = args.output_dir.expanduser().resolve()

    dump_json(output / "sen12_pair_index.json", sen12)
    dump_json(
        output / "sen12_smoke.json",
        {"data_root": str(args.sen12_root.resolve()), "seed": 42, "samples": smoke},
    )
    dump_json(
        output / "sen12_fixed_100.json",
        {"data_root": str(args.sen12_root.resolve()), "seed": 42, "samples": fixed},
    )
    dump_json(output / "qxs_valtest4000.json", qxs)

    if args.validate:
        missing = (
            validate_paths(sen12["test"], ("sar", "opt"))
            + validate_paths(qxs["samples"], ("sar_path", "opt_path"))
        )
        if missing:
            preview = "\n".join(str(path) for path in missing[:10])
            raise SystemExit(f"Found {len(missing)} missing dataset files:\n{preview}")

    print(f"Wrote runtime manifests to {output}")
    print(f"SEN12: {len(sen12['train'])} train, {len(sen12['test'])} test")
    print(f"QXS: {len(qxs['samples'])} fixed evaluation samples")


if __name__ == "__main__":
    main()
