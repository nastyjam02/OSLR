#!/usr/bin/env bash
set -euo pipefail

EXPERIMENT="${1:-}"
PACKAGE_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
RUNTIME_DIR="${RUNTIME_DIR:-$PACKAGE_ROOT/runtime_manifests}"

if [[ -z "$EXPERIMENT" ]]; then
  echo "Usage: $0 {oslr-sen12|ldm-sen12|oslr-qxs|ldm-qxs|pair-statistics}" >&2
  exit 2
fi

: "${SEN12_ROOT:?Set SEN12_ROOT to the local splits directory.}"
: "${QXS_ROOT:?Set QXS_ROOT to the local QXS-SAROPT directory.}"

if [[ ! -f "$RUNTIME_DIR/qxs_valtest4000.json" ]]; then
  python "$PACKAGE_ROOT/scripts/prepare_runtime_manifests.py" \
    --sen12-root "$SEN12_ROOT" --qxs-root "$QXS_ROOT" \
    --output-dir "$RUNTIME_DIR"
fi

case "$EXPERIMENT" in
  pair-statistics)
    python "$PACKAGE_ROOT/src/archive/evaluate_sar_opt_metrics.py" \
      --root-dir "$SEN12_ROOT/test" \
      --output-csv "$PACKAGE_ROOT/reproduced/sen12_test3k_mi.csv" \
      --summary-json "$PACKAGE_ROOT/reproduced/sen12_test3k_mi_summary.json" \
      --bins 64 --workers "${WORKERS:-8}"
    python "$PACKAGE_ROOT/src/archive/evaluate_sar_opt_metrics.py" \
      --input "$RUNTIME_DIR/qxs_valtest4000.json" \
      --output-csv "$PACKAGE_ROOT/reproduced/qxs_valtest4k_mi.csv" \
      --summary-json "$PACKAGE_ROOT/reproduced/qxs_valtest4k_mi_summary.json" \
      --bins 64 --workers "${WORKERS:-8}"
    ;;
  oslr-sen12)
    : "${VAE_MODEL_DIR:?Set VAE_MODEL_DIR.}"
    : "${FID_WEIGHTS:?Set FID_WEIGHTS.}"
    : "${OSLR_FULL_CKPT:?Set OSLR_FULL_CKPT.}"
    python "$PACKAGE_ROOT/src/sar2opt_onestep/evaluate.py" \
      --checkpoint "$OSLR_FULL_CKPT" --data-root "$SEN12_ROOT" \
      --eval-manifest "" --output-dir "$PACKAGE_ROOT/reproduced/oslr_full_sen12" \
      --vae-model-id "$VAE_MODEL_DIR" --ldm-model-id "$VAE_MODEL_DIR" \
      --fid-weights "$FID_WEIGHTS" --input-mode clean --batch-size "${BATCH_SIZE:-32}" \
      --num-samples 3000 --seed 42
    ;;
  ldm-sen12)
    : "${VAE_MODEL_DIR:?Set VAE_MODEL_DIR.}"
    : "${FID_WEIGHTS:?Set FID_WEIGHTS.}"
    : "${LDM_SEN12_CKPT:?Set LDM_SEN12_CKPT.}"
    python "$PACKAGE_ROOT/src/sar2opt_latent/evaluate.py" \
      --checkpoint "$LDM_SEN12_CKPT" --data-root "$SEN12_ROOT" \
      --eval-manifest "" --output-dir "$PACKAGE_ROOT/reproduced/ldm_ddim50_sen12" \
      --vae-model-id "$VAE_MODEL_DIR" --ldm-model-id "$VAE_MODEL_DIR" \
      --fid-weights "$FID_WEIGHTS" --scheduler ddim --num-inference-steps 50 \
      --batch-size "${BATCH_SIZE:-32}" --num-samples 3000 --seed 42
    ;;
  oslr-qxs)
    : "${VAE_MODEL_DIR:?Set VAE_MODEL_DIR.}"
    : "${FID_WEIGHTS:?Set FID_WEIGHTS.}"
    : "${OSLR_QXS_CKPT:?Set OSLR_QXS_CKPT.}"
    python "$PACKAGE_ROOT/src/sar2opt_onestep/evaluate.py" \
      --checkpoint "$OSLR_QXS_CKPT" --data-root "$QXS_ROOT/splits/valtest" \
      --eval-manifest "$RUNTIME_DIR/qxs_valtest4000.json" \
      --output-dir "$PACKAGE_ROOT/reproduced/oslr_l1_qxs" \
      --vae-model-id "$VAE_MODEL_DIR" --ldm-model-id "$VAE_MODEL_DIR" \
      --fid-weights "$FID_WEIGHTS" --input-mode clean --batch-size "${BATCH_SIZE:-32}" \
      --num-samples 4000 --seed 42
    ;;
  ldm-qxs)
    : "${VAE_MODEL_DIR:?Set VAE_MODEL_DIR.}"
    : "${FID_WEIGHTS:?Set FID_WEIGHTS.}"
    : "${LDM_QXS_CKPT:?Set LDM_QXS_CKPT.}"
    python "$PACKAGE_ROOT/src/sar2opt_latent/evaluate.py" \
      --checkpoint "$LDM_QXS_CKPT" --data-root "$QXS_ROOT/splits/valtest" \
      --eval-manifest "$RUNTIME_DIR/qxs_valtest4000.json" \
      --output-dir "$PACKAGE_ROOT/reproduced/ldm_ddim50_qxs" \
      --vae-model-id "$VAE_MODEL_DIR" --ldm-model-id "$VAE_MODEL_DIR" \
      --fid-weights "$FID_WEIGHTS" --scheduler ddim --num-inference-steps 50 \
      --batch-size "${BATCH_SIZE:-32}" --num-samples 4000 --seed 42
    ;;
  *)
    echo "Unknown experiment: $EXPERIMENT" >&2
    exit 2
    ;;
esac
