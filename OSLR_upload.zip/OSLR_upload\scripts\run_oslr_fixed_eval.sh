#!/usr/bin/env bash
set -euo pipefail

PACKAGE_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
RUNTIME_DIR="${RUNTIME_DIR:-$PACKAGE_ROOT/runtime_manifests}"

: "${SEN12_ROOT:?Set SEN12_ROOT to the local splits directory.}"
: "${VAE_MODEL_DIR:?Set VAE_MODEL_DIR to the local SD2.1 model directory.}"
: "${FID_WEIGHTS:?Set FID_WEIGHTS to the local FID Inception weight file.}"
: "${OSLR_FULL_CKPT:?Set OSLR_FULL_CKPT to the downloaded OSLR full checkpoint.}"

if [[ ! -f "$RUNTIME_DIR/sen12_fixed_100.json" ]]; then
  : "${QXS_ROOT:?Set QXS_ROOT once to generate runtime manifests.}"
  python "$PACKAGE_ROOT/scripts/prepare_runtime_manifests.py" \
    --sen12-root "$SEN12_ROOT" --qxs-root "$QXS_ROOT" \
    --output-dir "$RUNTIME_DIR"
fi

python "$PACKAGE_ROOT/src/sar2opt_onestep/evaluate.py" \
  --checkpoint "$OSLR_FULL_CKPT" \
  --data-root "$SEN12_ROOT" \
  --eval-manifest "$RUNTIME_DIR/sen12_fixed_100.json" \
  --output-dir "$PACKAGE_ROOT/reproduced/fixed100_oslr_full" \
  --vae-model-id "$VAE_MODEL_DIR" \
  --ldm-model-id "$VAE_MODEL_DIR" \
  --fid-weights "$FID_WEIGHTS" \
  --input-mode clean \
  --batch-size "${BATCH_SIZE:-32}" \
  --num-samples 100 \
  --seed 42
