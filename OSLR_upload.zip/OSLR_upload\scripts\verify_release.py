#!/usr/bin/env python3
"""Fail fast on common release-package omissions and local-path leaks."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REQUIRED = (
    "README.md",
    "ASSET_MAP.md",
    "DATA_AND_WEIGHTS.md",
    "environment/environment.nasty-home.yml",
    "environment/requirements-nasty-home.txt",
    "assets/manifests/sen12_pair_index_relative.json",
    "assets/manifests/qxs_valtest4000_seed42_relative.json",
    "assets/statistics/sen12_test3k_mi_summary.json",
    "assets/statistics/qxs_valtest4k_mi_summary.json",
    "assets/results/oslr_full_sen12.json",
    "assets/results/ldm_ddim50_sen12.json",
    "src/sar2opt_onestep/train.py",
    "src/sar2opt_latent/evaluate.py",
    "src/archive/evaluate_sar_opt_metrics.py",
)
FORBIDDEN = ("/home/ma-user/work/mnt/Nasty", "/home/ma-user/anaconda3")


def main() -> None:
    missing = [item for item in REQUIRED if not (ROOT / item).is_file()]
    if missing:
        raise SystemExit("Missing required files:\n" + "\n".join(missing))

    leaks: list[Path] = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.suffix not in {".py", ".sh", ".md", ".json", ".csv", ".txt", ".yml"}:
            continue
        if path.resolve() == Path(__file__).resolve():
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        if any(value in text for value in FORBIDDEN):
            leaks.append(path.relative_to(ROOT))
    if leaks:
        raise SystemExit("Found server-specific paths:\n" + "\n".join(map(str, leaks)))

    for path in (
        ROOT / "assets/manifests/sen12_pair_index_relative.json",
        ROOT / "assets/manifests/qxs_valtest4000_seed42_relative.json",
    ):
        with path.open(encoding="utf-8") as handle:
            json.load(handle)

    placeholders = (ROOT / "DATA_AND_WEIGHTS.md").read_text(encoding="utf-8").count("FILL_BEFORE_RELEASE")
    print(f"Package check passed. Weight registry still has {placeholders} required release fields to fill.")


if __name__ == "__main__":
    main()
