#!/usr/bin/env python3
"""Evaluate SAR/optical matching quality with NMI and edge Chamfer distance.

The default mode evaluates the paired images stored in eval_100_balanced.json.
If registered/warped SAR outputs are available, pass --after-dir or
--after-field to compute before/after deltas.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import cv2
import numpy as np


def read_gray(path: str | Path) -> np.ndarray:
    image = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if image is None:
        raise FileNotFoundError(f"Cannot read image: {path}")

    if image.ndim == 3:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    elif image.ndim == 4:
        image = cv2.cvtColor(image, cv2.COLOR_BGRA2GRAY)

    return image.astype(np.float32)


def center_crop_pair(a: np.ndarray, b: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    h = min(a.shape[0], b.shape[0])
    w = min(a.shape[1], b.shape[1])

    def crop(x: np.ndarray) -> np.ndarray:
        y0 = (x.shape[0] - h) // 2
        x0 = (x.shape[1] - w) // 2
        return x[y0 : y0 + h, x0 : x0 + w]

    return crop(a), crop(b)


def robust_normalize(image: np.ndarray) -> np.ndarray:
    valid = image[np.isfinite(image)]
    if valid.size == 0:
        return np.zeros_like(image, dtype=np.float32)

    lo, hi = np.percentile(valid, [1, 99])
    if hi <= lo:
        lo, hi = float(valid.min()), float(valid.max())
    if hi <= lo:
        return np.zeros_like(image, dtype=np.float32)

    normalized = (image - lo) / (hi - lo)
    return np.clip(normalized, 0.0, 1.0).astype(np.float32)


def entropy_from_hist(hist: np.ndarray) -> float:
    prob = hist.astype(np.float64)
    total = prob.sum()
    if total <= 0:
        return 0.0
    prob = prob / total
    prob = prob[prob > 0]
    return float(-np.sum(prob * np.log(prob)))


def compute_mi_nmi(a: np.ndarray, b: np.ndarray, bins: int = 64) -> dict[str, float]:
    a, b = center_crop_pair(a, b)
    x = robust_normalize(a).ravel()
    y = robust_normalize(b).ravel()

    valid = np.isfinite(x) & np.isfinite(y)
    x = x[valid]
    y = y[valid]
    if x.size == 0:
        return {"mi": math.nan, "nmi": math.nan}

    joint_hist, _, _ = np.histogram2d(x, y, bins=bins, range=[[0, 1], [0, 1]])
    hist_x = joint_hist.sum(axis=1)
    hist_y = joint_hist.sum(axis=0)

    hx = entropy_from_hist(hist_x)
    hy = entropy_from_hist(hist_y)
    hxy = entropy_from_hist(joint_hist)
    mi = hx + hy - hxy
    nmi = (hx + hy) / (hxy + 1e-12)
    return {"mi": float(mi), "nmi": float(nmi)}


def to_uint8(image: np.ndarray) -> np.ndarray:
    return (robust_normalize(image) * 255.0).astype(np.uint8)


def auto_canny(image: np.ndarray, sigma: float = 0.33) -> np.ndarray:
    blurred = cv2.GaussianBlur(to_uint8(image), (5, 5), 0)
    median = float(np.median(blurred))
    lower = int(max(0, (1.0 - sigma) * median))
    upper = int(min(255, (1.0 + sigma) * median))
    if lower == upper:
        lower, upper = 50, 150
    return cv2.Canny(blurred, lower, upper)


def one_way_chamfer(src_edges: np.ndarray, dst_edges: np.ndarray) -> float:
    src_mask = src_edges > 0
    dst_mask = dst_edges > 0
    if not np.any(src_mask) or not np.any(dst_mask):
        return math.nan

    # distanceTransform measures distance from each background pixel to nearest
    # zero pixel, so edge pixels are encoded as zero in the destination image.
    dst_zero_edges = np.where(dst_mask, 0, 255).astype(np.uint8)
    distance = cv2.distanceTransform(dst_zero_edges, cv2.DIST_L2, 3)
    return float(distance[src_mask].mean())


def compute_chamfer(a: np.ndarray, b: np.ndarray) -> dict[str, float]:
    a, b = center_crop_pair(a, b)
    edges_a = auto_canny(a)
    edges_b = auto_canny(b)

    a_to_b = one_way_chamfer(edges_a, edges_b)
    b_to_a = one_way_chamfer(edges_b, edges_a)
    chamfer = np.nanmean([a_to_b, b_to_a])
    return {
        "chamfer_px": float(chamfer),
        "chamfer_a_to_b_px": float(a_to_b),
        "chamfer_b_to_a_px": float(b_to_a),
        "edges_a": int(np.count_nonzero(edges_a)),
        "edges_b": int(np.count_nonzero(edges_b)),
    }


def build_after_index(after_dir: Path | None) -> dict[str, Path]:
    if after_dir is None:
        return {}
    return {path.name: path for path in after_dir.rglob("*") if path.is_file()}


def resolve_after_path(
    sample: dict[str, Any],
    after_field: str | None,
    after_index: dict[str, Path],
) -> Path | None:
    if after_field and sample.get(after_field):
        return Path(sample[after_field])

    sar_name = Path(sample["sar_path"]).name
    return after_index.get(sar_name)


def build_samples_from_root(root_dir: Path) -> list[dict[str, Any]]:
    samples: list[dict[str, Any]] = []
    categories = sorted(path for path in root_dir.iterdir() if path.is_dir())
    order = 0

    for category_dir in categories:
        sar_dir = category_dir / "s1"
        opt_dir = category_dir / "s2"
        if not sar_dir.is_dir() or not opt_dir.is_dir():
            continue

        for sar_path in sorted(sar_dir.glob("*.png")):
            opt_name = sar_path.name.replace("_s1_", "_s2_")
            opt_path = opt_dir / opt_name
            if not opt_path.exists():
                continue

            samples.append(
                {
                    "order": order,
                    "index": order,
                    "category": category_dir.name,
                    "sar_path": str(sar_path),
                    "opt_path": str(opt_path),
                }
            )
            order += 1

    return samples


def summarize(rows: list[dict[str, Any]], key: str | None = None) -> dict[str, Any]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        group = str(row[key]) if key else "overall"
        groups[group].append(row)

    def stats(values: list[float]) -> dict[str, float | int]:
        arr = np.array([v for v in values if v is not None and np.isfinite(v)], dtype=np.float64)
        if arr.size == 0:
            return {"count": 0, "mean": math.nan, "median": math.nan, "std": math.nan}
        return {
            "count": int(arr.size),
            "mean": float(arr.mean()),
            "median": float(np.median(arr)),
            "std": float(arr.std()),
        }

    summary = {}
    metric_names = [
        "nmi",
        "mi",
        "chamfer_px",
        "after_nmi",
        "after_chamfer_px",
        "delta_nmi",
        "delta_chamfer_px",
    ]
    for group, group_rows in groups.items():
        summary[group] = {
            metric: stats([row.get(metric, math.nan) for row in group_rows])
            for metric in metric_names
        }
    return summary


def evaluate_sample(
    sample: dict[str, Any],
    bins: int,
    after_field: str | None,
    after_index: dict[str, Path],
) -> dict[str, Any]:
    sar = read_gray(sample["sar_path"])
    opt = read_gray(sample["opt_path"])

    mi_nmi = compute_mi_nmi(sar, opt, bins=bins)
    chamfer = compute_chamfer(sar, opt)
    row = {
        "order": sample.get("order"),
        "index": sample.get("index"),
        "category": sample.get("category"),
        "sar_path": sample["sar_path"],
        "opt_path": sample["opt_path"],
        **mi_nmi,
        **chamfer,
    }

    after_path = resolve_after_path(sample, after_field, after_index)
    if after_path is not None and after_path.exists():
        after_sar = read_gray(after_path)
        after_mi_nmi = compute_mi_nmi(after_sar, opt, bins=bins)
        after_chamfer = compute_chamfer(after_sar, opt)
        row.update(
            {
                "after_sar_path": str(after_path),
                "after_mi": after_mi_nmi["mi"],
                "after_nmi": after_mi_nmi["nmi"],
                "after_chamfer_px": after_chamfer["chamfer_px"],
                "delta_nmi": after_mi_nmi["nmi"] - mi_nmi["nmi"],
                # Positive means the edge distance decreased after registration.
                "delta_chamfer_px": chamfer["chamfer_px"] - after_chamfer["chamfer_px"],
            }
        )
    else:
        row.update(
            {
                "after_sar_path": "",
                "after_mi": math.nan,
                "after_nmi": math.nan,
                "after_chamfer_px": math.nan,
                "delta_nmi": math.nan,
                "delta_chamfer_px": math.nan,
            }
        )

    return row


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input",
        default="",
        help="JSON file containing samples with sar_path and opt_path.",
    )
    parser.add_argument(
        "--root-dir",
        default=None,
        help="Optional dataset root with category/s1 and category/s2 directories.",
    )
    parser.add_argument(
        "--output-csv",
        default="sar_opt_metrics.csv",
        help="Per-sample metric output.",
    )
    parser.add_argument(
        "--summary-json",
        default="sar_opt_metrics_summary.json",
        help="Aggregate metric summary output.",
    )
    parser.add_argument("--bins", type=int, default=64, help="Histogram bins for MI/NMI.")
    parser.add_argument(
        "--workers",
        type=int,
        default=1,
        help="Number of worker processes. Use >1 for full datasets.",
    )
    parser.add_argument(
        "--after-dir",
        default=None,
        help="Optional directory containing registered SAR images with original filenames.",
    )
    parser.add_argument(
        "--after-field",
        default=None,
        help="Optional sample JSON field containing registered SAR image path.",
    )
    return parser.parse_args()


def evaluate_sample_for_pool(args: tuple[dict[str, Any], int, str | None, dict[str, Path]]) -> dict[str, Any]:
    return evaluate_sample(*args)


def main() -> None:
    args = parse_args()

    if args.root_dir:
        input_path = Path(args.root_dir)
        samples = build_samples_from_root(input_path)
    else:
        input_path = Path(args.input)
        with input_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        samples = data["samples"] if isinstance(data, dict) and "samples" in data else data

    after_index = build_after_index(Path(args.after_dir)) if args.after_dir else {}

    rows: list[dict[str, Any]] = []
    if args.workers > 1:
        tasks = [(sample, args.bins, args.after_field, after_index) for sample in samples]
        with ProcessPoolExecutor(max_workers=args.workers) as executor:
            futures = [executor.submit(evaluate_sample_for_pool, task) for task in tasks]
            for done, future in enumerate(as_completed(futures), 1):
                rows.append(future.result())
                if done % 500 == 0 or done == len(futures):
                    print(f"processed {done}/{len(futures)}", flush=True)
        rows.sort(key=lambda row: row["order"])
    else:
        for done, sample in enumerate(samples, 1):
            rows.append(evaluate_sample(sample, args.bins, args.after_field, after_index))
            if done % 500 == 0 or done == len(samples):
                print(f"processed {done}/{len(samples)}", flush=True)

    output_csv = Path(args.output_csv)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(rows[0].keys()) if rows else []
    with output_csv.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    summary = {
        "input": str(input_path),
        "num_samples": len(rows),
        "overall": summarize(rows)["overall"],
        "by_category": summarize(rows, key="category"),
    }
    summary_json = Path(args.summary_json)
    summary_json.parent.mkdir(parents=True, exist_ok=True)
    with summary_json.open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
