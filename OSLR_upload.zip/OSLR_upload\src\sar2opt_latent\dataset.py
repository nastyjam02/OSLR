"""
SAR–光学配对数据集（与 sar2opt 目录结构相同）。

P0 latent：默认 sar_representation=repeat3、normalize_mode=vae，与冻结 SD VAE 输入一致。
像素基线 legacy：sar_representation=gray、normalize_mode=legacy。
"""

from __future__ import annotations

import glob
import os

import cv2
import numpy as np
import torch
from torch.utils.data import Dataset


class SAROpticalDataset(Dataset):
    def __init__(
        self,
        sar_dir=None,
        opt_dir=None,
        image_size=256,
        root_dir=None,
        sar_representation: str = "repeat3",
        normalize_mode: str = "vae",
    ):
        """
        :param sar_representation: "gray" -> [1,H,W]； "repeat3" -> [3,H,W]（进 VAE）
        :param normalize_mode: "legacy"（SAR 公式7 + EO 动态 max）； "vae"（EO/SAR 均按 SD 友好映射到 [-1,1]）
        """
        self.sar_dir = sar_dir
        self.opt_dir = opt_dir
        self.image_size = image_size
        self.root_dir = root_dir
        self.sar_representation = sar_representation
        self.normalize_mode = normalize_mode

        if sar_representation not in ("gray", "repeat3"):
            raise ValueError("sar_representation 必须是 gray 或 repeat3")
        if normalize_mode not in ("legacy", "vae"):
            raise ValueError("normalize_mode 必须是 legacy 或 vae")

        if root_dir is not None:
            if sar_dir is not None or opt_dir is not None:
                raise ValueError("root_dir 与 sar_dir/opt_dir 只能二选一")
            self.sar_paths = self._collect_image_paths(root_dir, "*", "s1")
            self.opt_paths = self._collect_image_paths(root_dir, "*", "s2")
            self._validate_root_pairs()
        else:
            if sar_dir is None or opt_dir is None:
                raise ValueError("未指定 root_dir 时必须同时提供 sar_dir 和 opt_dir")
            self.sar_paths = self._collect_image_paths(sar_dir)
            self.opt_paths = self._collect_image_paths(opt_dir)

        assert len(self.sar_paths) == len(self.opt_paths), (
            f"SAR({len(self.sar_paths)}) 与光学({len(self.opt_paths)}) 数量不匹配"
        )
        if len(self.sar_paths) == 0:
            print("警告：未找到图像，请检查路径。")

    def __len__(self):
        return len(self.sar_paths)

    @staticmethod
    def _collect_image_paths(*parts):
        root = os.path.join(*parts)
        return sorted(
            glob.glob(os.path.join(root, "*.tif*"))
            + glob.glob(os.path.join(root, "*.png"))
        )

    def _validate_root_pairs(self):
        if len(self.sar_paths) != len(self.opt_paths):
            return
        for sar_path, opt_path in zip(self.sar_paths, self.opt_paths):
            expected_opt_path = (
                sar_path.replace(f"{os.sep}s1{os.sep}", f"{os.sep}s2{os.sep}")
                .replace("_s1_", "_s2_")
            )
            if os.path.normpath(expected_opt_path) != os.path.normpath(opt_path):
                raise ValueError(
                    "SAR 与光学配对不一致："
                    f"\nSAR: {sar_path}\nOPT: {opt_path}\n期望: {expected_opt_path}"
                )

    def _resize_if_needed(self, img):
        h, w = img.shape[:2]
        if h == self.image_size and w == self.image_size:
            return img
        return cv2.resize(
            img, (self.image_size, self.image_size), interpolation=cv2.INTER_AREA
        )

    @staticmethod
    def _vae_normalize_single_channel(gray_f32: np.ndarray) -> np.ndarray:
        """单通道 float -> [-1, 1]，与 EO vae 分支同一尺度习惯。"""
        gmax = float(gray_f32.max()) if gray_f32.size else 1.0
        if gmax <= 255.0:
            denom = 127.5
        else:
            denom = max(gmax / 2.0, 1e-6)
        return np.clip(gray_f32 / denom - 1.0, -1.0, 1.0).astype(np.float32)

    def _load_pair_raw(self, idx: int) -> tuple[np.ndarray, np.ndarray]:
        """
        读取并 resize 一对 SAR / 光学图像（未做 [-1,1] 归一化）。

        :return: sar_gray [H,W] float32；opt [H,W] 或 [H,W,3] float32（RGB 顺序）
        """
        sar_img = cv2.imread(self.sar_paths[idx], cv2.IMREAD_UNCHANGED)
        opt_img = cv2.imread(self.opt_paths[idx], cv2.IMREAD_UNCHANGED)
        if sar_img is None or opt_img is None:
            raise ValueError(f"无法读取: {self.sar_paths[idx]} 或 {self.opt_paths[idx]}")

        sar_img = sar_img.astype(np.float32)
        opt_img = opt_img.astype(np.float32)

        if len(sar_img.shape) > 2:
            sar_img = np.mean(sar_img, axis=2)

        if len(opt_img.shape) == 3 and opt_img.shape[2] == 3:
            if opt_img.max() <= 255.0:
                opt_img = cv2.cvtColor(opt_img.astype(np.uint8), cv2.COLOR_BGR2RGB).astype(
                    np.float32
                )

        sar_img = self._resize_if_needed(sar_img)
        opt_img = self._resize_if_needed(opt_img)
        return sar_img, opt_img

    def _normalize_opt(self, opt_img: np.ndarray) -> np.ndarray:
        """光学 -> [H,W,3] float32，vae 或 legacy 归一化。"""
        if self.normalize_mode == "vae":
            if len(opt_img.shape) == 3 and opt_img.shape[2] == 3:
                omax = float(opt_img.max()) if opt_img.size else 255.0
                denom = 127.5 if omax <= 255.0 else max(omax / 2.0, 1e-6)
                opt_norm = (opt_img / denom - 1.0).astype(np.float32)
                return np.clip(opt_norm, -1.0, 1.0)
            gray = opt_img if len(opt_img.shape) == 2 else np.mean(opt_img, axis=2)
            return np.stack([self._vae_normalize_single_channel(gray)] * 3, axis=2)

        opt_max = 255.0 if opt_img.max() <= 255.0 else float(opt_img.max())
        return (opt_img / (opt_max / 2.0)) - 1.0

    def _normalize_sar_gray(self, sar_img: np.ndarray) -> np.ndarray:
        """SAR 灰度 -> [H,W] float32。"""
        if self.normalize_mode == "vae":
            return self._vae_normalize_single_channel(sar_img)

        sar_mean = np.mean(sar_img)
        sar_norm = np.zeros_like(sar_img, dtype=np.float32)
        sar_norm[sar_img <= 0] = -1.0
        sar_norm[sar_img >= sar_mean] = 1.0
        mask = (sar_img > 0) & (sar_img < sar_mean)
        if sar_mean > 0:
            sar_norm[mask] = 2.0 * (sar_img[mask] / sar_mean) - 1.0
        else:
            sar_norm[mask] = -1.0
        return sar_norm

    def _sar_gray_to_tensor(self, sar_gray_norm: np.ndarray) -> torch.Tensor:
        if self.sar_representation == "repeat3":
            return torch.from_numpy(np.stack([sar_gray_norm] * 3, axis=0)).float()
        return torch.from_numpy(sar_gray_norm).unsqueeze(0).float()

    def __getitem__(self, idx):
        sar_img, opt_img = self._load_pair_raw(idx)
        opt_norm = self._normalize_opt(opt_img)
        sar_gray_norm = self._normalize_sar_gray(sar_img)
        sar_tensor = self._sar_gray_to_tensor(sar_gray_norm)
        opt_tensor = torch.from_numpy(opt_norm).permute(2, 0, 1).float()
        return sar_tensor, opt_tensor
