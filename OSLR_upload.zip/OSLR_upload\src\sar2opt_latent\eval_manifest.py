"""固定评估子集：跨类别均衡采样清单的生成与加载。"""

from __future__ import annotations

import json
import random
from collections import defaultdict
from pathlib import Path

from dataset import SAROpticalDataset

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_EVAL_MANIFEST = PROJECT_ROOT / "archive" / "splits" / "eval_100_balanced.json"
DEFAULT_EVAL_CATEGORIES = ("agri", "barrenland", "grassland", "urban")
DEFAULT_EVAL_PER_CATEGORY = 25
DEFAULT_EVAL_SEED = 42


def _category_for_index(dataset: SAROpticalDataset, index: int) -> str:
    return Path(dataset.sar_paths[index]).parent.parent.name


def build_stratified_eval_indices(
    data_root: Path,
    *,
    image_size: int,
    categories: tuple[str, ...],
    per_category: int,
    seed: int,
) -> list[int]:
    dataset = SAROpticalDataset(
        root_dir=str(data_root),
        image_size=image_size,
        sar_representation="repeat3",
        normalize_mode="vae",
    )
    by_cat: dict[str, list[int]] = defaultdict(list)
    for i in range(len(dataset)):
        cat = _category_for_index(dataset, i)
        if cat in categories:
            by_cat[cat].append(i)

    rng = random.Random(seed)
    selected: list[int] = []
    for cat in categories:
        pool = sorted(by_cat.get(cat, []))
        if len(pool) < per_category:
            raise RuntimeError(
                f"评估类 {cat!r} 仅 {len(pool)} 张，需要 {per_category} 张（root={data_root}）"
            )
        if len(pool) == per_category:
            picked = pool
        else:
            picked = sorted(rng.sample(pool, per_category))
        selected.extend(picked)

    return sorted(selected)


def save_eval_manifest(
    path: Path,
    *,
    data_root: Path,
    image_size: int,
    categories: tuple[str, ...],
    per_category: int,
    seed: int,
    indices: list[int],
) -> None:
    dataset = SAROpticalDataset(
        root_dir=str(data_root),
        image_size=image_size,
        sar_representation="repeat3",
        normalize_mode="vae",
    )
    entries = []
    for order, idx in enumerate(indices):
        sar_path = dataset.sar_paths[idx]
        entries.append(
            {
                "order": order,
                "index": idx,
                "category": _category_for_index(dataset, idx),
                "sar_path": sar_path,
                "opt_path": dataset.opt_paths[idx],
            }
        )
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "data_root": str(data_root.resolve()),
        "categories": list(categories),
        "per_category": per_category,
        "seed": seed,
        "num_samples": len(indices),
        "indices": indices,
        "samples": entries,
    }
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)


def load_eval_manifest(
    manifest_path: Path,
    *,
    data_root: Path | None = None,
) -> tuple[list[int], dict]:
    manifest_path = manifest_path.expanduser().resolve()
    if not manifest_path.is_file():
        raise FileNotFoundError(f"评估清单不存在: {manifest_path}")

    with manifest_path.open(encoding="utf-8") as f:
        payload = json.load(f)

    if data_root is not None:
        file_root = Path(payload.get("data_root", "")).expanduser().resolve()
        if file_root != data_root.expanduser().resolve():
            raise ValueError(
                "评估清单 data_root 不匹配:\n"
                f"  文件: {file_root}\n"
                f"  当前: {data_root.resolve()}"
            )

    indices = [int(i) for i in payload["indices"]]
    if not indices:
        raise ValueError(f"评估清单 indices 为空: {manifest_path}")
    return indices, payload


def generate_eval_manifest(
    manifest_path: Path,
    *,
    data_root: Path,
    image_size: int = 256,
    categories: tuple[str, ...] = DEFAULT_EVAL_CATEGORIES,
    per_category: int = DEFAULT_EVAL_PER_CATEGORY,
    seed: int = DEFAULT_EVAL_SEED,
) -> list[int]:
    data_root = data_root.expanduser().resolve()
    indices = build_stratified_eval_indices(
        data_root,
        image_size=image_size,
        categories=categories,
        per_category=per_category,
        seed=seed,
    )
    save_eval_manifest(
        manifest_path,
        data_root=data_root,
        image_size=image_size,
        categories=categories,
        per_category=per_category,
        seed=seed,
        indices=indices,
    )
    return indices
