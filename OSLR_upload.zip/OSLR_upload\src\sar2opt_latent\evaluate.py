"""Latent / LDM 评测：生成 decode 后与 GT 算 SSIM / FID。"""

from __future__ import annotations

import argparse
import json
import random
import time
from collections import defaultdict
from pathlib import Path

import cv2
import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

from dataset import SAROpticalDataset
from eval_manifest import DEFAULT_EVAL_MANIFEST, load_eval_manifest
from latent_infer import TTA_CHOICES, resolve_tta_views, sample_conditional_eo_tta
from model_ldm import DEFAULT_LDM_MODEL_ID, load_model_from_checkpoint
from scheduler_utils import SCHEDULER_CHOICES, build_inference_scheduler, run_subdir_name
from vae_utils import (
    DEFAULT_VAE_MODEL_ID,
    latent_spatial_size,
    load_frozen_vae,
    load_custom_sar_vae,
)

PACKAGE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = PACKAGE_DIR.parent
DEFAULT_DATA = PROJECT_ROOT / "archive" / "splits" / "test"
DEFAULT_CKPT = PROJECT_ROOT / "checkpoints" / "sar2opt_latent" / "model_step_5000_final.pth"
DEFAULT_OUT = PROJECT_ROOT / "outputs" / "sar2opt_latent_eval"
DEFAULT_FID_WEIGHTS = (
    PROJECT_ROOT
    / "sar2opt"
    / "FID_Inception_V3"
    / "weights-inception-2015-12-05-6726825d.pth"
)


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", default=str(DEFAULT_CKPT))
    p.add_argument("--data-root", default=str(DEFAULT_DATA))
    p.add_argument(
        "--eval-manifest",
        default=str(DEFAULT_EVAL_MANIFEST),
        help="跨类均衡评估清单 JSON；传空字符串则取 test 集前 num-samples 张",
    )
    p.add_argument("--output-dir", default=str(DEFAULT_OUT))
    p.add_argument("--vae-model-id", default=DEFAULT_VAE_MODEL_ID)
    p.add_argument(
        "--model-type",
        choices=("auto", "latent", "ldm"),
        default="auto",
    )
    p.add_argument("--ldm-model-id", default=DEFAULT_LDM_MODEL_ID)
    p.add_argument("--prompt", default=None)
    p.add_argument(
        "--guidance-scale",
        type=float,
        default=1.0,
        help="LDM text CFG 强度；>1 启用，<=1 与旧行为一致。",
    )
    p.add_argument("--image-size", type=int, default=256)
    p.add_argument("--batch-size", type=int, default=4)
    p.add_argument("--num-workers", type=int, default=2)
    p.add_argument("--num-samples", type=int, default=100)
    p.add_argument("--num-diffusion-steps", type=int, default=1000)
    p.add_argument("--num-inference-steps", type=int, default=50)
    p.add_argument("--scheduler", default="ddim", choices=SCHEDULER_CHOICES)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--log-every", type=int, default=10)
    p.add_argument("--save-sar", action="store_true")
    p.add_argument(
        "--fid-weights",
        default=str(DEFAULT_FID_WEIGHTS),
        help="FID Inception v3 本地权重；默认用 sar2opt/FID_Inception_V3，避免联网下载。",
    )
    p.add_argument(
        "--custom-sar-vae",
        default=None,
        help="自研单通道 SAR VAE checkpoint 权重路径（不为 None 时将替代 SD VAE 提取 z_sar 条件）。",
    )
    p.add_argument(
        "--tta",
        default="none",
        choices=TTA_CHOICES,
        help="几何 TTA：none=关闭；flip=原图+水平翻转；geo4=4 视图 dihedral 子集。算力约 ×视图数。",
    )
    p.add_argument(
        "--timing-warmup-batches",
        type=int,
        default=2,
        help="推理计时前跳过的 warmup batch 数（不计入 latency 统计）。",
    )
    return p.parse_args()


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def denormalize_rgb_batch(images):
    images = ((images + 1.0) / 2.0).clamp(0, 1)
    return (images * 255).round().to(torch.uint8)


def tensor_rgb_to_hwc(tensor):
    return tensor.permute(1, 2, 0).cpu().numpy()


def save_rgb_image(path, image_chw):
    path.parent.mkdir(parents=True, exist_ok=True)
    hwc = tensor_rgb_to_hwc(image_chw)
    bgr = cv2.cvtColor(hwc, cv2.COLOR_RGB2BGR)
    if not cv2.imwrite(str(path), bgr):
        raise RuntimeError(path)


def save_sar_preview(path, sar_3ch):
    """保存 SAR 首通道灰度预览。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    g = sar_3ch[0:1]
    g = ((g + 1.0) / 2.0).clamp(0, 1).squeeze(0).cpu().numpy()
    g = (g * 255).astype(np.uint8)
    if not cv2.imwrite(str(path), g):
        raise RuntimeError(path)


def build_sample_name(dataset, index, order=None):
    sar_path = Path(dataset.sar_paths[index])
    category = sar_path.parent.parent.name
    prefix = order if order is not None else index
    return f"{prefix:06d}_{category}_{sar_path.stem}.png"


def category_for_index(dataset, index):
    return Path(dataset.sar_paths[index]).parent.parent.name


def _fid_kwargs(fid_weights_path=None):
    fid_kw = {"feature": 2048, "normalize": False}
    if fid_weights_path:
        w = Path(fid_weights_path).expanduser().resolve()
        if not w.is_file():
            raise FileNotFoundError(w)
        fid_kw["feature_extractor_weights_path"] = str(w)
    return fid_kw


def create_fid(device, fid_weights_path=None):
    from torchmetrics.image.fid import FrechetInceptionDistance

    return FrechetInceptionDistance(**_fid_kwargs(fid_weights_path)).to(device)


def create_lpips(device):
    from torchmetrics.image.lpip import LearnedPerceptualImagePatchSimilarity

    return LearnedPerceptualImagePatchSimilarity(net_type="alex", normalize=True).to(device)


def create_metric_objects(device, fid_weights_path=None):
    from skimage.metrics import peak_signal_noise_ratio, structural_similarity

    fid = create_fid(device, fid_weights_path=fid_weights_path)
    lpips = create_lpips(device)
    return structural_similarity, peak_signal_noise_ratio, fid, lpips


def evaluate(args):
    set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    tta_views = resolve_tta_views(args.tta)

    ckpt = Path(args.checkpoint).resolve()
    data_root = Path(args.data_root).resolve()
    out_base = Path(args.output_dir).resolve()
    run_name = run_subdir_name(args.scheduler, args.num_inference_steps)
    output_dir = out_base / run_name
    if args.tta != "none":
        output_dir = output_dir / f"tta_{args.tta}"

    if not ckpt.is_file():
        raise FileNotFoundError(ckpt)
    if not data_root.is_dir():
        raise NotADirectoryError(data_root)

    fid_w = (args.fid_weights or "").strip() or None
    if fid_w is None and DEFAULT_FID_WEIGHTS.is_file():
        fid_w = str(DEFAULT_FID_WEIGHTS)
    structural_similarity, peak_signal_noise_ratio, fid, lpips = create_metric_objects(
        device, fid_weights_path=fid_w
    )

    dataset = SAROpticalDataset(
        root_dir=str(data_root),
        image_size=args.image_size,
        sar_representation="repeat3",
        normalize_mode="vae",
    )
    if len(dataset) == 0:
        raise RuntimeError("测试集为空")

    eval_manifest_path = (args.eval_manifest or "").strip()
    eval_manifest_meta = None
    eval_indices = None
    if eval_manifest_path:
        manifest = Path(eval_manifest_path).expanduser().resolve()
        eval_indices, eval_manifest_meta = load_eval_manifest(manifest, data_root=data_root)
        total = len(eval_indices)
        if args.num_samples is not None:
            total = min(args.num_samples, total)
            eval_indices = eval_indices[:total]
        eval_dataset = Subset(dataset, eval_indices)
    else:
        total = min(args.num_samples, len(dataset))
        eval_dataset = dataset

    loader = DataLoader(
        eval_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=torch.cuda.is_available(),
    )

    latent_size = latent_spatial_size(args.image_size)
    model, prompt_embeds, uncond_prompt_embeds, model_type = load_model_from_checkpoint(
        ckpt,
        device,
        model_type=args.model_type,
        ldm_model_id=args.ldm_model_id,
        latent_size=latent_size,
        prompt=args.prompt,
    )

    vae = load_frozen_vae(args.vae_model_id, device=device)

    sar_vae = None
    if args.custom_sar_vae:
        print("加载自研单通道 SAR VAE...", args.custom_sar_vae)
        sar_vae = load_custom_sar_vae(args.custom_sar_vae, device=device)

    scheduler = build_inference_scheduler(
        args.scheduler,
        args.num_diffusion_steps,
        args.num_inference_steps,
        device,
    )

    gen_dir = output_dir / "generated"
    real_dir = output_dir / "real"
    sar_dir = output_dir / "sar"
    gen_dir.mkdir(parents=True, exist_ok=True)
    real_dir.mkdir(parents=True, exist_ok=True)
    if args.save_sar:
        sar_dir.mkdir(parents=True, exist_ok=True)

    manifest_msg = eval_manifest_path or "(前 num-samples 张)"
    cfg_msg = f" guidance_scale={args.guidance_scale}" if args.guidance_scale > 1.0 else ""
    tta_msg = f" tta={args.tta}{tta_views}" if args.tta != "none" else ""
    print(
        f"{model_type} 评估",
        ckpt,
        f"manifest={manifest_msg}{cfg_msg}{tta_msg}",
        "samples=",
        total,
        "out=",
        output_dir,
    )

    ssim_vals = []
    psnr_vals = []
    ssim_by_cat = defaultdict(list)
    psnr_by_cat = defaultdict(list)
    fid_by_cat = {}
    lpips_by_cat = {}

    def get_category_metrics(category):
        if category not in fid_by_cat:
            fid_by_cat[category] = create_fid(device, fid_weights_path=fid_w)
            lpips_by_cat[category] = create_lpips(device)
        return fid_by_cat[category], lpips_by_cat[category]

    processed = 0
    wall_t0 = time.perf_counter()
    infer_batch_ms = []
    timed_images = 0
    peak_mem_bytes = 0

    for batch_idx, (sar_imgs, real_opt) in enumerate(loader):
        if processed >= total:
            break
        remain = total - processed
        if sar_imgs.shape[0] > remain:
            sar_imgs = sar_imgs[:remain]
            real_opt = real_opt[:remain]

        sar_imgs = sar_imgs.to(device)
        real_opt = real_opt.to(device)

        do_time = batch_idx >= max(0, args.timing_warmup_batches)
        if device.type == "cuda":
            torch.cuda.synchronize()
        t_infer0 = time.perf_counter()
        with torch.no_grad():
            fake_opt = sample_conditional_eo_tta(
                model,
                vae,
                scheduler,
                sar_imgs,
                latent_size,
                prompt_embeds=prompt_embeds,
                uncond_prompt_embeds=uncond_prompt_embeds,
                guidance_scale=args.guidance_scale,
                sar_vae=sar_vae,
                tta=args.tta,
            )
        if device.type == "cuda":
            torch.cuda.synchronize()
        t_infer1 = time.perf_counter()
        if do_time:
            batch_ms = (t_infer1 - t_infer0) * 1000.0
            infer_batch_ms.append(batch_ms)
            timed_images += int(sar_imgs.shape[0])
        if device.type == "cuda":
            peak_mem_bytes = max(peak_mem_bytes, int(torch.cuda.max_memory_allocated()))

        fake_u8 = denormalize_rgb_batch(fake_opt)
        real_u8 = denormalize_rgb_batch(real_opt)
        fid.update(real_u8.to(device), real=True)
        fid.update(fake_u8.to(device), real=False)
        fake_01 = ((fake_opt + 1.0) / 2.0).clamp(0, 1)
        real_01 = ((real_opt + 1.0) / 2.0).clamp(0, 1)
        lpips.update(fake_01, real_01)

        for i in range(fake_u8.shape[0]):
            subset_idx = batch_idx * args.batch_size + i
            if eval_indices is not None:
                orig_idx = eval_indices[subset_idx]
                name = build_sample_name(dataset, orig_idx, order=subset_idx)
            else:
                orig_idx = subset_idx
                name = build_sample_name(dataset, orig_idx)
            fi = fake_u8[i].cpu()
            ri = real_u8[i].cpu()
            save_rgb_image(gen_dir / name, fi)
            save_rgb_image(real_dir / name, ri)
            if args.save_sar:
                save_sar_preview(sar_dir / name, sar_imgs[i])

            ssim_val = float(
                structural_similarity(
                    tensor_rgb_to_hwc(ri),
                    tensor_rgb_to_hwc(fi),
                    channel_axis=2,
                    data_range=255,
                )
            )
            psnr_val = float(
                peak_signal_noise_ratio(
                    tensor_rgb_to_hwc(ri),
                    tensor_rgb_to_hwc(fi),
                    data_range=255,
                )
            )
            ssim_vals.append(ssim_val)
            psnr_vals.append(psnr_val)

            cat = category_for_index(dataset, orig_idx)
            ssim_by_cat[cat].append(ssim_val)
            psnr_by_cat[cat].append(psnr_val)
            cat_fid, cat_lpips = get_category_metrics(cat)
            cat_fid.update(ri.unsqueeze(0).to(device), real=True)
            cat_fid.update(fi.unsqueeze(0).to(device), real=False)
            cat_lpips.update(fake_01[i : i + 1], real_01[i : i + 1])

        processed += fake_u8.shape[0]
        if args.log_every > 0 and (processed % args.log_every == 0 or processed == total):
            print(f"已评估 {processed}/{total}", flush=True)

    metrics_by_category = {}
    for cat in sorted(ssim_by_cat):
        metrics_by_category[cat] = {
            "num_samples": len(ssim_by_cat[cat]),
            "mean_ssim": float(np.mean(ssim_by_cat[cat])),
            "mean_psnr": float(np.mean(psnr_by_cat[cat])),
            "mean_lpips": float(lpips_by_cat[cat].compute().item()),
            "fid": float(fid_by_cat[cat].compute().item()),
        }

    wall_s = time.perf_counter() - wall_t0
    infer_total_s = float(sum(infer_batch_ms) / 1000.0) if infer_batch_ms else 0.0
    ms_per_image = (
        float(sum(infer_batch_ms) / timed_images) if timed_images > 0 else None
    )
    images_per_s = (
        float(timed_images / infer_total_s) if infer_total_s > 0 else None
    )
    timing = {
        "wall_total_s": float(wall_s),
        "infer_total_s": infer_total_s,
        "timed_images": int(timed_images),
        "timing_warmup_batches": int(args.timing_warmup_batches),
        "num_timed_batches": len(infer_batch_ms),
        "ms_per_image": ms_per_image,
        "images_per_s": images_per_s,
        "batch_size": int(args.batch_size),
        "mean_batch_ms": float(np.mean(infer_batch_ms)) if infer_batch_ms else None,
        "p50_batch_ms": float(np.percentile(infer_batch_ms, 50)) if infer_batch_ms else None,
        "p95_batch_ms": float(np.percentile(infer_batch_ms, 95)) if infer_batch_ms else None,
        "peak_cuda_mem_gb": (
            float(peak_mem_bytes / (1024**3)) if peak_mem_bytes > 0 else None
        ),
        "note": (
            "infer_* 仅统计 sample_conditional_eo_tta（含 SAR encode + UNet 采样 + VAE decode）；"
            "不含指标计算与落盘。wall_total_s 为整次 evaluate 墙钟时间。"
        ),
    }

    metrics = {
        "checkpoint": str(ckpt),
        "data_root": str(data_root),
        "eval_manifest": eval_manifest_path or None,
        "eval_categories": eval_manifest_meta.get("categories") if eval_manifest_meta else None,
        "eval_per_category": eval_manifest_meta.get("per_category") if eval_manifest_meta else None,
        "output_dir": str(output_dir),
        "model_type": model_type,
        "num_samples": processed,
        "mean_ssim": float(np.mean(ssim_vals)),
        "mean_psnr": float(np.mean(psnr_vals)),
        "mean_lpips": float(lpips.compute().item()),
        "fid": float(fid.compute().item()),
        "metrics_by_category": metrics_by_category,
        "scheduler": args.scheduler,
        "num_diffusion_steps": args.num_diffusion_steps,
        "num_inference_steps": args.num_inference_steps,
        "guidance_scale": args.guidance_scale,
        "tta": args.tta,
        "tta_views": list(tta_views),
        "timing": timing,
    }
    outp = output_dir / "metrics.json"
    with outp.open("w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2, ensure_ascii=False)
    timing_path = output_dir / "timing.json"
    with timing_path.open("w", encoding="utf-8") as f:
        json.dump(
            {
                "scheduler": args.scheduler,
                "num_inference_steps": args.num_inference_steps,
                "num_samples": processed,
                **timing,
            },
            f,
            indent=2,
            ensure_ascii=False,
        )
    print(
        "SSIM",
        metrics["mean_ssim"],
        "PSNR",
        metrics["mean_psnr"],
        "LPIPS",
        metrics["mean_lpips"],
        "FID",
        metrics["fid"],
        outp,
    )
    print(
        "timing",
        f"infer={infer_total_s:.1f}s",
        f"ms/img={ms_per_image:.2f}" if ms_per_image is not None else "ms/img=n/a",
        f"img/s={images_per_s:.2f}" if images_per_s is not None else "img/s=n/a",
        f"wall={wall_s:.1f}s",
        timing_path,
    )
    if metrics_by_category:
        print("-" * 72)
        print(f"{'Category':<12} | {'N':>5} | {'SSIM':>8} | {'PSNR':>8} | {'LPIPS':>8} | {'FID':>8}")
        for cat, cat_metrics in metrics_by_category.items():
            print(
                f"{cat:<12} | {cat_metrics['num_samples']:>5} | "
                f"{cat_metrics['mean_ssim']:>8.4f} | {cat_metrics['mean_psnr']:>8.2f} | "
                f"{cat_metrics['mean_lpips']:>8.4f} | {cat_metrics['fid']:>8.2f}"
            )


if __name__ == "__main__":
    evaluate(parse_args())

'''
# 基线（无 TTA）
python evaluate.py \
  --checkpoint "${LDM_SEN12_CKPT}" \
  --model-type ldm \
  --data-root "${SEN12_ROOT}" \
  --output-dir reproduced/ldm_tta \
  --scheduler ddim \
  --num-inference-steps 50 \
  --num-samples 100 \
  --batch-size 16 \
  --seed 42 \
  --tta none

# 几何 TTA：原图 + 水平翻转（约 2× 算力）
python evaluate.py \
  --checkpoint "${LDM_SEN12_CKPT}" \
  --model-type ldm \
  --data-root "${SEN12_ROOT}" \
  --output-dir reproduced/ldm_tta \
  --scheduler ddim \
  --num-inference-steps 50 \
  --num-samples 100 \
  --batch-size 16 \
  --seed 42 \
  --tta flip

# 几何 TTA：4 视图（约 4× 算力）
python evaluate.py \
  --checkpoint "${LDM_SEN12_CKPT}" \
  --model-type ldm \
  --data-root "${SEN12_ROOT}" \
  --output-dir reproduced/ldm_tta \
  --scheduler ddim \
  --num-inference-steps 50 \
  --num-samples 100 \
  --batch-size 16 \
  --seed 42 \
  --tta geo4
'''