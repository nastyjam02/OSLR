"""生成跨类别均衡的固定评估清单（默认 4 类 × 25 张 = 100 张）。"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent
if str(PACKAGE_DIR) not in sys.path:
    sys.path.insert(0, str(PACKAGE_DIR))

from eval_manifest import (  # noqa: E402
    DEFAULT_EVAL_CATEGORIES,
    DEFAULT_EVAL_MANIFEST,
    DEFAULT_EVAL_PER_CATEGORY,
    DEFAULT_EVAL_SEED,
    generate_eval_manifest,
)

DEFAULT_DATA = PACKAGE_DIR.parent / "archive" / "splits" / "test"


def parse_args():
    parser = argparse.ArgumentParser(description="生成固定评估清单 JSON")
    parser.add_argument("--data-root", default=str(DEFAULT_DATA))
    parser.add_argument("--output", default=str(DEFAULT_EVAL_MANIFEST))
    parser.add_argument("--image-size", type=int, default=256)
    parser.add_argument("--per-category", type=int, default=DEFAULT_EVAL_PER_CATEGORY)
    parser.add_argument("--seed", type=int, default=DEFAULT_EVAL_SEED)
    parser.add_argument(
        "--categories",
        nargs="+",
        default=list(DEFAULT_EVAL_CATEGORIES),
    )
    return parser.parse_args()


def main():
    args = parse_args()
    data_root = Path(args.data_root).expanduser().resolve()
    output = Path(args.output).expanduser().resolve()
    categories = tuple(args.categories)
    total = args.per_category * len(categories)

    indices = generate_eval_manifest(
        output,
        data_root=data_root,
        image_size=args.image_size,
        categories=categories,
        per_category=args.per_category,
        seed=args.seed,
    )
    print(
        f"已写入 {output}\n"
        f"  data_root={data_root}\n"
        f"  categories={categories}\n"
        f"  per_category={args.per_category}\n"
        f"  total={total} (indices={len(indices)})",
        flush=True,
    )


if __name__ == "__main__":
    main()
