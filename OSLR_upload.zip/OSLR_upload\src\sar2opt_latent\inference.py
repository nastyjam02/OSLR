"""Latent / LDM 单张推理。"""

from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import torch

from latent_infer import TTA_CHOICES, resolve_tta_views, sample_conditional_eo_tta
from model_ldm import DEFAULT_LDM_MODEL_ID, load_model_from_checkpoint
from preprocess import load_sar_rgb_vae
from scheduler_utils import SCHEDULER_CHOICES, build_inference_scheduler, run_subdir_name
from vae_utils import DEFAULT_VAE_MODEL_ID, latent_spatial_size, load_frozen_vae

PACKAGE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = PACKAGE_DIR.parent
DEFAULT_CKPT = PROJECT_ROOT / "checkpoints" / "sar2opt_latent" / "model_step_5000_final.pth"
DEFAULT_OUT = PROJECT_ROOT / "outputs" / "sar2opt_latent" / "generated_optical.png"


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", default=str(DEFAULT_CKPT))
    p.add_argument("--sar-path", required=True)
    p.add_argument("--output", default=str(DEFAULT_OUT))
    p.add_argument("--vae-model-id", default=DEFAULT_VAE_MODEL_ID)
    p.add_argument(
        "--model-type",
        choices=("auto", "latent", "ldm"),
        default="auto",
        help="auto 从 checkpoint args 读取。",
    )
    p.add_argument("--ldm-model-id", default=DEFAULT_LDM_MODEL_ID)
    p.add_argument("--prompt", default=None, help="LDM 文本条件；默认与训练 checkpoint 一致。")
    p.add_argument(
        "--guidance-scale",
        type=float,
        default=1.0,
        help="LDM text CFG 强度；>1 启用，<=1 与旧行为一致。",
    )
    p.add_argument("--image-size", type=int, default=256)
    p.add_argument("--num-diffusion-steps", type=int, default=1000)
    p.add_argument("--num-inference-steps", type=int, default=50)
    p.add_argument("--scheduler", default="ddim", choices=SCHEDULER_CHOICES)
    p.add_argument("--seed", type=int, default=None)
    p.add_argument(
        "--tta",
        default="none",
        choices=TTA_CHOICES,
        help="几何 TTA：none=关闭；flip=原图+水平翻转；geo4=4 视图 dihedral 子集。",
    )
    return p.parse_args()


def save_rgb(path: Path, tensor_chw: torch.Tensor):
    path.parent.mkdir(parents=True, exist_ok=True)
    x = ((tensor_chw + 1.0) / 2.0).clamp(0, 1).permute(1, 2, 0).cpu().numpy()
    x = (x * 255).astype("uint8")
    bgr = cv2.cvtColor(x, cv2.COLOR_RGB2BGR)
    if not cv2.imwrite(str(path), bgr):
        raise RuntimeError(f"保存失败: {path}")


def main():
    args = parse_args()
    if args.seed is not None:
        torch.manual_seed(args.seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(args.seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    ckpt = Path(args.checkpoint).resolve()
    if not ckpt.is_file():
        raise FileNotFoundError(ckpt)

    latent_size = latent_spatial_size(args.image_size)
    model, prompt_embeds, uncond_prompt_embeds, model_type = load_model_from_checkpoint(
        ckpt,
        device,
        model_type=args.model_type,
        ldm_model_id=args.ldm_model_id,
        latent_size=latent_size,
        prompt=args.prompt,
    )
    print(f"已加载模型: {model_type} | {ckpt}")
    if args.guidance_scale > 1.0 and uncond_prompt_embeds is not None:
        print(f"text CFG: guidance_scale={args.guidance_scale}")

    vae = load_frozen_vae(args.vae_model_id, device=device)
    scheduler = build_inference_scheduler(
        args.scheduler,
        args.num_diffusion_steps,
        args.num_inference_steps,
        device,
    )

    sar = load_sar_rgb_vae(args.sar_path, args.image_size).to(device)
    tta_views = resolve_tta_views(args.tta)
    if len(tta_views) > 1:
        print(f"几何 TTA: {args.tta} -> {tta_views}")
    with torch.no_grad():
        out = sample_conditional_eo_tta(
            model,
            vae,
            scheduler,
            sar,
            latent_size,
            prompt_embeds=prompt_embeds,
            uncond_prompt_embeds=uncond_prompt_embeds,
            guidance_scale=args.guidance_scale,
            tta=args.tta,
        )

    out_path = Path(args.output).expanduser().resolve()
    run_name = run_subdir_name(args.scheduler, args.num_inference_steps)
    tta_tag = f"tta_{args.tta}" if args.tta != "none" else None
    if out_path.suffix:
        parent = out_path.parent / run_name
        if tta_tag:
            parent = parent / tta_tag
        final_path = parent / out_path.name
    else:
        parent = out_path / run_name
        if tta_tag:
            parent = parent / tta_tag
        final_path = parent / "generated_optical.png"
    final_path.parent.mkdir(parents=True, exist_ok=True)
    save_rgb(final_path, out[0])
    print(f"已保存: {final_path}")


if __name__ == "__main__":
    main()
