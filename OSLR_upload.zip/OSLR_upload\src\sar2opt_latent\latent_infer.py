"""Latent 条件采样：z_T ~ N(0,I)，以 z_x 为条件逐步去噪后 VAE 解码。"""

from __future__ import annotations

from typing import Sequence

import torch

from model_ldm import expand_prompt_embeds
from scheduler_utils import reset_inference_scheduler
from vae_utils import decode_latents, encode_images, encode_sar_images

# 几何 TTA 预设：均为自逆变换（再做一次即还原）
TTA_PRESETS: dict[str, tuple[str, ...]] = {
    "none": ("id",),
    "flip": ("id", "hflip"),
    "geo4": ("id", "hflip", "rot180", "hflip_rot180"),
}
TTA_CHOICES = tuple(TTA_PRESETS.keys())


def resolve_tta_views(tta: str | Sequence[str] | None) -> tuple[str, ...]:
    """解析 --tta 预设名或显式视图列表。"""
    if tta is None or tta == "" or tta == "none":
        return TTA_PRESETS["none"]
    if isinstance(tta, str):
        key = tta.strip().lower()
        if key in TTA_PRESETS:
            return TTA_PRESETS[key]
        raise ValueError(f"未知 TTA 预设: {tta!r}，可选: {list(TTA_PRESETS)}")
    views = tuple(tta)
    if not views:
        raise ValueError("TTA views 不能为空")
    for name in views:
        apply_geom(torch.zeros(1, 1, 2, 2), name)  # 校验名称
    return views


def apply_geom(x: torch.Tensor, name: str) -> torch.Tensor:
    """对 [B,C,H,W] 做几何变换。"""
    if name == "id":
        return x
    if name == "hflip":
        return torch.flip(x, dims=[-1])
    if name == "vflip":
        return torch.flip(x, dims=[-2])
    if name == "rot180":
        return torch.rot90(x, k=2, dims=[-2, -1])
    if name == "hflip_rot180":
        return torch.rot90(torch.flip(x, dims=[-1]), k=2, dims=[-2, -1])
    raise ValueError(f"未知几何变换: {name!r}")


def invert_geom(x: torch.Tensor, name: str) -> torch.Tensor:
    """当前预设变换均为自逆。"""
    return apply_geom(x, name)


def _expand_timesteps(timesteps: torch.Tensor | int, batch_size: int, device: torch.device) -> torch.Tensor:
    if not isinstance(timesteps, torch.Tensor):
        timesteps = torch.tensor([timesteps], device=device, dtype=torch.long)
    else:
        timesteps = timesteps.to(device=device, dtype=torch.long)
    if timesteps.ndim == 0:
        return timesteps.expand(batch_size)
    if timesteps.shape[0] == 1:
        return timesteps.expand(batch_size)
    if timesteps.shape[0] == batch_size:
        return timesteps
    raise ValueError(
        f"timesteps batch ({timesteps.shape[0]}) 与 model_input batch ({batch_size}) 不匹配"
    )


def predict_latent_noise(
    model,
    model_input: torch.Tensor,
    timesteps: torch.Tensor,
    prompt_embeds: torch.Tensor | None,
) -> torch.Tensor:
    """P0 UNet2DModel 或 P1 UNet2DConditionModel 统一噪声预测。"""
    bsz = model_input.shape[0]
    if prompt_embeds is not None:
        encoder_hidden_states = expand_prompt_embeds(prompt_embeds, bsz)
        return model(
            model_input,
            timesteps,
            encoder_hidden_states=encoder_hidden_states,
        ).sample
    return model(model_input, timesteps).sample


def predict_latent_noise_cfg(
    model,
    model_input: torch.Tensor,
    timesteps: torch.Tensor,
    prompt_embeds: torch.Tensor,
    uncond_prompt_embeds: torch.Tensor,
    guidance_scale: float = 1.0,
) -> torch.Tensor:
    """Text CFG：ε = ε_uncond + w * (ε_cond - ε_uncond)。"""
    if guidance_scale <= 1.0:
        return predict_latent_noise(model, model_input, timesteps, prompt_embeds)

    bsz = model_input.shape[0]
    device = model_input.device
    model_input_2 = torch.cat([model_input, model_input], dim=0)
    t2 = torch.cat(
        [
            _expand_timesteps(timesteps, bsz, device),
            _expand_timesteps(timesteps, bsz, device),
        ],
        dim=0,
    )
    embeds_2 = torch.cat(
        [
            expand_prompt_embeds(uncond_prompt_embeds, bsz),
            expand_prompt_embeds(prompt_embeds, bsz),
        ],
        dim=0,
    )
    noise_2 = predict_latent_noise(model, model_input_2, t2, embeds_2)
    noise_uncond, noise_cond = noise_2.chunk(2, dim=0)
    return noise_uncond + guidance_scale * (noise_cond - noise_uncond)


@torch.no_grad()
def sample_conditional_eo(
    model,
    vae,
    scheduler,
    sar_3ch: torch.Tensor,
    latent_size: int,
    prompt_embeds: torch.Tensor | None = None,
    uncond_prompt_embeds: torch.Tensor | None = None,
    guidance_scale: float = 1.0,
    sar_vae: torch.nn.Module | None = None,
    init_noise: torch.Tensor | None = None,
) -> torch.Tensor:
    """
    :param sar_3ch: [B, 3, H, W]，已与训练时 vae 归一化一致
    :param prompt_embeds: LDM 时 [1, seq, dim]；P0 传 None
    :param uncond_prompt_embeds: LDM text CFG 无条件 embedding；P0 传 None
    :param guidance_scale: text CFG 强度；<=1 时不启用 CFG
    :param sar_vae: 自研的单通道 VAE 编码器（若有）
    :param init_noise: 可选初始 latent 噪声 [B,4,H,W]；None 则随机采样
    :return: 生成 EO RGB，[B, 3, H, W]，约 [-1, 1]
    """
    device = sar_3ch.device
    dtype = sar_3ch.dtype

    if sar_vae is not None:
        z_x = encode_sar_images(sar_vae, sar_3ch)
    else:
        z_x = encode_images(vae, sar_3ch)

    bsz = sar_3ch.shape[0]
    if init_noise is None:
        z = torch.randn(bsz, 4, latent_size, latent_size, device=device, dtype=dtype)
    else:
        if init_noise.shape != (bsz, 4, latent_size, latent_size):
            raise ValueError(
                f"init_noise shape {tuple(init_noise.shape)} != "
                f"({bsz}, 4, {latent_size}, {latent_size})"
            )
        z = init_noise.to(device=device, dtype=dtype)

    use_cfg = (
        prompt_embeds is not None
        and uncond_prompt_embeds is not None
        and guidance_scale > 1.0
    )

    reset_inference_scheduler(scheduler)
    for t in scheduler.timesteps:
        model_input = torch.cat([z, z_x], dim=1)
        if use_cfg:
            noise_pred = predict_latent_noise_cfg(
                model,
                model_input,
                t,
                prompt_embeds,
                uncond_prompt_embeds,
                guidance_scale=guidance_scale,
            )
        else:
            noise_pred = predict_latent_noise(model, model_input, t, prompt_embeds)
        z = scheduler.step(noise_pred, t, z).prev_sample

    return decode_latents(vae, z)


@torch.no_grad()
def sample_conditional_eo_tta(
    model,
    vae,
    scheduler,
    sar_3ch: torch.Tensor,
    latent_size: int,
    prompt_embeds: torch.Tensor | None = None,
    uncond_prompt_embeds: torch.Tensor | None = None,
    guidance_scale: float = 1.0,
    sar_vae: torch.nn.Module | None = None,
    tta: str | Sequence[str] | None = "none",
    init_noise: torch.Tensor | None = None,
) -> torch.Tensor:
    """几何 TTA：对 SAR（及初始噪声）做翻转/旋转，推理后逆变换再像素平均。

    :param tta: 预设名 none/flip/geo4，或显式视图名序列
    :param init_noise: 共享初始噪声；None 时在本函数内采样一次并复用到各视图
    """
    views = resolve_tta_views(tta)
    if views == ("id",):
        return sample_conditional_eo(
            model,
            vae,
            scheduler,
            sar_3ch,
            latent_size,
            prompt_embeds=prompt_embeds,
            uncond_prompt_embeds=uncond_prompt_embeds,
            guidance_scale=guidance_scale,
            sar_vae=sar_vae,
            init_noise=init_noise,
        )

    device = sar_3ch.device
    dtype = sar_3ch.dtype
    bsz = sar_3ch.shape[0]
    if init_noise is None:
        z0 = torch.randn(bsz, 4, latent_size, latent_size, device=device, dtype=dtype)
    else:
        if init_noise.shape != (bsz, 4, latent_size, latent_size):
            raise ValueError(
                f"init_noise shape {tuple(init_noise.shape)} != "
                f"({bsz}, 4, {latent_size}, {latent_size})"
            )
        z0 = init_noise.to(device=device, dtype=dtype)

    acc: torch.Tensor | None = None
    for name in views:
        sar_v = apply_geom(sar_3ch, name)
        z0_v = apply_geom(z0, name)
        opt_v = sample_conditional_eo(
            model,
            vae,
            scheduler,
            sar_v,
            latent_size,
            prompt_embeds=prompt_embeds,
            uncond_prompt_embeds=uncond_prompt_embeds,
            guidance_scale=guidance_scale,
            sar_vae=sar_vae,
            init_noise=z0_v,
        )
        opt = invert_geom(opt_v, name)
        acc = opt if acc is None else acc + opt
    assert acc is not None
    return acc / float(len(views))
