"""P0：在 VAE latent 上的条件 U-Net（8→4）。"""

from __future__ import annotations

import torch.nn as nn
from diffusers import UNet2DModel


def build_latent_unet(latent_size: int = 32) -> UNet2DModel:
    return UNet2DModel(
        sample_size=latent_size,
        in_channels=8,
        out_channels=4,
        layers_per_block=2,
        block_out_channels=(128, 128, 256, 256, 512, 512),
        down_block_types=(
            "DownBlock2D",
            "DownBlock2D",
            "DownBlock2D",
            "DownBlock2D",
            "AttnDownBlock2D",
            "DownBlock2D",
        ),
        up_block_types=(
            "UpBlock2D",
            "AttnUpBlock2D",
            "UpBlock2D",
            "UpBlock2D",
            "UpBlock2D",
            "UpBlock2D",
        ),
    )
