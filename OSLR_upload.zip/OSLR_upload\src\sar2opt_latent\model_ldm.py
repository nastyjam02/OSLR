"""P1：SD2.1 UNet2DConditionModel + 8 通道 SAR 拼接 + 冻结文本编码（默认可为空 prompt）。"""

from __future__ import annotations

from pathlib import Path

import torch
import torch.nn as nn
from diffusers import UNet2DConditionModel
from transformers import CLIPTextModel, CLIPTokenizer

from vae_utils import DEFAULT_VAE_MODEL_ID

# 与 VAE 共用本地 diffusers 布局：sd21_base_mirror/{vae,unet,text_encoder,tokenizer}/
DEFAULT_LDM_MODEL_ID = DEFAULT_VAE_MODEL_ID

MODEL_TYPE_LDM = "ldm_p1"
DEFAULT_PROMPT = ""
DEFAULT_UNCOND_PROMPT = ""


def expand_unet_in_channels(unet: UNet2DConditionModel, extra_in_channels: int = 4) -> UNet2DConditionModel:
    """
    将 conv_in 从 4 扩到 4+extra（默认 8），用于 cat([z_y^t, z_x])。
    前 4 通道保留预训练权重；新增通道拷贝前 4 通道（C-DiffSET §4.2）。
    """
    old_conv = unet.conv_in
    if old_conv.in_channels == 4 + extra_in_channels:
        return unet

    new_in = old_conv.in_channels + extra_in_channels
    new_conv = nn.Conv2d(
        new_in,
        old_conv.out_channels,
        kernel_size=old_conv.kernel_size,
        stride=old_conv.stride,
        padding=old_conv.padding,
        bias=old_conv.bias is not None,
    )
    with torch.no_grad():
        new_conv.weight.zero_()
        new_conv.weight[:, : old_conv.in_channels].copy_(old_conv.weight)
        new_conv.weight[:, old_conv.in_channels :].copy_(old_conv.weight)
        if old_conv.bias is not None:
            new_conv.bias.copy_(old_conv.bias)

    unet.conv_in = new_conv
    unet.register_to_config(in_channels=new_in)
    return unet


@torch.no_grad()
def encode_prompt(
    text_encoder: CLIPTextModel,
    tokenizer: CLIPTokenizer,
    prompt: str | list[str],
    device: torch.device,
    dtype: torch.dtype,
) -> torch.Tensor:
    """返回 [B, seq_len, hidden]，供 UNet cross-attention 使用。"""
    if isinstance(prompt, str):
        prompt = [prompt]

    text_inputs = tokenizer(
        prompt,
        padding="max_length",
        max_length=tokenizer.model_max_length,
        truncation=True,
        return_tensors="pt",
    )
    input_ids = text_inputs.input_ids.to(device)
    prompt_embeds = text_encoder(input_ids)[0]
    return prompt_embeds.to(dtype=dtype)


def _repo_root(model_id: str) -> Path:
    return Path(model_id).expanduser().resolve()


def _remap_text_encoder_state(state: dict) -> dict:
    """diffusers/OpenCLIP 导出带 text_model. 前缀，需对齐 transformers CLIPTextModel。"""
    remapped: dict = {}
    for key, value in state.items():
        if key.startswith("text_model."):
            key = key[len("text_model.") :]
        if key == "embeddings.position_ids":
            continue
        remapped[key] = value
    return remapped


def _load_text_encoder_weights(text_encoder: CLIPTextModel, te_dir: Path) -> None:
    """兼容 Manojb 镜像中的 model.fp16.safetensors 等命名。"""
    candidates = (
        "model.safetensors",
        "model.fp16.safetensors",
        "pytorch_model.bin",
        "pytorch_model.fp16.bin",
    )
    weight_path = next((te_dir / n for n in candidates if (te_dir / n).is_file()), None)
    if weight_path is None:
        raise FileNotFoundError(
            f"text_encoder 目录缺少权重文件（尝试过 {candidates}）: {te_dir}"
        )
    if weight_path.suffix == ".safetensors":
        from safetensors.torch import load_file

        state = load_file(str(weight_path))
    else:
        state = torch.load(weight_path, map_location="cpu", weights_only=True)
    state = _remap_text_encoder_state(state)
    text_encoder.load_state_dict(state)


def load_frozen_text_encoder(
    model_id: str = DEFAULT_LDM_MODEL_ID,
    device: torch.device | str | None = None,
    dtype: torch.dtype = torch.float32,
) -> tuple[CLIPTextModel, CLIPTokenizer]:
    root = _repo_root(model_id)
    te_dir = root / "text_encoder"
    try:
        text_encoder = CLIPTextModel.from_pretrained(te_dir, local_files_only=True)
    except OSError:
        config = CLIPTextModel.config_class.from_pretrained(te_dir, local_files_only=True)
        text_encoder = CLIPTextModel(config)
        _load_text_encoder_weights(text_encoder, te_dir)
    tokenizer = CLIPTokenizer.from_pretrained(root / "tokenizer", local_files_only=True)
    text_encoder.requires_grad_(False)
    text_encoder.eval()
    if device is not None:
        text_encoder = text_encoder.to(device=device, dtype=dtype)
    return text_encoder, tokenizer


def build_ldm_unet(
    model_id: str = DEFAULT_LDM_MODEL_ID,
    device: torch.device | str | None = None,
    dtype: torch.dtype = torch.float32,
    prompt: str = DEFAULT_PROMPT,
    uncond_prompt: str = DEFAULT_UNCOND_PROMPT,
    extra_in_channels: int = 4,
) -> tuple[UNet2DConditionModel, torch.Tensor, torch.Tensor]:
    """
    加载 SD2.1 U-Net、扩 8 通道输入，并缓存 cond / uncond prompt 的 text embedding。

    :return: (unet, prompt_embeds, uncond_prompt_embeds)，形状均为 [1, 77, cross_attention_dim]
    """
    root = _repo_root(model_id)
    unet = UNet2DConditionModel.from_pretrained(root / "unet")
    unet = expand_unet_in_channels(unet, extra_in_channels=extra_in_channels)

    if device is not None:
        unet = unet.to(device=device, dtype=dtype)

    text_encoder, tokenizer = load_frozen_text_encoder(model_id, device=device, dtype=dtype)
    dev = device if device is not None else torch.device("cpu")
    prompt_embeds = encode_prompt(text_encoder, tokenizer, prompt, dev, dtype)
    uncond_prompt_embeds = encode_prompt(text_encoder, tokenizer, uncond_prompt, dev, dtype)

    # 释放 text_encoder 引用；推理/训练仅保留缓存的 embedding
    del text_encoder, tokenizer

    return unet, prompt_embeds, uncond_prompt_embeds


def expand_prompt_embeds(prompt_embeds: torch.Tensor, batch_size: int) -> torch.Tensor:
    """[1, seq, dim] -> [B, seq, dim]"""
    if prompt_embeds.shape[0] == batch_size:
        return prompt_embeds
    return prompt_embeds.expand(batch_size, -1, -1)


def select_training_prompt_embeds(
    prompt_embeds: torch.Tensor,
    uncond_prompt_embeds: torch.Tensor,
    batch_size: int,
    cond_dropout_prob: float,
    device: torch.device,
) -> torch.Tensor:
    """Per-sample text CFG dropout，返回 [B, seq, dim]。"""
    cond = expand_prompt_embeds(prompt_embeds, batch_size)
    if cond_dropout_prob <= 0.0:
        return cond

    uncond = expand_prompt_embeds(uncond_prompt_embeds, batch_size)
    drop_mask = torch.rand(batch_size, device=device) < cond_dropout_prob
    return torch.where(drop_mask.view(-1, 1, 1), uncond, cond)


def resolve_ldm_model_id(model_id: str | None) -> str:
    path = _repo_root(model_id or DEFAULT_LDM_MODEL_ID)
    if not path.is_dir():
        raise FileNotFoundError(f"LDM 模型目录不存在: {path}")
    for sub in ("unet", "text_encoder", "tokenizer"):
        if not (path / sub).is_dir():
            raise FileNotFoundError(f"缺少子目录 {sub}/，请补全 SD2.1 权重: {path}")
    return str(path)


def is_ldm_model_type(model_type: str | None) -> bool:
    if not model_type:
        return False
    return model_type.startswith("ldm")


def checkpoint_model_type(state: dict) -> str:
    if isinstance(state, dict) and "args" in state and isinstance(state["args"], dict):
        return str(state["args"].get("model_type", "latent_p0"))
    return "latent_p0"


def load_model_from_checkpoint(
    checkpoint_path: str | Path,
    device: torch.device,
    *,
    model_type: str | None = None,
    ldm_model_id: str = DEFAULT_LDM_MODEL_ID,
    latent_size: int = 32,
    prompt: str | None = None,
) -> tuple[torch.nn.Module, torch.Tensor | None, torch.Tensor | None, str]:
    """
  从 checkpoint 加载 P0 或 LDM 模型。

  :return: (model, prompt_embeds_or_none, uncond_prompt_embeds_or_none, resolved_model_type)
  """
    from model_latent import build_latent_unet

    ckpt_path = Path(checkpoint_path).resolve()
    state = torch.load(ckpt_path, map_location=device, weights_only=False)
    ckpt_type = checkpoint_model_type(state)

    if model_type in (None, "auto"):
        resolved = ckpt_type
    elif model_type == "ldm":
        resolved = MODEL_TYPE_LDM
    elif model_type == "latent":
        resolved = "latent_p0"
    else:
        resolved = model_type

    weight = state["model"] if isinstance(state, dict) and "model" in state else state
    ckpt_args = state.get("args", {}) if isinstance(state, dict) else {}
    use_ldm = is_ldm_model_type(resolved)

    if use_ldm:
        prompt_str = prompt if prompt is not None else str(ckpt_args.get("prompt", DEFAULT_PROMPT))
        ldm_id = str(ckpt_args.get("ldm_model_id", ldm_model_id))
        model, prompt_embeds, uncond_prompt_embeds = build_ldm_unet(
            model_id=resolve_ldm_model_id(ldm_id),
            device=device,
            prompt=prompt_str,
        )
        model.load_state_dict(weight)
        model.eval()
        return model, prompt_embeds, uncond_prompt_embeds, MODEL_TYPE_LDM

    model = build_latent_unet(latent_size=latent_size).to(device)
    model.load_state_dict(weight)
    model.eval()
    return model, None, None, "latent_p0"
