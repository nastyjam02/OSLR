"""与 dataset 一致的 SAR 读取与 vae 归一化，供推理复用。"""

from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np
import torch


def _resize_if_needed(img: np.ndarray, image_size: int) -> np.ndarray:
    h, w = img.shape[:2]
    if h == image_size and w == image_size:
        return img
    return cv2.resize(img, (image_size, image_size), interpolation=cv2.INTER_AREA)


def _vae_normalize_gray(gray_f32: np.ndarray) -> np.ndarray:
    gmax = float(gray_f32.max()) if gray_f32.size else 1.0
    denom = 127.5 if gmax <= 255.0 else max(gmax / 2.0, 1e-6)
    return np.clip(gray_f32 / denom - 1.0, -1.0, 1.0).astype(np.float32)


def load_sar_rgb_vae(sar_path: str | Path, image_size: int) -> torch.Tensor:
    """
    读取 SAR，repeat3 + vae 归一化，返回 [1, 3, H, W] float。
    """
    sar_path = Path(sar_path)
    sar_img = cv2.imread(str(sar_path), cv2.IMREAD_UNCHANGED)
    if sar_img is None:
        raise ValueError(f"无法读取 SAR: {sar_path}")
    sar_img = sar_img.astype(np.float32)
    if len(sar_img.shape) > 2:
        sar_img = np.mean(sar_img, axis=2)
    sar_img = _resize_if_needed(sar_img, image_size)
    sar_gray_norm = _vae_normalize_gray(sar_img)
    sar_rgb = np.stack([sar_gray_norm] * 3, axis=0)
    return torch.from_numpy(sar_rgb).float().unsqueeze(0)
