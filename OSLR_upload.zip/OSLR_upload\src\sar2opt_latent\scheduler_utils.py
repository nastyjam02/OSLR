"""训练一致的扩散日程上，构建推理用采样器。"""

from __future__ import annotations

import re

import torch
from diffusers import (
    DDIMScheduler,
    DDPMScheduler,
    DEISMultistepScheduler,
    DPMSolverMultistepScheduler,
    UniPCMultistepScheduler,
)

SCHEDULER_CHOICES = (
    "ddpm",
    "ddim",
    "dpm-solver++",
    "dpm-solver++-trailing",
    "dpm-solver++-karras",
    "unipc",
    "deis",
)


def normalize_scheduler_name(name: str) -> str:
    key = name.strip().lower()
    if key not in SCHEDULER_CHOICES:
        allowed = ", ".join(SCHEDULER_CHOICES)
        raise ValueError(f"未知 scheduler: {name!r}，可选: {allowed}")
    return key


# 复合 DPM++ 变体用可读子目录名；默认 dpm-solver++ 仍走正则，保持与 A1 的 dpm-solver__N 一致。
_SUBDIR_ALIASES = {
    "dpm-solver++-trailing": "dpm-solver-trailing",
    "dpm-solver++-karras": "dpm-solver-karras",
}


def run_subdir_name(scheduler: str, num_inference_steps: int) -> str:
    sched = normalize_scheduler_name(scheduler)
    safe = _SUBDIR_ALIASES.get(sched) or re.sub(r"[^a-zA-Z0-9._-]+", "_", sched)
    return f"{safe}_{int(num_inference_steps)}"


def build_inference_scheduler(
    scheduler_name: str,
    num_train_timesteps: int,
    num_inference_steps: int,
    device: torch.device,
):
    sched = normalize_scheduler_name(scheduler_name)
    train_sched = DDPMScheduler(num_train_timesteps=num_train_timesteps)

    if sched == "ddpm":
        scheduler = train_sched
    elif sched == "ddim":
        scheduler = DDIMScheduler.from_config(train_sched.config, clip_sample=False)
    elif sched == "dpm-solver++":
        scheduler = DPMSolverMultistepScheduler.from_config(train_sched.config)
    elif sched == "dpm-solver++-trailing":
        scheduler = DPMSolverMultistepScheduler.from_config(
            train_sched.config,
            timestep_spacing="trailing",
        )
    elif sched == "dpm-solver++-karras":
        scheduler = DPMSolverMultistepScheduler.from_config(
            train_sched.config,
            use_karras_sigmas=True,
        )
    elif sched == "unipc":
        scheduler = UniPCMultistepScheduler.from_config(train_sched.config)
    elif sched == "deis":
        scheduler = DEISMultistepScheduler.from_config(train_sched.config)
    else:
        raise AssertionError(sched)

    try:
        scheduler.set_timesteps(num_inference_steps, device=device)
    except TypeError:
        scheduler.set_timesteps(num_inference_steps)
        if hasattr(scheduler.timesteps, "to"):
            scheduler.timesteps = scheduler.timesteps.to(device)

    return scheduler


def reset_inference_scheduler(scheduler) -> None:
    """每次采样前重置内部步计数；evaluate 多 batch 复用同一 scheduler 时必须调用。"""
    n = getattr(scheduler, "num_inference_steps", None)
    if n is None:
        timesteps = getattr(scheduler, "timesteps", None)
        if timesteps is None:
            return
        n = len(timesteps)
    device = getattr(getattr(scheduler, "timesteps", None), "device", None)
    try:
        if device is not None:
            scheduler.set_timesteps(n, device=device)
        else:
            scheduler.set_timesteps(n)
    except TypeError:
        scheduler.set_timesteps(n)
        if device is not None and hasattr(scheduler.timesteps, "to"):
            scheduler.timesteps = scheduler.timesteps.to(device)
