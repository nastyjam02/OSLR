"""
冻结 VAE + latent DDPM + SAR latent 通道拼接。
支持 --model-type latent（P0）与 ldm（P1 SD U-Net）。
"""

from __future__ import annotations

import argparse
import random
import time
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from diffusers import DDPMScheduler
from torch.optim import AdamW
from torch.utils.data import DataLoader
from transformers import get_cosine_schedule_with_warmup

from dataset import SAROpticalDataset
from latent_infer import predict_latent_noise
from model_latent import build_latent_unet
from model_ldm import (
    DEFAULT_LDM_MODEL_ID,
    DEFAULT_PROMPT,
    MODEL_TYPE_LDM,
    build_ldm_unet,
)
from val_monitor import (
    load_or_create_val_indices,
    make_val_dataloader,
    resolve_val_categories,
    run_val_monitor,
)
from vae_utils import (
    DEFAULT_VAE_MODEL_ID,
    encode_images,
    latent_spatial_size,
    load_frozen_vae,
    load_custom_sar_vae,
    encode_sar_images,
)

PACKAGE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = PACKAGE_DIR.parent
DEFAULT_DATA_ROOT = PROJECT_ROOT / "archive" / "splits" / "train"
DEFAULT_CHECKPOINT_DIR = PROJECT_ROOT / "checkpoints" / "sar2opt_latent"
DEFAULT_CHECKPOINT_DIR_LDM = PROJECT_ROOT / "checkpoints" / "sar2opt_ldm"
DEFAULT_VAL_DATA_ROOT = PROJECT_ROOT / "archive" / "splits" / "test"


def parse_args():
    p = argparse.ArgumentParser(description="sar2opt_latent 训练（P0 latent / P1 ldm）")
    p.add_argument(
        "--model-type",
        choices=("latent", "ldm"),
        default="latent",
        help="latent=P0 小 U-Net；ldm=P1 SD UNet2DConditionModel。",
    )
    p.add_argument("--data-root", default=str(DEFAULT_DATA_ROOT))
    p.add_argument("--checkpoint-dir", default=None)
    p.add_argument("--resume", default=None)
    p.add_argument(
        "--init-from-model",
        default=None,
        help="只加载模型权重作为 fine-tune 起点，不恢复 optimizer/lr_scheduler/global_step。",
    )
    p.add_argument(
        "--vae-model-id",
        default=DEFAULT_VAE_MODEL_ID,
        help="含 vae/ 子目录的 diffusers 模型 ID 或本地目录；默认 sar2opt_latent/sd21_base_mirror。",
    )
    p.add_argument(
        "--ldm-model-id",
        default=DEFAULT_LDM_MODEL_ID,
        help="含 unet/text_encoder/tokenizer 的本地目录；ldm 时使用。",
    )
    p.add_argument(
        "--prompt",
        default=DEFAULT_PROMPT,
        help="LDM 固定文本条件；默认空字符串（暂无语义 prompt）。",
    )
    p.add_argument("--image-size", type=int, default=256)
    p.add_argument("--batch-size", type=int, default=12)
    p.add_argument("--num-workers", type=int, default=4)
    p.add_argument("--learning-rate", type=float, default=None)
    p.add_argument("--num-train-steps", type=int, default=5000)
    p.add_argument("--num-diffusion-steps", type=int, default=1000)
    p.add_argument(
        "--x0-loss-weight",
        type=float,
        default=0.0,
        help="z0 latent L1 辅助损失权重；0 表示保持纯噪声 MSE。",
    )
    p.add_argument("--warmup-steps", type=int, default=100)
    p.add_argument("--log-every", type=int, default=20)
    p.add_argument("--save-every", type=int, default=500)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--use-swanlab", action="store_true")
    p.add_argument("--swanlab-project", type=str, default="sar2opt_latent")
    p.add_argument("--swanlab-experiment", type=str, default=None)
    p.add_argument(
        "--swanlab-mode",
        type=str,
        default="cloud",
        choices=("cloud", "local", "offline", "disabled"),
    )
    p.add_argument("--swanlab-logdir", type=str, default=None)
    p.add_argument("--no-val", action="store_true", help="关闭训练期 test 子集 SSIM 监控。")
    p.add_argument("--val-data-root", default=str(DEFAULT_VAL_DATA_ROOT))
    p.add_argument(
        "--val-categories",
        default="agri,barrenland,grassland,urban",
        help="逗号分隔；每类抽相同张数。",
    )
    p.add_argument("--val-per-category", type=int, default=10)
    p.add_argument("--val-batch-size", type=int, default=4)
    p.add_argument("--val-scheduler", default="ddim")
    p.add_argument("--val-inference-steps", type=int, default=50)
    p.add_argument("--val-seed", type=int, default=42)
    p.add_argument(
        "--val-every",
        type=int,
        default=0,
        help="验证频率；0 表示与 --save-every 相同。",
    )
    p.add_argument(
        "--val-indices-file",
        default=None,
        help="固定 40 张索引 JSON；默认写在 checkpoint-dir/val_indices_test_40.json。",
    )
    p.add_argument(
        "--custom-sar-vae",
        default=None,
        help="自研单通道 SAR VAE checkpoint 权重路径（不为 None 时将替代 SD VAE 提取 z_sar 特征）。",
    )
    args = p.parse_args()
    if args.checkpoint_dir is None:
        args.checkpoint_dir = str(
            DEFAULT_CHECKPOINT_DIR_LDM if args.model_type == "ldm" else DEFAULT_CHECKPOINT_DIR
        )
    if args.learning_rate is None:
        args.learning_rate = 3e-5 if args.model_type == "ldm" else 1e-4
    return args


def resolved_model_type_tag(args) -> str:
    return MODEL_TYPE_LDM if args.model_type == "ldm" else "latent_p0"


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def save_checkpoint(path, model, optimizer, lr_scheduler, global_step, epoch, args):
    path.parent.mkdir(parents=True, exist_ok=True)
    d = vars(args).copy()
    d["model_type"] = resolved_model_type_tag(args)
    torch.save(
        {
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "lr_scheduler": lr_scheduler.state_dict(),
            "global_step": global_step,
            "epoch": epoch,
            "args": d,
        },
        path,
    )


def load_checkpoint(path, model, optimizer, lr_scheduler, device):
    ckpt = torch.load(path, map_location=device, weights_only=False)
    if "model" in ckpt:
        model.load_state_dict(ckpt["model"])
        optimizer.load_state_dict(ckpt["optimizer"])
        lr_scheduler.load_state_dict(ckpt["lr_scheduler"])
        return ckpt.get("global_step", 0), ckpt.get("epoch", 0)
    model.load_state_dict(ckpt)
    return 0, 0


def load_model_weights(path, model, device):
    ckpt = torch.load(path, map_location=device, weights_only=False)
    weight = ckpt["model"] if isinstance(ckpt, dict) and "model" in ckpt else ckpt
    model.load_state_dict(weight)


def _init_swanlab(args, data_root: Path, num_samples: int):
    import swanlab

    default_logdir = PROJECT_ROOT / "swanlog"
    logdir = Path(args.swanlab_logdir).expanduser() if args.swanlab_logdir else default_logdir
    logdir.mkdir(parents=True, exist_ok=True)
    config = {
        "package": "sar2opt_latent",
        "model_type": resolved_model_type_tag(args),
        "train_model_type": args.model_type,
        "ldm_model_id": args.ldm_model_id,
        "prompt": args.prompt,
        "data_root": str(data_root),
        "num_samples": num_samples,
        "vae_model_id": args.vae_model_id,
        "image_size": args.image_size,
        "batch_size": args.batch_size,
        "learning_rate": args.learning_rate,
        "num_train_steps": args.num_train_steps,
        "num_diffusion_steps": args.num_diffusion_steps,
        "x0_loss_weight": args.x0_loss_weight,
        "init_from_model": args.init_from_model,
        "warmup_steps": args.warmup_steps,
        "seed": args.seed,
        "val_data_root": str(Path(args.val_data_root).resolve()),
        "val_per_category": args.val_per_category,
        "val_scheduler": args.val_scheduler,
        "val_inference_steps": args.val_inference_steps,
        "val_seed": args.val_seed,
        "val_num_samples": args.val_per_category * len(resolve_val_categories(args.val_categories)),
    }
    kw = {
        "project": args.swanlab_project,
        "config": config,
        "mode": args.swanlab_mode,
        "logdir": str(logdir),
    }
    if args.swanlab_experiment:
        kw["experiment_name"] = args.swanlab_experiment
    swanlab.init(**kw)
    return swanlab


def _val_interval_steps(args) -> int:
    return args.val_every if args.val_every > 0 else args.save_every


def should_run_val(global_step: int, args) -> bool:
    if args.no_val:
        return False
    interval = _val_interval_steps(args)
    return global_step == 0 or (global_step > 0 and global_step % interval == 0)


def log_val_metrics(
    args,
    metrics: dict[str, float],
    global_step: int,
    swanlab_mod,
    elapsed_s: float,
):
    mean_ssim = metrics["val/mean_ssim"]
    n = int(metrics["val/num_samples"])
    print(
        f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | step={global_step} "
        f"val SSIM={mean_ssim:.4f} (n={n}, {args.val_scheduler}/{args.val_inference_steps}) "
        f"Δt={elapsed_s:.1f}s",
        flush=True,
    )
    if swanlab_mod is not None:
        payload = dict(metrics)
        payload["val/inference_steps"] = float(args.val_inference_steps)
        swanlab_mod.log(payload, step=global_step)


def run_validation(
    args,
    device,
    latent_size: int,
    model,
    vae,
    val_ctx: dict,
    global_step: int,
    swanlab_mod,
    prompt_embeds,
    sar_vae=None,
):
    t0 = time.perf_counter()
    metrics = run_val_monitor(
        model,
        vae,
        val_ctx["loader"],
        val_ctx["dataset"],
        val_ctx["indices"],
        device=device,
        latent_size=latent_size,
        num_diffusion_steps=args.num_diffusion_steps,
        val_scheduler=args.val_scheduler,
        val_inference_steps=args.val_inference_steps,
        val_seed=args.val_seed,
        prompt_embeds=prompt_embeds,
        sar_vae=sar_vae,
    )
    log_val_metrics(args, metrics, global_step, swanlab_mod, time.perf_counter() - t0)



def setup_val_context(args) -> dict | None:
    if args.no_val:
        return None
    val_root = Path(args.val_data_root).resolve()
    if not val_root.is_dir():
        raise NotADirectoryError(val_root)

    categories = resolve_val_categories(args.val_categories)
    indices_path = (
        Path(args.val_indices_file).expanduser().resolve()
        if args.val_indices_file
        else Path(args.checkpoint_dir).resolve() / "val_indices_test_40.json"
    )
    indices = load_or_create_val_indices(
        val_root,
        indices_path,
        image_size=args.image_size,
        categories=categories,
        per_category=args.val_per_category,
        seed=args.val_seed,
    )
    full_dataset, loader = make_val_dataloader(
        val_root,
        indices,
        image_size=args.image_size,
        batch_size=args.val_batch_size,
        num_workers=args.num_workers,
    )
    print(
        f"验证监控: {val_root} | {len(categories)} 类 × {args.val_per_category} = {len(indices)} 张 | "
        f"{args.val_scheduler}/{args.val_inference_steps} | 索引 {indices_path}",
        flush=True,
    )
    return {"dataset": full_dataset, "loader": loader, "indices": indices}


def train_loop(args, device, data_root, dataloader, vae, swanlab_mod, val_ctx, sar_vae=None):
    latent_size = latent_spatial_size(args.image_size)
    prompt_embeds = None
    if args.model_type == "ldm":
        print(f"构建 LDM U-Net: {args.ldm_model_id!r}, prompt={args.prompt!r}")
        model, prompt_embeds, uncond_prompt_embeds = build_ldm_unet(
            model_id=args.ldm_model_id,
            device=device,
            prompt=args.prompt,
        )
    else:
        model = build_latent_unet(latent_size=latent_size).to(device)
    noise_scheduler = DDPMScheduler(num_train_timesteps=args.num_diffusion_steps)
    optimizer = AdamW(model.parameters(), lr=args.learning_rate, betas=(0.9, 0.999))
    lr_scheduler = get_cosine_schedule_with_warmup(
        optimizer=optimizer,
        num_warmup_steps=args.warmup_steps,
        num_training_steps=args.num_train_steps,
    )

    global_step = 0
    start_epoch = 0
    if args.resume and args.init_from_model:
        raise ValueError("--resume 与 --init-from-model 不能同时使用")
    if args.resume:
        global_step, start_epoch = load_checkpoint(
            Path(args.resume).resolve(), model, optimizer, lr_scheduler, device
        )
        print(f"恢复 checkpoint: step={global_step}, epoch={start_epoch}")
    elif args.init_from_model:
        init_path = Path(args.init_from_model).resolve()
        load_model_weights(init_path, model, device)
        print(f"初始化模型权重: {init_path} (optimizer/lr_scheduler 从头开始)")

    vae.to(device)
    vae.eval()
    if sar_vae is not None:
        sar_vae.to(device)
        sar_vae.eval()

    phase = "LDM P1" if args.model_type == "ldm" else "latent P0"
    print(f"开始训练 ({phase})...")
    print(f"数据: {data_root}, 样本数: {len(dataloader.dataset)}")
    print(
        f"model_type={args.model_type}, latent_size={latent_size}, "
        f"T={args.num_diffusion_steps}, lr={args.learning_rate}, device={device}"
    )
    if sar_vae is not None:
        print(f"应用自研单通道 SAR VAE 编码条件特征 z_sar (z_x).")
    model.train()

    if val_ctx is not None and should_run_val(global_step, args):
        run_validation(
            args, device, latent_size, model, vae, val_ctx, global_step, swanlab_mod, prompt_embeds, sar_vae=sar_vae
        )

    train_t0 = time.perf_counter()
    last_log_t = train_t0
    epoch = start_epoch
    '''
    把配对 OPT/SAR 先经冻结 VAE 编成 z_y 与 z_x，
    只对 z_y 随机时间步加噪得到 z_y^t，U-Net 在 concat(z_y^t, z_x) 
    上预测噪声，用 MSE 对齐采样到的 ε，只反传更新 U-Net；
    学习率按 cosine+warmup 随 global_step 走，并周期性存盘。

    '''
    while global_step < args.num_train_steps:
        for _, (sar_imgs, opt_imgs) in enumerate(dataloader):
            sar_imgs = sar_imgs.to(device) #[B,3,H,W]，值域约 [-1,1]
            opt_imgs = opt_imgs.to(device)
            bsz = opt_imgs.shape[0]

            with torch.no_grad():
                z_y = encode_images(vae, opt_imgs)  # [B,4,h,w]（h=w=32）
                if sar_vae is not None:
                    z_x = encode_sar_images(sar_vae, sar_imgs)
                else:
                    z_x = encode_images(vae, sar_imgs)


            noise = torch.randn_like(z_y)
            timesteps = torch.randint(
                0,
                noise_scheduler.config.num_train_timesteps,
                (bsz,),
                device=device,
                dtype=torch.long,
            )
            z_y_t = noise_scheduler.add_noise(z_y, noise, timesteps)
            model_input = torch.cat([z_y_t, z_x], dim=1)
            noise_pred = predict_latent_noise(model, model_input, timesteps, prompt_embeds)
            noise_loss = F.mse_loss(noise_pred, noise)
            x0_loss = noise_loss.new_zeros(())
            if args.x0_loss_weight > 0:
                alpha_prod_t = noise_scheduler.alphas_cumprod.to(
                    device=device, dtype=z_y_t.dtype
                )[timesteps]
                alpha_prod_t = alpha_prod_t.view(-1, 1, 1, 1)
                beta_prod_t = 1 - alpha_prod_t
                z0_pred = (z_y_t - beta_prod_t.sqrt() * noise_pred) / alpha_prod_t.sqrt()
                x0_loss = F.l1_loss(z0_pred, z_y)
            loss = noise_loss + args.x0_loss_weight * x0_loss

            loss.backward()
            optimizer.step()
            lr_scheduler.step()
            optimizer.zero_grad()

            global_step += 1

            if global_step % args.log_every == 0 or global_step == 1:
                now = time.perf_counter()
                wall = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                since_last = now - last_log_t
                last_log_t = now
                print(
                    f"{wall} | step={global_step} loss={loss.item():.4f} "
                    f"(noise={noise_loss.item():.4f}, x0={x0_loss.item():.4f}) "
                    f"lr={lr_scheduler.get_last_lr()[0]:.6f} Δt={since_last:.1f}s",
                    flush=True,
                )
                if swanlab_mod is not None:
                    swanlab_mod.log(
                        {
                            "train/loss": loss.item(),
                            "train/noise_loss": noise_loss.item(),
                            "train/x0_loss": x0_loss.item(),
                            "train/x0_loss_weight": args.x0_loss_weight,
                            "train/lr": lr_scheduler.get_last_lr()[0],
                            "train/epoch": float(epoch),
                        },
                        step=global_step,
                    )

            if global_step % args.save_every == 0:
                ckpt_path = Path(args.checkpoint_dir) / f"model_step_{global_step}.pth"
                save_checkpoint(
                    ckpt_path, model, optimizer, lr_scheduler, global_step, epoch, args
                )
                print(f"已保存 {ckpt_path}", flush=True)
                if swanlab_mod is not None:
                    swanlab_mod.log({"train/checkpoint_step": float(global_step)}, step=global_step)

                if val_ctx is not None and should_run_val(global_step, args):
                    run_validation(
                        args,
                        device,
                        latent_size,
                        model,
                        vae,
                        val_ctx,
                        global_step,
                        swanlab_mod,
                        prompt_embeds,
                        sar_vae=sar_vae,
                    )

            if global_step >= args.num_train_steps:
                break
        epoch += 1

    final = Path(args.checkpoint_dir) / f"model_step_{global_step}_final.pth"
    save_checkpoint(final, model, optimizer, lr_scheduler, global_step, epoch, args)
    print(f"最终 checkpoint: {final}", flush=True)


def main():
    args = parse_args()
    set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    data_root = Path(args.data_root).resolve()
    if not data_root.is_dir():
        raise NotADirectoryError(data_root)

    dataset = SAROpticalDataset(
        root_dir=str(data_root),
        image_size=args.image_size,
        sar_representation="repeat3",
        normalize_mode="vae",
    )
    if len(dataset) == 0:
        raise RuntimeError("无训练样本")

    dataloader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=torch.cuda.is_available(),
        drop_last=True,
    )

    print("加载 VAE...", args.vae_model_id)
    vae = load_frozen_vae(args.vae_model_id, device=device)

    sar_vae = None
    if args.custom_sar_vae:
        print("加载自研单通道 SAR VAE...", args.custom_sar_vae)
        sar_vae = load_custom_sar_vae(args.custom_sar_vae, device=device)

    swanlab_mod = None
    if args.use_swanlab:
        try:
            swanlab_mod = _init_swanlab(args, data_root, len(dataset))
        except ImportError as e:
            raise ImportError("pip install swanlab") from e

    val_ctx = setup_val_context(args)

    try:
        train_loop(args, device, data_root, dataloader, vae, swanlab_mod, val_ctx, sar_vae=sar_vae)
    finally:
        if swanlab_mod is not None:
            swanlab_mod.finish()


if __name__ == "__main__":
    main()
