"""冻结 SD VAE 的 encode / decode（P0）与自研单通道 SAR VAE。"""

from __future__ import annotations

import sys
from pathlib import Path

import torch
from diffusers import AutoencoderKL

# 本地 SD2.1-base VAE（含 vae/ 子目录）；与 diffusers subfolder="vae" 一致。
DEFAULT_VAE_MODEL_ID = str(Path(__file__).resolve().parent / "sd21_base_mirror")


def load_frozen_vae(
    model_id: str = DEFAULT_VAE_MODEL_ID,
    device: torch.device | str | None = None,
    dtype: torch.dtype = torch.float32,
) -> AutoencoderKL:
    vae = AutoencoderKL.from_pretrained(model_id, subfolder="vae")
    vae.requires_grad_(False)
    vae.eval()
    if device is not None:
        vae = vae.to(device=device, dtype=dtype)
    return vae


@torch.no_grad()
def encode_images(vae: AutoencoderKL, images: torch.Tensor) -> torch.Tensor:
    latent_dist = vae.encode(images).latent_dist
    latents = latent_dist.sample()
    return latents * vae.config.scaling_factor


@torch.no_grad()
def decode_latents(vae: AutoencoderKL, latents: torch.Tensor) -> torch.Tensor:
    latents = latents / vae.config.scaling_factor
    return vae.decode(latents).sample


def latent_spatial_size(image_size: int) -> int:
    return image_size // 8


def load_custom_sar_vae(
    checkpoint_path: str,
    device: torch.device | str | None = None,
) -> torch.nn.Module:
    """加载自定义训练单通道 VAE 的 E_sar 权重"""
    # 动态注入 `sar_vae` 目录至 PYTHONPATH
    project_root = Path(__file__).resolve().parent.parent
    sar_vae_dir = project_root / "sar_vae"
    if str(sar_vae_dir) not in sys.path:
        sys.path.insert(0, str(sar_vae_dir))

    from model import SARVAE

    state = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    ckpt_args = state.get("args", {})
    latent_channels = int(ckpt_args.get("latent_channels", 4))
    base_channels = int(ckpt_args.get("base_channels", 64))

    sar_vae = SARVAE(
        in_channels=1,
        latent_channels=latent_channels,
        base_channels=base_channels,
    )
    sar_vae.load_state_dict(state["model"])
    sar_vae.requires_grad_(False)
    sar_vae.eval()

    if device is not None:
        sar_vae = sar_vae.to(device)
    return sar_vae


@torch.no_grad()
def encode_sar_images(sar_vae: torch.nn.Module, images: torch.Tensor) -> torch.Tensor:
    """利用自研单通道 VAE 提取 SAR 特征，返回编码均值 mu。"""
    # 适配 repeat3：如果输入为 [B, 3, 256, 256]，自动切片取第一通道
    if images.shape[1] == 3:
        images = images[:, 0:1]

    mu, _logvar = sar_vae.encode(images)
    return mu

