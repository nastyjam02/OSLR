"""训练期验证：固定 test 子集上生成 SSIM（与 evaluate.py 口径一致）。"""

from __future__ import annotations

import json
import random
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

from dataset import SAROpticalDataset
from latent_infer import sample_conditional_eo
from scheduler_utils import build_inference_scheduler
from vae_utils import latent_spatial_size

DEFAULT_VAL_CATEGORIES = ("agri", "barrenland", "grassland", "urban")


def denormalize_rgb_batch(images: torch.Tensor) -> torch.Tensor:
    images = ((images + 1.0) / 2.0).clamp(0, 1)
    return (images * 255).round().to(torch.uint8)


def tensor_rgb_to_hwc(tensor: torch.Tensor) -> np.ndarray:
    return tensor.permute(1, 2, 0).cpu().numpy()


def _ssim_uint8(real_u8: torch.Tensor, fake_u8: torch.Tensor) -> float:
    from skimage.metrics import structural_similarity

    return float(
        structural_similarity(
            tensor_rgb_to_hwc(real_u8),
            tensor_rgb_to_hwc(fake_u8),
            channel_axis=2,
            data_range=255,
        )
    )


def _category_for_index(dataset: SAROpticalDataset, index: int) -> str:
    return Path(dataset.sar_paths[index]).parent.parent.name


def build_stratified_val_indices(
    data_root: Path,
    *,
    image_size: int,
    categories: tuple[str, ...],
    per_category: int,
    seed: int,
) -> list[int]:
    dataset = SAROpticalDataset(
        root_dir=str(data_root),
        image_size=image_size,
        sar_representation="repeat3",
        normalize_mode="vae",
    )
    by_cat: dict[str, list[int]] = defaultdict(list)
    for i in range(len(dataset)):
        cat = _category_for_index(dataset, i)
        if cat in categories:
            by_cat[cat].append(i)

    rng = random.Random(seed)
    selected: list[int] = []
    for cat in categories:
        pool = sorted(by_cat.get(cat, []))
        if len(pool) < per_category:
            raise RuntimeError(
                f"验证类 {cat!r} 仅 {len(pool)} 张，需要 {per_category} 张（root={data_root}）"
            )
        if len(pool) == per_category:
            picked = pool
        else:
            picked = sorted(rng.sample(pool, per_category))
        selected.extend(picked)

    return sorted(selected)


def save_val_indices_manifest(
    path: Path,
    *,
    data_root: Path,
    image_size: int,
    categories: tuple[str, ...],
    per_category: int,
    seed: int,
    indices: list[int],
) -> None:
    dataset = SAROpticalDataset(
        root_dir=str(data_root),
        image_size=image_size,
        sar_representation="repeat3",
        normalize_mode="vae",
    )
    entries = []
    for idx in indices:
        sar_path = dataset.sar_paths[idx]
        entries.append(
            {
                "index": idx,
                "category": _category_for_index(dataset, idx),
                "sar_path": sar_path,
                "opt_path": dataset.opt_paths[idx],
            }
        )
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "data_root": str(data_root.resolve()),
        "categories": list(categories),
        "per_category": per_category,
        "seed": seed,
        "num_samples": len(indices),
        "indices": indices,
        "samples": entries,
    }
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)


def load_or_create_val_indices(
    data_root: Path,
    indices_path: Path,
    *,
    image_size: int,
    categories: tuple[str, ...],
    per_category: int,
    seed: int,
) -> list[int]:
    data_root = data_root.resolve()
    if indices_path.is_file():
        with indices_path.open(encoding="utf-8") as f:
            payload = json.load(f)
        if Path(payload.get("data_root", "")).resolve() != data_root:
            raise ValueError(
                f"val 索引文件 data_root 不匹配:\n  文件: {payload.get('data_root')}\n  当前: {data_root}"
            )
        return [int(i) for i in payload["indices"]]

    indices = build_stratified_val_indices(
        data_root,
        image_size=image_size,
        categories=categories,
        per_category=per_category,
        seed=seed,
    )
    save_val_indices_manifest(
        indices_path,
        data_root=data_root,
        image_size=image_size,
        categories=categories,
        per_category=per_category,
        seed=seed,
        indices=indices,
    )
    return indices


def make_val_dataloader(
    data_root: Path,
    indices: list[int],
    *,
    image_size: int,
    batch_size: int,
    num_workers: int,
) -> tuple[SAROpticalDataset, DataLoader]:
    dataset = SAROpticalDataset(
        root_dir=str(data_root),
        image_size=image_size,
        sar_representation="repeat3",
        normalize_mode="vae",
    )
    subset = Subset(dataset, indices)
    loader = DataLoader(
        subset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available(),
    )
    return dataset, loader


@torch.no_grad()
def run_val_monitor(
    model,
    vae,
    val_loader: DataLoader,
    full_dataset: SAROpticalDataset,
    subset_indices: list[int],
    *,
    device: torch.device,
    latent_size: int,
    num_diffusion_steps: int,
    val_scheduler: str,
    val_inference_steps: int,
    val_seed: int,
    prompt_embeds: torch.Tensor | None = None,
    uncond_prompt_embeds: torch.Tensor | None = None,
    guidance_scale: float = 1.0,
    sar_vae: torch.nn.Module | None = None,
) -> dict[str, float]:
    was_training = model.training
    model.eval()

    if val_seed is not None:
        torch.manual_seed(val_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(val_seed)

    scheduler = build_inference_scheduler(
        val_scheduler,
        num_diffusion_steps,
        val_inference_steps,
        device,
    )

    ssim_all: list[float] = []
    ssim_by_cat: dict[str, list[float]] = defaultdict(list)

    global_pos = 0
    for sar_imgs, real_opt in val_loader:
        bsz = sar_imgs.shape[0]
        sar_imgs = sar_imgs.to(device)
        real_opt = real_opt.to(device)

        fake_opt = sample_conditional_eo(
            model,
            vae,
            scheduler,
            sar_imgs,
            latent_size,
            prompt_embeds=prompt_embeds,
            uncond_prompt_embeds=uncond_prompt_embeds,
            guidance_scale=guidance_scale,
            sar_vae=sar_vae,
        )
        fake_u8 = denormalize_rgb_batch(fake_opt)
        real_u8 = denormalize_rgb_batch(real_opt)


        for i in range(bsz):
            ds_idx = subset_indices[global_pos + i]
            cat = _category_for_index(full_dataset, ds_idx)
            score = _ssim_uint8(real_u8[i], fake_u8[i])
            ssim_all.append(score)
            ssim_by_cat[cat].append(score)

        global_pos += bsz

    if was_training:
        model.train()

    metrics: dict[str, float] = {
        "val/mean_ssim": float(np.mean(ssim_all)),
        "val/num_samples": float(len(ssim_all)),
    }
    for cat, vals in sorted(ssim_by_cat.items()):
        metrics[f"val/ssim_{cat}"] = float(np.mean(vals))

    return metrics


def resolve_val_categories(categories_str: str | None) -> tuple[str, ...]:
    if not categories_str or not categories_str.strip():
        return DEFAULT_VAL_CATEGORIES
    return tuple(c.strip() for c in categories_str.split(",") if c.strip())
