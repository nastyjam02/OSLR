"""B2 单步对抗增强用的条件 PatchGAN 判别器。

pix2pix 式：判别器吃 concat(optical_rgb, sar_rgb)，输出 patch logits。
默认 3 层下采样 ≈ 70x70 感受野。所有卷积用 spectral norm 稳定对抗训练，
不使用 BatchNorm/InstanceNorm；配合 hinge 损失。
"""

from __future__ import annotations

import torch
import torch.nn as nn
from torch.nn.utils import spectral_norm


class ConditionalPatchGAN(nn.Module):
    def __init__(
        self,
        image_channels: int = 3,
        cond_channels: int = 3,
        base_channels: int = 64,
        n_layers: int = 3,
    ):
        super().__init__()
        in_channels = image_channels + cond_channels
        layers: list[nn.Module] = [
            spectral_norm(nn.Conv2d(in_channels, base_channels, 4, stride=2, padding=1)),
            nn.LeakyReLU(0.2, inplace=True),
        ]
        ch = base_channels
        for _ in range(1, n_layers):
            nch = min(ch * 2, base_channels * 8)
            layers += [
                spectral_norm(nn.Conv2d(ch, nch, 4, stride=2, padding=1)),
                nn.LeakyReLU(0.2, inplace=True),
            ]
            ch = nch
        nch = min(ch * 2, base_channels * 8)
        layers += [
            spectral_norm(nn.Conv2d(ch, nch, 4, stride=1, padding=1)),
            nn.LeakyReLU(0.2, inplace=True),
        ]
        ch = nch
        layers += [spectral_norm(nn.Conv2d(ch, 1, 4, stride=1, padding=1))]
        self.model = nn.Sequential(*layers)

    def forward(self, image: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        return self.model(torch.cat([image, cond], dim=1))


def hinge_d_loss(real_logits: torch.Tensor, fake_logits: torch.Tensor) -> torch.Tensor:
    """判别器 hinge 损失：real 推向 >+1，fake 推向 <-1。"""
    return (
        torch.relu(1.0 - real_logits).mean()
        + torch.relu(1.0 + fake_logits).mean()
    )


def hinge_g_loss(fake_logits: torch.Tensor) -> torch.Tensor:
    """生成器 hinge 对抗损失：最大化 fake logits。"""
    return -fake_logits.mean()
