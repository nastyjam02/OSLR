"""阶段 B 单步回归评测：SSIM / PSNR / LPIPS / FID（口径对齐 sar2opt_latent/evaluate.py）。"""

from __future__ import annotations

import argparse
import json
import random
import sys
import time
from collections import defaultdict
from pathlib import Path

_SAR2OPT_LATENT_DIR = Path(__file__).resolve().parent.parent / "sar2opt_latent"
if str(_SAR2OPT_LATENT_DIR) not in sys.path:
    sys.path.insert(0, str(_SAR2OPT_LATENT_DIR))

import cv2
import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

from dataset import SAROpticalDataset
from eval_manifest import DEFAULT_EVAL_MANIFEST, load_eval_manifest
from model_latent import build_latent_unet
from model_ldm import (
    DEFAULT_LDM_MODEL_ID,
    MODEL_TYPE_LDM,
    build_ldm_unet,
    is_ldm_model_type,
    resolve_ldm_model_id,
)
from vae_utils import (
    DEFAULT_VAE_MODEL_ID,
    latent_spatial_size,
    load_custom_sar_vae,
    load_frozen_vae,
)

from infer import sample_onestep

PACKAGE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = PACKAGE_DIR.parent
DEFAULT_DATA = PROJECT_ROOT / "archive" / "splits" / "test"
DEFAULT_CKPT = PROJECT_ROOT / "checkpoints" / "sar2opt_onestep" / "model_step_20000_final.pth"
DEFAULT_OUT = PROJECT_ROOT / "outputs" / "sar2opt_onestep_eval"
DEFAULT_FID_WEIGHTS = (
    PROJECT_ROOT
    / "sar2opt"
    / "FID_Inception_V3"
    / "weights-inception-2015-12-05-6726825d.pth"
)


def parse_args():
    p = argparse.ArgumentParser(description="SAR→Opt 单步回归评测")
    p.add_argument("--checkpoint", default=str(DEFAULT_CKPT))
    p.add_argument("--data-root", default=str(DEFAULT_DATA))
    p.add_argument("--eval-manifest", default=str(DEFAULT_EVAL_MANIFEST))
    p.add_argument("--output-dir", default=str(DEFAULT_OUT))
    p.add_argument("--vae-model-id", default=DEFAULT_VAE_MODEL_ID)
    p.add_argument("--ldm-model-id", default=DEFAULT_LDM_MODEL_ID)
    p.add_argument("--prompt", default=None)
    p.add_argument(
        "--input-mode",
        choices=("clean", "noise", "auto"),
        default="auto",
        help="auto 时从 checkpoint args 读取。",
    )
    p.add_argument("--timestep", type=int, default=None)
    p.add_argument("--image-size", type=int, default=256)
    p.add_argument("--batch-size", type=int, default=32)
    p.add_argument("--num-workers", type=int, default=4)
    p.add_argument("--num-samples", type=int, default=100)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--log-every", type=int, default=10)
    p.add_argument("--save-sar", action="store_true")
    p.add_argument("--fid-weights", default=str(DEFAULT_FID_WEIGHTS))
    p.add_argument("--custom-sar-vae", default=None)
    p.add_argument("--timing-warmup-batches", type=int, default=2)
    return p.parse_args()


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def denormalize_rgb_batch(images):
    images = ((images + 1.0) / 2.0).clamp(0, 1)
    return (images * 255).round().to(torch.uint8)


def tensor_rgb_to_hwc(tensor):
    return tensor.permute(1, 2, 0).cpu().numpy()


def save_rgb_image(path, image_chw):
    path.parent.mkdir(parents=True, exist_ok=True)
    hwc = tensor_rgb_to_hwc(image_chw)
    bgr = cv2.cvtColor(hwc, cv2.COLOR_RGB2BGR)
    if not cv2.imwrite(str(path), bgr):
        raise RuntimeError(path)


def save_sar_preview(path, sar_3ch):
    path.parent.mkdir(parents=True, exist_ok=True)
    g = sar_3ch[0:1]
    g = ((g + 1.0) / 2.0).clamp(0, 1).squeeze(0).cpu().numpy()
    g = (g * 255).astype(np.uint8)
    if not cv2.imwrite(str(path), g):
        raise RuntimeError(path)


def build_sample_name(dataset, index, order=None):
    sar_path = Path(dataset.sar_paths[index])
    category = sar_path.parent.parent.name
    prefix = order if order is not None else index
    return f"{prefix:06d}_{category}_{sar_path.stem}.png"


def category_for_index(dataset, index):
    return Path(dataset.sar_paths[index]).parent.parent.name


def _fid_kwargs(fid_weights_path=None):
    fid_kw = {"feature": 2048, "normalize": False}
    if fid_weights_path:
        w = Path(fid_weights_path).expanduser().resolve()
        if not w.is_file():
            raise FileNotFoundError(w)
        fid_kw["feature_extractor_weights_path"] = str(w)
    return fid_kw


def create_fid(device, fid_weights_path=None):
    from torchmetrics.image.fid import FrechetInceptionDistance

    return FrechetInceptionDistance(**_fid_kwargs(fid_weights_path)).to(device)


def create_lpips(device):
    from torchmetrics.image.lpip import LearnedPerceptualImagePatchSimilarity

    return LearnedPerceptualImagePatchSimilarity(net_type="alex", normalize=True).to(device)


def create_metric_objects(device, fid_weights_path=None):
    from skimage.metrics import peak_signal_noise_ratio, structural_similarity

    fid = create_fid(device, fid_weights_path=fid_weights_path)
    lpips = create_lpips(device)
    return structural_similarity, peak_signal_noise_ratio, fid, lpips


def load_onestep_model(checkpoint_path, device, *, ldm_model_id, latent_size, prompt):
    ckpt_path = Path(checkpoint_path).resolve()
    state = torch.load(ckpt_path, map_location=device, weights_only=False)
    ckpt_args = state.get("args", {}) if isinstance(state, dict) else {}
    weight = state["model"] if isinstance(state, dict) and "model" in state else state

    model_type = str(ckpt_args.get("model_type", "onestep_ldm"))
    input_mode = str(ckpt_args.get("input_mode", "clean"))
    timestep = int(ckpt_args.get("timestep", 0))
    prompt_str = prompt if prompt is not None else str(ckpt_args.get("prompt", ""))

    if is_ldm_model_type(model_type) or model_type.startswith("onestep_ldm"):
        ldm_id = str(ckpt_args.get("ldm_model_id", ldm_model_id))
        model, prompt_embeds, _uncond = build_ldm_unet(
            model_id=resolve_ldm_model_id(ldm_id),
            device=device,
            prompt=prompt_str,
        )
        model.load_state_dict(weight)
        model.eval()
        return model, prompt_embeds, "onestep_ldm", input_mode, timestep

    model = build_latent_unet(latent_size=latent_size).to(device)
    model.load_state_dict(weight)
    model.eval()
    return model, None, "onestep_latent_p0", input_mode, timestep


def evaluate(args):
    set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    ckpt = Path(args.checkpoint).resolve()
    data_root = Path(args.data_root).resolve()
    if not ckpt.is_file():
        raise FileNotFoundError(ckpt)
    if not data_root.is_dir():
        raise NotADirectoryError(data_root)

    latent_size = latent_spatial_size(args.image_size)
    model, prompt_embeds, model_type, ckpt_input_mode, ckpt_timestep = load_onestep_model(
        ckpt,
        device,
        ldm_model_id=args.ldm_model_id,
        latent_size=latent_size,
        prompt=args.prompt,
    )
    input_mode = ckpt_input_mode if args.input_mode == "auto" else args.input_mode
    timestep = ckpt_timestep if args.timestep is None else args.timestep

    out_base = Path(args.output_dir).resolve()
    run_name = f"onestep_{input_mode}"
    output_dir = out_base / run_name

    fid_w = (args.fid_weights or "").strip() or None
    if fid_w is None and DEFAULT_FID_WEIGHTS.is_file():
        fid_w = str(DEFAULT_FID_WEIGHTS)
    structural_similarity, peak_signal_noise_ratio, fid, lpips = create_metric_objects(
        device, fid_weights_path=fid_w
    )

    dataset = SAROpticalDataset(
        root_dir=str(data_root),
        image_size=args.image_size,
        sar_representation="repeat3",
        normalize_mode="vae",
    )
    if len(dataset) == 0:
        raise RuntimeError("测试集为空")

    eval_manifest_path = (args.eval_manifest or "").strip()
    eval_manifest_meta = None
    eval_indices = None
    if eval_manifest_path:
        manifest = Path(eval_manifest_path).expanduser().resolve()
        eval_indices, eval_manifest_meta = load_eval_manifest(manifest, data_root=data_root)
        total = len(eval_indices)
        if args.num_samples is not None:
            total = min(args.num_samples, total)
            eval_indices = eval_indices[:total]
        eval_dataset = Subset(dataset, eval_indices)
    else:
        total = min(args.num_samples, len(dataset))
        eval_dataset = dataset

    loader = DataLoader(
        eval_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=torch.cuda.is_available(),
    )

    vae = load_frozen_vae(args.vae_model_id, device=device)
    sar_vae = None
    if args.custom_sar_vae:
        print("加载自研 SAR VAE...", args.custom_sar_vae)
        sar_vae = load_custom_sar_vae(args.custom_sar_vae, device=device)

    gen_dir = output_dir / "generated"
    real_dir = output_dir / "real"
    sar_dir = output_dir / "sar"
    gen_dir.mkdir(parents=True, exist_ok=True)
    real_dir.mkdir(parents=True, exist_ok=True)
    if args.save_sar:
        sar_dir.mkdir(parents=True, exist_ok=True)

    print(
        f"{model_type} 评估 {ckpt} | mode={input_mode} t={timestep} | "
        f"samples={total} out={output_dir}",
        flush=True,
    )

    ssim_vals = []
    psnr_vals = []
    ssim_by_cat = defaultdict(list)
    psnr_by_cat = defaultdict(list)
    fid_by_cat = {}
    lpips_by_cat = {}

    def get_category_metrics(category):
        if category not in fid_by_cat:
            fid_by_cat[category] = create_fid(device, fid_weights_path=fid_w)
            lpips_by_cat[category] = create_lpips(device)
        return fid_by_cat[category], lpips_by_cat[category]

    processed = 0
    wall_t0 = time.perf_counter()
    infer_batch_ms = []
    timed_images = 0
    peak_mem_bytes = 0

    for batch_idx, (sar_imgs, real_opt) in enumerate(loader):
        if processed >= total:
            break
        bsz = min(sar_imgs.shape[0], total - processed)
        sar_imgs = sar_imgs[:bsz].to(device)
        real_opt = real_opt[:bsz].to(device)

        if torch.cuda.is_available():
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats()
        t_infer0 = time.perf_counter()

        fake_opt = sample_onestep(
            model,
            vae,
            sar_imgs,
            input_mode=input_mode,
            prompt_embeds=prompt_embeds,
            sar_vae=sar_vae,
            timestep=timestep,
        )

        if torch.cuda.is_available():
            torch.cuda.synchronize()
            peak_mem_bytes = max(peak_mem_bytes, torch.cuda.max_memory_allocated())
        t_infer1 = time.perf_counter()
        if batch_idx >= args.timing_warmup_batches:
            infer_batch_ms.append((t_infer1 - t_infer0) * 1000.0)
            timed_images += bsz

        fake_u8 = denormalize_rgb_batch(fake_opt)
        real_u8 = denormalize_rgb_batch(real_opt)
        fake_01 = ((fake_opt + 1.0) / 2.0).clamp(0, 1)
        real_01 = ((real_opt + 1.0) / 2.0).clamp(0, 1)

        fid.update(real_u8, real=True)
        fid.update(fake_u8, real=False)
        lpips.update(fake_01, real_01)

        for i in range(bsz):
            if eval_indices is not None:
                ds_idx = eval_indices[processed + i]
                order = processed + i
            else:
                ds_idx = processed + i
                order = ds_idx
            cat = category_for_index(dataset, ds_idx)
            name = build_sample_name(dataset, ds_idx, order=order)

            real_np = tensor_rgb_to_hwc(real_u8[i])
            fake_np = tensor_rgb_to_hwc(fake_u8[i])
            ssim = float(
                structural_similarity(real_np, fake_np, channel_axis=2, data_range=255)
            )
            psnr = float(peak_signal_noise_ratio(real_np, fake_np, data_range=255))
            ssim_vals.append(ssim)
            psnr_vals.append(psnr)
            ssim_by_cat[cat].append(ssim)
            psnr_by_cat[cat].append(psnr)

            cat_fid, cat_lpips = get_category_metrics(cat)
            cat_fid.update(real_u8[i : i + 1], real=True)
            cat_fid.update(fake_u8[i : i + 1], real=False)
            cat_lpips.update(fake_01[i : i + 1], real_01[i : i + 1])

            save_rgb_image(gen_dir / name, fake_u8[i])
            save_rgb_image(real_dir / name, real_u8[i])
            if args.save_sar:
                save_sar_preview(sar_dir / name, sar_imgs[i])

        processed += bsz
        if processed % args.log_every < bsz or processed >= total:
            print(f"  processed {processed}/{total}", flush=True)

    wall_total_s = time.perf_counter() - wall_t0
    metrics = {
        "model_type": model_type,
        "checkpoint": str(ckpt),
        "input_mode": input_mode,
        "timestep": timestep,
        "num_samples": processed,
        "SSIM": float(np.mean(ssim_vals)) if ssim_vals else None,
        "PSNR": float(np.mean(psnr_vals)) if psnr_vals else None,
        "LPIPS": float(lpips.compute().item()),
        "FID": float(fid.compute().item()),
        "by_category": {},
        "timing": {
            "wall_total_s": wall_total_s,
            "infer_total_s": float(sum(infer_batch_ms) / 1000.0) if infer_batch_ms else None,
            "ms_per_img": float(sum(infer_batch_ms) / timed_images) if timed_images else None,
            "images_per_s": float(timed_images / (sum(infer_batch_ms) / 1000.0))
            if timed_images and infer_batch_ms
            else None,
            "timed_images": timed_images,
            "peak_mem_gb": float(peak_mem_bytes / (1024**3)) if peak_mem_bytes else None,
        },
    }
    if eval_manifest_meta is not None:
        metrics["eval_manifest"] = eval_manifest_meta

    for cat in sorted(ssim_by_cat.keys()):
        cat_fid = fid_by_cat[cat]
        cat_lpips = lpips_by_cat[cat]
        metrics["by_category"][cat] = {
            "n": len(ssim_by_cat[cat]),
            "SSIM": float(np.mean(ssim_by_cat[cat])),
            "PSNR": float(np.mean(psnr_by_cat[cat])),
            "LPIPS": float(cat_lpips.compute().item()),
            "FID": float(cat_fid.compute().item()),
        }

    output_dir.mkdir(parents=True, exist_ok=True)
    metrics_path = output_dir / "metrics.json"
    with metrics_path.open("w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2, ensure_ascii=False)

    print(
        f"SSIM={metrics['SSIM']:.4f} PSNR={metrics['PSNR']:.2f} "
        f"LPIPS={metrics['LPIPS']:.4f} FID={metrics['FID']:.2f}",
        flush=True,
    )
    if metrics["timing"]["ms_per_img"] is not None:
        print(
            f"timing: {metrics['timing']['ms_per_img']:.1f} ms/img, "
            f"{metrics['timing']['images_per_s']:.1f} img/s",
            flush=True,
        )
    print(f"metrics -> {metrics_path}", flush=True)
    return metrics


if __name__ == "__main__":
    evaluate(parse_args())
