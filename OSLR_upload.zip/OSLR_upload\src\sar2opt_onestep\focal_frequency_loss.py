"""Focal Frequency Loss (Jiang et al., ICCV 2021)。

在频域直接惩罚生成图与真实图的频谱差异，并用"焦点权重"聚焦于难拟合的
频率分量（通常是高频纹理）。相比 GAN 更稳、更便宜，正对"糊/高频缺失"。

用法：
    ffl = FocalFrequencyLoss(alpha=1.0)
    loss = ffl(fake_img, real_img)   # 输入 [B,C,H,W]，尺度需一致（如 [-1,1]）
"""

from __future__ import annotations

import torch
import torch.nn as nn


class FocalFrequencyLoss(nn.Module):
    """频域焦点损失。

    Args:
        alpha: 焦点权重的指数。alpha=0 退化为普通频谱 L2；越大越聚焦难拟合频率。
        eps: 权重归一化数值稳定项。
    """

    def __init__(self, alpha: float = 1.0, eps: float = 1e-12):
        super().__init__()
        self.alpha = alpha
        self.eps = eps

    @staticmethod
    def _to_freq(x: torch.Tensor) -> torch.Tensor:
        # 全图 2D FFT；norm="ortho" 保证尺度与图像大小无关。
        # 输出 [B,C,H,W,2]，最后一维为 (real, imag)。
        freq = torch.fft.fft2(x, norm="ortho")
        return torch.stack([freq.real, freq.imag], dim=-1)

    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        # FFT 需 fp32，避免在混合精度下报错/精度损失。
        pred_freq = self._to_freq(pred.float())
        target_freq = self._to_freq(target.float())

        # 每个频率点的平方距离 d(u,v) = |F_pred - F_target|^2
        freq_dist = (pred_freq - target_freq).pow(2).sum(dim=-1)

        # 焦点权重 w = d^alpha，detach 后按 batch 内最大值归一化到 [0,1]。
        with torch.no_grad():
            weight = freq_dist.detach() ** self.alpha
            norm = weight.amax(dim=(-2, -1), keepdim=True).clamp_min(self.eps)
            weight = (weight / norm).clamp(0.0, 1.0)

        return (weight * freq_dist).mean()
