"""单步回归推理：SAR latent → optical latent → VAE decode。"""

from __future__ import annotations

import torch

from model_ldm import expand_prompt_embeds
from vae_utils import decode_latents, encode_images, encode_sar_images


def build_onestep_input(
    z_sar: torch.Tensor,
    *,
    input_mode: str = "clean",
    noise: torch.Tensor | None = None,
) -> torch.Tensor:
    """
    组装 8 通道 U-Net 输入。

    - clean: concat(zeros, z_sar)
    - noise: concat(ε, z_sar)，ε ~ N(0,I) 或外部传入
    """
    if input_mode == "clean":
        z_noise = torch.zeros_like(z_sar)
    elif input_mode == "noise":
        z_noise = torch.randn_like(z_sar) if noise is None else noise.to(dtype=z_sar.dtype, device=z_sar.device)
    else:
        raise ValueError(f"未知 input_mode={input_mode!r}，期望 clean|noise")
    return torch.cat([z_noise, z_sar], dim=1)


def predict_optical_latent(
    model,
    model_input: torch.Tensor,
    prompt_embeds: torch.Tensor | None,
    *,
    timestep: int = 0,
) -> torch.Tensor:
    """U-Net 单次前向，直接预测 optical latent（非噪声）。"""
    bsz = model_input.shape[0]
    device = model_input.device
    timesteps = torch.full((bsz,), timestep, device=device, dtype=torch.long)
    if prompt_embeds is not None:
        encoder_hidden_states = expand_prompt_embeds(prompt_embeds, bsz)
        return model(
            model_input,
            timesteps,
            encoder_hidden_states=encoder_hidden_states,
        ).sample
    return model(model_input, timesteps).sample


@torch.no_grad()
def sample_onestep(
    model,
    vae,
    sar_imgs: torch.Tensor,
    *,
    input_mode: str = "clean",
    prompt_embeds: torch.Tensor | None = None,
    sar_vae=None,
    timestep: int = 0,
    noise: torch.Tensor | None = None,
) -> torch.Tensor:
    """SAR 图像 → 单步预测 optical 图像（VAE 归一化 [-1,1]）。"""
    if sar_vae is not None:
        z_sar = encode_sar_images(sar_vae, sar_imgs)
    else:
        z_sar = encode_images(vae, sar_imgs)
    model_input = build_onestep_input(z_sar, input_mode=input_mode, noise=noise)
    z_pred = predict_optical_latent(
        model, model_input, prompt_embeds, timestep=timestep
    )
    return decode_latents(vae, z_pred)
