"""
阶段 B：SAR latent → optical latent 单步回归训练。

复用 sar2opt_latent 的 Dataset / VAE / LDM U-Net；
去掉扩散加噪与噪声 MSE，改为直接 L1 回归 optical latent。
"""

from __future__ import annotations

import argparse
import os
import random
import sys
import time
from datetime import datetime
from pathlib import Path

_SAR2OPT_LATENT_DIR = Path(__file__).resolve().parent.parent / "sar2opt_latent"
if str(_SAR2OPT_LATENT_DIR) not in sys.path:
    sys.path.insert(0, str(_SAR2OPT_LATENT_DIR))

import numpy as np
import torch
import torch.distributed as dist
import torch.nn.functional as F
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.optim import AdamW
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler
from transformers import get_cosine_schedule_with_warmup

from dataset import SAROpticalDataset
from model_latent import build_latent_unet
from model_ldm import (
    DEFAULT_LDM_MODEL_ID,
    MODEL_TYPE_LDM,
    build_ldm_unet,
    select_training_prompt_embeds,
)
from val_monitor import (
    load_or_create_val_indices,
    make_val_dataloader,
    resolve_val_categories,
)
from vae_utils import (
    DEFAULT_VAE_MODEL_ID,
    encode_images,
    encode_sar_images,
    latent_spatial_size,
    load_custom_sar_vae,
    load_frozen_vae,
)

from infer import build_onestep_input, predict_optical_latent, sample_onestep

PACKAGE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = PACKAGE_DIR.parent
DEFAULT_DATA_ROOT = PROJECT_ROOT / "archive" / "splits" / "train"
DEFAULT_VAL_DATA_ROOT = PROJECT_ROOT / "archive" / "splits" / "test"
DEFAULT_CHECKPOINT_DIR = PROJECT_ROOT / "checkpoints" / "sar2opt_onestep"
DEFAULT_PROMPT = ""
MODEL_TYPE_ONESTEP = "onestep_ldm"


def parse_args():
    p = argparse.ArgumentParser(description="SAR→Opt 单步 latent 回归（阶段 B）")
    p.add_argument(
        "--model-type",
        choices=("ldm", "latent"),
        default="ldm",
        help="ldm=SD2.1 8ch U-Net；latent=P0 小 U-Net。",
    )
    p.add_argument(
        "--input-mode",
        choices=("clean", "noise"),
        default="clean",
        help="clean=concat(0,z_sar)；noise=concat(ε,z_sar)。",
    )
    p.add_argument("--timestep", type=int, default=0, help="固定喂给 U-Net 的时间步。")
    p.add_argument("--data-root", default=str(DEFAULT_DATA_ROOT))
    p.add_argument("--checkpoint-dir", default=str(DEFAULT_CHECKPOINT_DIR))
    p.add_argument("--resume", default=None)
    p.add_argument(
        "--init-from-model",
        default=None,
        help="仅加载 U-Net 权重初始化；optimizer/lr_scheduler 从头开始。",
    )
    p.add_argument("--vae-model-id", default=DEFAULT_VAE_MODEL_ID)
    p.add_argument("--ldm-model-id", default=DEFAULT_LDM_MODEL_ID)
    p.add_argument("--prompt", default=DEFAULT_PROMPT)
    p.add_argument("--cond-dropout-prob", type=float, default=0.0)
    p.add_argument("--image-size", type=int, default=256)
    p.add_argument("--batch-size", type=int, default=32)
    p.add_argument("--num-workers", type=int, default=8)
    p.add_argument("--learning-rate", type=float, default=1e-4)
    p.add_argument("--num-train-steps", type=int, default=20000)
    p.add_argument("--warmup-steps", type=int, default=100)
    p.add_argument("--log-every", type=int, default=20)
    p.add_argument("--save-every", type=int, default=5000)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument(
        "--lambda-latent",
        type=float,
        default=1.0,
        help="optical latent L1 权重。",
    )
    p.add_argument(
        "--lambda-pixel",
        type=float,
        default=0.0,
        help="VAE decode 后像素 L1 权重；0 表示关闭。",
    )
    p.add_argument("--custom-sar-vae", default=None)
    p.add_argument("--use-swanlab", action="store_true")
    p.add_argument("--swanlab-project", type=str, default="sar2opt_onestep")
    p.add_argument("--swanlab-experiment", type=str, default=None)
    p.add_argument(
        "--swanlab-mode",
        type=str,
        default="cloud",
        choices=("cloud", "local", "offline", "disabled"),
    )
    p.add_argument("--swanlab-logdir", type=str, default=None)
    p.add_argument("--no-val", action="store_true")
    p.add_argument("--val-data-root", default=str(DEFAULT_VAL_DATA_ROOT))
    p.add_argument(
        "--val-categories",
        default="agri,barrenland,grassland,urban",
    )
    p.add_argument("--val-per-category", type=int, default=10)
    p.add_argument("--val-batch-size", type=int, default=16)
    p.add_argument("--val-seed", type=int, default=42)
    p.add_argument("--val-every", type=int, default=0)
    p.add_argument("--val-indices-file", default=None)
    p.add_argument("--local_rank", type=int, default=-1)
    args = p.parse_args()
    if "LOCAL_RANK" in os.environ:
        args.local_rank = int(os.environ["LOCAL_RANK"])
    return args


def resolved_model_type_tag(args) -> str:
    if args.model_type == "ldm":
        return MODEL_TYPE_ONESTEP
    return "onestep_latent_p0"


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def save_checkpoint(path, model, optimizer, lr_scheduler, global_step, epoch, args):
    path.parent.mkdir(parents=True, exist_ok=True)
    d = vars(args).copy()
    d["model_type"] = resolved_model_type_tag(args)
    torch.save(
        {
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "lr_scheduler": lr_scheduler.state_dict(),
            "global_step": global_step,
            "epoch": epoch,
            "args": d,
        },
        path,
    )


def _adapt_state_dict_for_model(state_dict, model):
    target = model.module if hasattr(model, "module") else model
    target_keys = set(target.state_dict().keys())
    if set(state_dict.keys()) == target_keys:
        return state_dict, target
    stripped = {k.removeprefix("module."): v for k, v in state_dict.items()}
    if set(stripped.keys()) == target_keys:
        return stripped, target
    return state_dict, target


def load_checkpoint(path, model, optimizer, lr_scheduler, device):
    ckpt = torch.load(path, map_location=device, weights_only=False)
    if "model" in ckpt:
        state_dict, load_into = _adapt_state_dict_for_model(ckpt["model"], model)
        load_into.load_state_dict(state_dict)
        optimizer.load_state_dict(ckpt["optimizer"])
        lr_scheduler.load_state_dict(ckpt["lr_scheduler"])
        return ckpt.get("global_step", 0), ckpt.get("epoch", 0)
    state_dict, load_into = _adapt_state_dict_for_model(ckpt, model)
    load_into.load_state_dict(state_dict)
    return 0, 0


def load_model_weights(path, model, device):
    ckpt = torch.load(path, map_location=device, weights_only=False)
    weight = ckpt["model"] if isinstance(ckpt, dict) and "model" in ckpt else ckpt
    state_dict, load_into = _adapt_state_dict_for_model(weight, model)
    missing, unexpected = load_into.load_state_dict(state_dict, strict=False)
    return missing, unexpected


def _val_interval_steps(args) -> int:
    return args.val_every if args.val_every > 0 else args.save_every


def should_run_val(global_step: int, args) -> bool:
    if args.no_val:
        return False
    interval = _val_interval_steps(args)
    return global_step == 0 or (global_step > 0 and global_step % interval == 0)


def setup_val_context(args) -> dict | None:
    if args.no_val:
        return None
    val_root = Path(args.val_data_root).resolve()
    if not val_root.is_dir():
        raise NotADirectoryError(val_root)
    categories = resolve_val_categories(args.val_categories)
    indices_path = (
        Path(args.val_indices_file).expanduser().resolve()
        if args.val_indices_file
        else Path(args.checkpoint_dir).resolve() / "val_indices_test_40.json"
    )
    indices = load_or_create_val_indices(
        val_root,
        indices_path,
        image_size=args.image_size,
        categories=categories,
        per_category=args.val_per_category,
        seed=args.val_seed,
    )
    full_dataset, loader = make_val_dataloader(
        val_root,
        indices,
        image_size=args.image_size,
        batch_size=args.val_batch_size,
        num_workers=args.num_workers,
    )
    print(
        f"验证监控: {val_root} | {len(categories)} 类 × {args.val_per_category} = {len(indices)} 张 | "
        f"onestep/{args.input_mode} | 索引 {indices_path}",
        flush=True,
    )
    return {"dataset": full_dataset, "loader": loader, "indices": indices}


@torch.no_grad()
def run_onestep_val(
    args,
    device,
    model,
    vae,
    val_ctx: dict,
    global_step: int,
    swanlab_mod,
    prompt_embeds,
    sar_vae=None,
):
    from collections import defaultdict

    from skimage.metrics import structural_similarity

    t0 = time.perf_counter()
    was_training = model.training
    model.eval()
    torch.manual_seed(args.val_seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.val_seed)

    def denorm(imgs):
        return ((imgs + 1.0) / 2.0).clamp(0, 1).mul(255).round().to(torch.uint8)

    def to_hwc(t):
        return t.permute(1, 2, 0).cpu().numpy()

    ssim_all = []
    ssim_by_cat = defaultdict(list)
    full_dataset = val_ctx["dataset"]
    indices = val_ctx["indices"]
    pos = 0
    for sar_imgs, real_opt in val_ctx["loader"]:
        bsz = sar_imgs.shape[0]
        sar_imgs = sar_imgs.to(device)
        real_opt = real_opt.to(device)
        fake = sample_onestep(
            model,
            vae,
            sar_imgs,
            input_mode=args.input_mode,
            prompt_embeds=prompt_embeds,
            sar_vae=sar_vae,
            timestep=args.timestep,
        )
        fake_u8 = denorm(fake)
        real_u8 = denorm(real_opt)
        for i in range(bsz):
            ds_idx = indices[pos + i]
            cat = Path(full_dataset.sar_paths[ds_idx]).parent.parent.name
            score = float(
                structural_similarity(
                    to_hwc(real_u8[i]),
                    to_hwc(fake_u8[i]),
                    channel_axis=2,
                    data_range=255,
                )
            )
            ssim_all.append(score)
            ssim_by_cat[cat].append(score)
        pos += bsz

    if was_training:
        model.train()

    mean_ssim = float(np.mean(ssim_all)) if ssim_all else 0.0
    elapsed = time.perf_counter() - t0
    print(
        f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | step={global_step} "
        f"val SSIM={mean_ssim:.4f} (n={len(ssim_all)}, onestep/{args.input_mode}) "
        f"Δt={elapsed:.1f}s",
        flush=True,
    )
    metrics = {
        "val/mean_ssim": mean_ssim,
        "val/num_samples": float(len(ssim_all)),
    }
    for cat, vals in sorted(ssim_by_cat.items()):
        metrics[f"val/ssim_{cat}"] = float(np.mean(vals))
    if swanlab_mod is not None:
        swanlab_mod.log(metrics, step=global_step)
    return metrics


def _init_swanlab(args, data_root, n_samples):
    import swanlab

    logdir = Path(args.swanlab_logdir) if args.swanlab_logdir else Path(args.checkpoint_dir) / "swanlog"
    logdir.mkdir(parents=True, exist_ok=True)
    config = {
        "model_type": resolved_model_type_tag(args),
        "input_mode": args.input_mode,
        "data_root": str(data_root),
        "n_samples": n_samples,
        "batch_size": args.batch_size,
        "learning_rate": args.learning_rate,
        "num_train_steps": args.num_train_steps,
        "lambda_latent": args.lambda_latent,
        "lambda_pixel": args.lambda_pixel,
        "init_from_model": args.init_from_model,
    }
    kw = {
        "project": args.swanlab_project,
        "config": config,
        "mode": args.swanlab_mode,
        "logdir": str(logdir),
    }
    if args.swanlab_experiment:
        kw["experiment_name"] = args.swanlab_experiment
    swanlab.init(**kw)
    return swanlab


def train_loop(
    args,
    device,
    data_root,
    dataset,
    dataloader,
    vae,
    swanlab_mod,
    val_ctx,
    sar_vae=None,
    rank=0,
    is_distributed=False,
    sampler=None,
):
    latent_size = latent_spatial_size(args.image_size)
    prompt_embeds = None
    uncond_prompt_embeds = None

    if args.model_type == "ldm":
        print(
            f"构建 LDM U-Net: {args.ldm_model_id!r}, prompt={args.prompt!r}, "
            f"input_mode={args.input_mode}, timestep={args.timestep}",
            flush=True,
        )
        model, prompt_embeds, uncond_prompt_embeds = build_ldm_unet(
            model_id=args.ldm_model_id,
            device=device,
            prompt=args.prompt,
        )
    else:
        model = build_latent_unet(latent_size=latent_size).to(device)

    if is_distributed:
        model = DDP(model, device_ids=[rank], output_device=rank)

    optimizer = AdamW(model.parameters(), lr=args.learning_rate, betas=(0.9, 0.999))
    lr_scheduler = get_cosine_schedule_with_warmup(
        optimizer=optimizer,
        num_warmup_steps=args.warmup_steps,
        num_training_steps=args.num_train_steps,
    )

    global_step = 0
    start_epoch = 0
    if args.resume and args.init_from_model:
        raise ValueError("--resume 与 --init-from-model 不能同时使用")
    if args.resume:
        global_step, start_epoch = load_checkpoint(
            Path(args.resume).resolve(), model, optimizer, lr_scheduler, device
        )
        if rank == 0:
            print(f"恢复 checkpoint: step={global_step}, epoch={start_epoch}", flush=True)
    elif args.init_from_model:
        init_path = Path(args.init_from_model).resolve()
        missing, unexpected = load_model_weights(init_path, model, device)
        if rank == 0:
            print(
                f"初始化模型权重: {init_path} "
                f"(missing={len(missing)}, unexpected={len(unexpected)}; optimizer 从头)",
                flush=True,
            )

    vae.to(device)
    vae.eval()
    if sar_vae is not None:
        sar_vae.to(device)
        sar_vae.eval()

    if rank == 0:
        print("开始训练 (onestep regression)...", flush=True)
        print(f"数据: {data_root}, 样本数: {len(dataset)}", flush=True)
        print(
            f"model_type={args.model_type}, input_mode={args.input_mode}, "
            f"latent_size={latent_size}, lr={args.learning_rate}, device={device}",
            flush=True,
        )

    model.train()
    raw_model = model.module if is_distributed else model

    if val_ctx is not None and rank == 0 and should_run_val(global_step, args):
        run_onestep_val(
            args, device, raw_model, vae, val_ctx, global_step, swanlab_mod, prompt_embeds, sar_vae
        )

    last_log_t = time.perf_counter()
    epoch = start_epoch

    while global_step < args.num_train_steps:
        if is_distributed and sampler is not None:
            sampler.set_epoch(epoch)
        for _, (sar_imgs, opt_imgs) in enumerate(dataloader):
            sar_imgs = sar_imgs.to(device)
            opt_imgs = opt_imgs.to(device)
            bsz = opt_imgs.shape[0]

            with torch.no_grad():
                z_y = encode_images(vae, opt_imgs)
                if sar_vae is not None:
                    z_x = encode_sar_images(sar_vae, sar_imgs)
                else:
                    z_x = encode_images(vae, sar_imgs)

            model_input = build_onestep_input(z_x, input_mode=args.input_mode)

            if args.model_type == "ldm":
                batch_prompt_embeds = select_training_prompt_embeds(
                    prompt_embeds,
                    uncond_prompt_embeds,
                    bsz,
                    args.cond_dropout_prob,
                    device,
                )
            else:
                batch_prompt_embeds = None

            z_pred = predict_optical_latent(
                model,
                model_input,
                batch_prompt_embeds,
                timestep=args.timestep,
            )

            loss_latent = F.l1_loss(z_pred, z_y)
            loss_pixel = z_pred.new_zeros(())
            if args.lambda_pixel > 0:
                # decode 可反传：像素空间辅助重建
                pixel_pred = vae.decode(z_pred / vae.config.scaling_factor).sample
                loss_pixel = F.l1_loss(pixel_pred, opt_imgs)

            loss = args.lambda_latent * loss_latent + args.lambda_pixel * loss_pixel
            loss.backward()
            optimizer.step()
            lr_scheduler.step()
            optimizer.zero_grad()

            global_step += 1

            if rank == 0 and (global_step % args.log_every == 0 or global_step == 1):
                now = time.perf_counter()
                wall = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                since_last = now - last_log_t
                last_log_t = now
                print(
                    f"{wall} | step={global_step} loss={loss.item():.4f} "
                    f"(latent={loss_latent.item():.4f}, pixel={loss_pixel.item():.4f}) "
                    f"lr={lr_scheduler.get_last_lr()[0]:.6f} Δt={since_last:.1f}s",
                    flush=True,
                )
                if swanlab_mod is not None:
                    swanlab_mod.log(
                        {
                            "train/loss_total": loss.item(),
                            "train/loss_latent": loss_latent.item(),
                            "train/loss_pixel": loss_pixel.item(),
                            "train/lr": lr_scheduler.get_last_lr()[0],
                            "train/epoch": float(epoch),
                        },
                        step=global_step,
                    )

            if rank == 0 and global_step % args.save_every == 0:
                ckpt_path = Path(args.checkpoint_dir) / f"model_step_{global_step}.pth"
                save_checkpoint(
                    ckpt_path, raw_model, optimizer, lr_scheduler, global_step, epoch, args
                )
                print(f"已保存 {ckpt_path}", flush=True)
                if val_ctx is not None and should_run_val(global_step, args):
                    run_onestep_val(
                        args,
                        device,
                        raw_model,
                        vae,
                        val_ctx,
                        global_step,
                        swanlab_mod,
                        prompt_embeds,
                        sar_vae,
                    )

            if global_step >= args.num_train_steps:
                break
        epoch += 1

    if rank == 0:
        final = Path(args.checkpoint_dir) / f"model_step_{global_step}_final.pth"
        save_checkpoint(final, raw_model, optimizer, lr_scheduler, global_step, epoch, args)
        print(f"最终 checkpoint: {final}", flush=True)


def main():
    args = parse_args()
    if args.resume and args.init_from_model:
        raise ValueError("--resume 与 --init-from-model 不能同时使用")
    if args.lambda_latent <= 0 and args.lambda_pixel <= 0:
        raise ValueError("至少开启 --lambda-latent 或 --lambda-pixel 之一")

    is_distributed = args.local_rank != -1
    if is_distributed:
        torch.cuda.set_device(args.local_rank)
        device = torch.device("cuda", args.local_rank)
        dist.init_process_group(backend="nccl")
        rank = dist.get_rank()
    else:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        rank = 0

    set_seed(args.seed + rank)

    data_root = Path(args.data_root).resolve()
    if not data_root.is_dir():
        raise NotADirectoryError(data_root)

    Path(args.checkpoint_dir).mkdir(parents=True, exist_ok=True)

    dataset = SAROpticalDataset(
        root_dir=str(data_root),
        image_size=args.image_size,
        sar_representation="repeat3",
        normalize_mode="vae",
    )
    if len(dataset) == 0:
        raise RuntimeError("无训练样本")

    sampler = DistributedSampler(dataset) if is_distributed else None
    dataloader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=(sampler is None),
        sampler=sampler,
        num_workers=args.num_workers,
        pin_memory=torch.cuda.is_available(),
        drop_last=True,
    )

    if rank == 0:
        print("加载 VAE...", args.vae_model_id, flush=True)
    vae = load_frozen_vae(args.vae_model_id, device=device)

    sar_vae = None
    if args.custom_sar_vae:
        if rank == 0:
            print("加载自研 SAR VAE...", args.custom_sar_vae, flush=True)
        sar_vae = load_custom_sar_vae(args.custom_sar_vae, device=device)

    swanlab_mod = None
    if args.use_swanlab and rank == 0:
        swanlab_mod = _init_swanlab(args, data_root, len(dataset))

    val_ctx = setup_val_context(args) if rank == 0 else None

    try:
        train_loop(
            args,
            device,
            data_root,
            dataset,
            dataloader,
            vae,
            swanlab_mod,
            val_ctx,
            sar_vae=sar_vae,
            rank=rank,
            is_distributed=is_distributed,
            sampler=sampler,
        )
    finally:
        if swanlab_mod is not None and rank == 0:
            swanlab_mod.finish()
        if is_distributed:
            dist.destroy_process_group()


if __name__ == "__main__":
    main()
