"""
阶段 B2：单步回归 + 感知(LPIPS) + 条件对抗(PatchGAN) 增强。

在 B0（clean, concat(0,z_sar), t=0, latent L1）基础上，续训时叠加：
  - latent L1（结构锚，守住 SSIM）
  - LPIPS（decode 后感知/高频）
  - 条件 PatchGAN hinge 对抗（decode 后 pixel 域，直接压 FID）

生成器（U-Net）默认从 B0 权重初始化；判别器从头训练。
checkpoint 的 "model" 键存生成器，兼容 evaluate.py。
"""

from __future__ import annotations

import argparse
import os
import random
import sys
import time
from datetime import datetime
from pathlib import Path

_THIS_DIR = Path(__file__).resolve().parent
_SAR2OPT_LATENT_DIR = _THIS_DIR.parent / "sar2opt_latent"
# 本目录与 sar2opt_latent 存在同名模块（train.py / infer.py / evaluate.py）。
# 必须让本目录优先解析，否则 `import train` 会命中 sar2opt_latent/train.py。
for _p in (str(_SAR2OPT_LATENT_DIR), str(_THIS_DIR)):
    if _p in sys.path:
        sys.path.remove(_p)
sys.path.insert(0, str(_SAR2OPT_LATENT_DIR))
sys.path.insert(0, str(_THIS_DIR))

import lpips
import numpy as np
import torch
import torch.distributed as dist
import torch.nn.functional as F
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.optim import Adam, AdamW
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler
from transformers import get_cosine_schedule_with_warmup

from dataset import SAROpticalDataset
from model_ldm import build_ldm_unet, select_training_prompt_embeds
from vae_utils import (
    DEFAULT_VAE_MODEL_ID,
    encode_images,
    encode_sar_images,
    latent_spatial_size,
    load_custom_sar_vae,
    load_frozen_vae,
)

from discriminator import ConditionalPatchGAN, hinge_d_loss, hinge_g_loss
from focal_frequency_loss import FocalFrequencyLoss
from infer import build_onestep_input, predict_optical_latent
from train import (
    load_model_weights,
    resolved_model_type_tag,
    run_onestep_val,
    setup_val_context,
    should_run_val,
)

PACKAGE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = PACKAGE_DIR.parent
DEFAULT_DATA_ROOT = PROJECT_ROOT / "archive" / "splits" / "train"
DEFAULT_VAL_DATA_ROOT = PROJECT_ROOT / "archive" / "splits" / "test"
DEFAULT_CHECKPOINT_DIR = PROJECT_ROOT / "checkpoints" / "sar2opt_onestep_b2"


def parse_args():
    p = argparse.ArgumentParser(description="SAR→Opt 单步 + LPIPS + 对抗（阶段 B2）")
    p.add_argument("--input-mode", choices=("clean", "noise"), default="clean")
    p.add_argument("--timestep", type=int, default=0)
    p.add_argument("--data-root", default=str(DEFAULT_DATA_ROOT))
    p.add_argument("--checkpoint-dir", default=str(DEFAULT_CHECKPOINT_DIR))
    p.add_argument("--resume", default=None)
    p.add_argument(
        "--init-from-model",
        default=None,
        help="生成器初始化权重（通常为 B0 final）；判别器从头。",
    )
    p.add_argument("--vae-model-id", default=DEFAULT_VAE_MODEL_ID)
    p.add_argument("--ldm-model-id", default=DEFAULT_VAE_MODEL_ID)
    p.add_argument("--prompt", default="")
    p.add_argument("--cond-dropout-prob", type=float, default=0.0)
    p.add_argument("--image-size", type=int, default=256)
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--num-workers", type=int, default=8)
    p.add_argument("--learning-rate", type=float, default=5e-5, help="生成器 lr。")
    p.add_argument("--d-learning-rate", type=float, default=1e-4, help="判别器 lr。")
    p.add_argument("--num-train-steps", type=int, default=15000)
    p.add_argument("--warmup-steps", type=int, default=100)
    p.add_argument("--log-every", type=int, default=20)
    p.add_argument("--save-every", type=int, default=2500)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--lambda-latent", type=float, default=1.0)
    p.add_argument("--lambda-lpips", type=float, default=1.0)
    p.add_argument("--lambda-gan", type=float, default=0.1)
    p.add_argument(
        "--lambda-ffl",
        type=float,
        default=0.0,
        help="Focal Frequency Loss 权重（频域高频重建项）；0 关闭。不受 gan-warmup 门控。",
    )
    p.add_argument(
        "--ffl-alpha",
        type=float,
        default=1.0,
        help="FFL 焦点权重指数：越大越聚焦难拟合（高频）分量。",
    )
    p.add_argument(
        "--gan-warmup-steps",
        type=int,
        default=200,
        help="前 N 步只用 latent L1 + LPIPS，不加对抗（让 D 先稳）。",
    )
    p.add_argument("--lpips-net", choices=("vgg", "alex"), default="vgg")
    p.add_argument("--d-base-channels", type=int, default=64)
    p.add_argument("--d-n-layers", type=int, default=3)
    p.add_argument(
        "--d-update-steps",
        type=int,
        default=1,
        help="每 N 个 G step 才更新一次 D（>1 给 D 降速，缓解对抗失衡）。",
    )
    p.add_argument(
        "--r1-gamma",
        type=float,
        default=0.0,
        help="R1 梯度惩罚权重（对真实样本 logits 的梯度），>0 抑制 D 过强；0 关闭。",
    )
    p.add_argument(
        "--r1-interval",
        type=int,
        default=16,
        help="R1 lazy 正则间隔：每 N 次 D 更新算一次 R1（权重按间隔放大补偿）。",
    )
    p.add_argument("--custom-sar-vae", default=None)
    p.add_argument("--use-swanlab", action="store_true")
    p.add_argument("--swanlab-project", type=str, default="sar2opt_onestep")
    p.add_argument("--swanlab-experiment", type=str, default="b2_gan")
    p.add_argument(
        "--swanlab-mode",
        type=str,
        default="cloud",
        choices=("cloud", "local", "offline", "disabled"),
    )
    p.add_argument("--swanlab-logdir", type=str, default=None)
    p.add_argument("--no-val", action="store_true")
    p.add_argument("--val-data-root", default=str(DEFAULT_VAL_DATA_ROOT))
    p.add_argument("--val-categories", default="agri,barrenland,grassland,urban")
    p.add_argument("--val-per-category", type=int, default=10)
    p.add_argument("--val-batch-size", type=int, default=16)
    p.add_argument("--val-seed", type=int, default=42)
    p.add_argument("--val-every", type=int, default=2500)
    p.add_argument("--val-indices-file", default=None)
    p.add_argument("--local_rank", type=int, default=-1)
    args = p.parse_args()
    if "LOCAL_RANK" in os.environ:
        args.local_rank = int(os.environ["LOCAL_RANK"])
    # 供复用的 train 工具函数读取
    args.model_type = "ldm"
    args.lambda_pixel = 0.0
    return args


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def unwrap(model):
    return model.module if hasattr(model, "module") else model


def save_checkpoint(path, generator, discriminator, opt_g, opt_d, lr_scheduler,
                    global_step, epoch, args):
    path.parent.mkdir(parents=True, exist_ok=True)
    d = vars(args).copy()
    d["model_type"] = resolved_model_type_tag(args)
    torch.save(
        {
            "model": unwrap(generator).state_dict(),
            "discriminator": unwrap(discriminator).state_dict(),
            "optimizer_g": opt_g.state_dict(),
            "optimizer_d": opt_d.state_dict(),
            "lr_scheduler": lr_scheduler.state_dict(),
            "global_step": global_step,
            "epoch": epoch,
            "args": d,
        },
        path,
    )


def load_resume(path, generator, discriminator, opt_g, opt_d, lr_scheduler, device):
    ckpt = torch.load(path, map_location=device, weights_only=False)
    unwrap(generator).load_state_dict(
        {k.removeprefix("module."): v for k, v in ckpt["model"].items()}
    )
    unwrap(discriminator).load_state_dict(
        {k.removeprefix("module."): v for k, v in ckpt["discriminator"].items()}
    )
    opt_g.load_state_dict(ckpt["optimizer_g"])
    opt_d.load_state_dict(ckpt["optimizer_d"])
    lr_scheduler.load_state_dict(ckpt["lr_scheduler"])
    return int(ckpt.get("global_step", 0)), int(ckpt.get("epoch", 0))


def _init_swanlab(args, data_root, n_samples):
    import swanlab

    logdir = Path(args.swanlab_logdir) if args.swanlab_logdir else Path(args.checkpoint_dir) / "swanlog"
    logdir.mkdir(parents=True, exist_ok=True)
    config = {
        "model_type": resolved_model_type_tag(args),
        "input_mode": args.input_mode,
        "data_root": str(data_root),
        "n_samples": n_samples,
        "batch_size": args.batch_size,
        "learning_rate": args.learning_rate,
        "d_learning_rate": args.d_learning_rate,
        "num_train_steps": args.num_train_steps,
        "lambda_latent": args.lambda_latent,
        "lambda_lpips": args.lambda_lpips,
        "lambda_gan": args.lambda_gan,
        "lambda_ffl": args.lambda_ffl,
        "ffl_alpha": args.ffl_alpha,
        "gan_warmup_steps": args.gan_warmup_steps,
        "lpips_net": args.lpips_net,
        "init_from_model": args.init_from_model,
    }
    kw = {
        "project": args.swanlab_project,
        "config": config,
        "mode": args.swanlab_mode,
        "logdir": str(logdir),
    }
    if args.swanlab_experiment:
        kw["experiment_name"] = args.swanlab_experiment
    swanlab.init(**kw)
    return swanlab


def decode_trainable(vae, latents):
    """可反传的 VAE decode（vae 冻结但前向可微），输出 [-1,1] RGB。"""
    return vae.decode(latents / vae.config.scaling_factor).sample


def train_loop(args, device, data_root, dataset, dataloader, vae, swanlab_mod,
               val_ctx, sar_vae=None, rank=0, is_distributed=False, sampler=None):
    print(
        f"构建 LDM U-Net (生成器): {args.ldm_model_id!r}, input_mode={args.input_mode}, "
        f"timestep={args.timestep}",
        flush=True,
    ) if rank == 0 else None
    generator, prompt_embeds, uncond_prompt_embeds = build_ldm_unet(
        model_id=args.ldm_model_id, device=device, prompt=args.prompt
    )
    discriminator = ConditionalPatchGAN(
        image_channels=3, cond_channels=3,
        base_channels=args.d_base_channels, n_layers=args.d_n_layers,
    ).to(device)

    lpips_fn = lpips.LPIPS(net=args.lpips_net).to(device)
    lpips_fn.requires_grad_(False)
    lpips_fn.eval()

    ffl_fn = FocalFrequencyLoss(alpha=args.ffl_alpha).to(device) if args.lambda_ffl > 0 else None

    global_step, start_epoch = 0, 0
    if args.init_from_model and not args.resume:
        init_path = Path(args.init_from_model).resolve()
        missing, unexpected = load_model_weights(init_path, generator, device)
        if rank == 0:
            print(
                f"生成器初始化: {init_path} (missing={len(missing)}, unexpected={len(unexpected)})",
                flush=True,
            )
        # 若 checkpoint 含判别器（如从 B2 续训），一并加载以继承对抗进度，
        # 避免丢弃已训 D 后 G 初期又被随机弱 D 误导。
        _ck = torch.load(init_path, map_location="cpu", weights_only=False)
        if isinstance(_ck, dict) and _ck.get("discriminator") is not None:
            d_state = {
                k[len("module."):] if k.startswith("module.") else k: v
                for k, v in _ck["discriminator"].items()
            }
            d_missing, d_unexpected = discriminator.load_state_dict(d_state, strict=False)
            if rank == 0:
                print(
                    f"判别器也从 checkpoint 初始化 (missing={len(d_missing)}, "
                    f"unexpected={len(d_unexpected)})",
                    flush=True,
                )
        del _ck

    if is_distributed:
        generator = DDP(generator, device_ids=[rank], output_device=rank)
    # 判别器不包 DDP：便于 R1 二次求导、G step 复用，各卡本地更新对小 PatchGAN 影响可控。
    raw_g = unwrap(generator)
    raw_d = discriminator

    opt_g = AdamW(generator.parameters(), lr=args.learning_rate, betas=(0.9, 0.999))
    opt_d = Adam(discriminator.parameters(), lr=args.d_learning_rate, betas=(0.5, 0.999))
    lr_scheduler = get_cosine_schedule_with_warmup(
        optimizer=opt_g,
        num_warmup_steps=args.warmup_steps,
        num_training_steps=args.num_train_steps,
    )

    if args.resume:
        global_step, start_epoch = load_resume(
            Path(args.resume).resolve(), generator, discriminator,
            opt_g, opt_d, lr_scheduler, device,
        )
        if rank == 0:
            print(f"恢复 checkpoint: step={global_step}, epoch={start_epoch}", flush=True)

    vae.to(device).eval()
    if sar_vae is not None:
        sar_vae.to(device).eval()

    if rank == 0:
        print("开始训练 (onestep + LPIPS + GAN)...", flush=True)
        print(
            f"数据: {data_root}, 样本数: {len(dataset)} | "
            f"λ_lat={args.lambda_latent} λ_lpips={args.lambda_lpips} "
            f"λ_gan={args.lambda_gan} (warmup={args.gan_warmup_steps}) "
            f"λ_ffl={args.lambda_ffl} (alpha={args.ffl_alpha})",
            flush=True,
        )

    generator.train()
    discriminator.train()

    if val_ctx is not None and rank == 0 and should_run_val(global_step, args):
        run_onestep_val(args, device, raw_g, vae, val_ctx, global_step,
                        swanlab_mod, prompt_embeds, sar_vae)

    last_log_t = time.perf_counter()
    epoch = start_epoch
    # D 每 d_update_steps 步才更新一次，且打印步与 D 更新步存在奇偶错位；
    # 用持久化变量保留最近一次 D 更新的 loss/r1，避免日志恒显 0。
    loss_d_val = 0.0
    r1_val = 0.0
    while global_step < args.num_train_steps:
        if is_distributed and sampler is not None:
            sampler.set_epoch(epoch)
        for _, (sar_imgs, opt_imgs) in enumerate(dataloader):
            sar_imgs = sar_imgs.to(device)
            opt_imgs = opt_imgs.to(device)
            bsz = opt_imgs.shape[0]

            with torch.no_grad():
                z_y = encode_images(vae, opt_imgs)
                z_x = (
                    encode_sar_images(sar_vae, sar_imgs)
                    if sar_vae is not None else encode_images(vae, sar_imgs)
                )
            model_input = build_onestep_input(z_x, input_mode=args.input_mode)
            batch_prompt_embeds = select_training_prompt_embeds(
                prompt_embeds, uncond_prompt_embeds, bsz, args.cond_dropout_prob, device
            )

            z_pred = predict_optical_latent(
                generator, model_input, batch_prompt_embeds, timestep=args.timestep
            )
            fake_img = decode_trainable(vae, z_pred)

            gan_active = global_step >= args.gan_warmup_steps and args.lambda_gan > 0

            # D 降频：每 d_update_steps 个 G step 才更新一次 D，缓解 D 过强。
            do_d_update = gan_active and (global_step % max(1, args.d_update_steps) == 0)
            if do_d_update:
                apply_r1 = args.r1_gamma > 0 and (
                    (global_step // max(1, args.d_update_steps)) % max(1, args.r1_interval) == 0
                )
                real_in = opt_imgs.detach().requires_grad_(True) if apply_r1 else opt_imgs
                real_logits = discriminator(real_in, sar_imgs)
                fake_logits_d = discriminator(fake_img.detach(), sar_imgs)
                loss_d = hinge_d_loss(real_logits, fake_logits_d)
                if apply_r1:
                    grad_real = torch.autograd.grad(
                        outputs=real_logits.sum(), inputs=real_in, create_graph=True
                    )[0]
                    r1 = grad_real.pow(2).flatten(1).sum(1).mean()
                    # lazy 正则：按间隔放大权重补偿更新频次
                    loss_d = loss_d + 0.5 * args.r1_gamma * r1 * args.r1_interval
                    r1_val = float(r1.detach())
                opt_d.zero_grad(set_to_none=True)
                loss_d.backward()
                opt_d.step()
                loss_d_val = loss_d.item()

            loss_latent = F.l1_loss(z_pred, z_y)
            loss_lpips = lpips_fn(fake_img, opt_imgs).mean()
            loss_g_adv = z_pred.new_zeros(())
            if gan_active:
                # 用未包 DDP 的判别器算对抗项，避免 D 在 G step 触发二次梯度同步
                fake_logits_g = raw_d(fake_img, sar_imgs)
                loss_g_adv = hinge_g_loss(fake_logits_g)

            # FFL 是纯重建项，无对抗失衡风险，从第 0 步就参与（不受 gan-warmup 门控）。
            loss_ffl = z_pred.new_zeros(())
            if ffl_fn is not None:
                loss_ffl = ffl_fn(fake_img, opt_imgs)

            loss_g = (
                args.lambda_latent * loss_latent
                + args.lambda_lpips * loss_lpips
                + args.lambda_gan * loss_g_adv
                + args.lambda_ffl * loss_ffl
            )
            opt_g.zero_grad(set_to_none=True)
            loss_g.backward()
            opt_g.step()
            lr_scheduler.step()

            global_step += 1

            if rank == 0 and (global_step % args.log_every == 0 or global_step == 1):
                now = time.perf_counter()
                since = now - last_log_t
                last_log_t = now
                print(
                    f"{datetime.now():%Y-%m-%d %H:%M:%S} | step={global_step} "
                    f"g={loss_g.item():.4f} (lat={loss_latent.item():.4f}, "
                    f"lpips={loss_lpips.item():.4f}, adv={float(loss_g_adv):.4f}, "
                    f"ffl={float(loss_ffl):.4f}) "
                    f"d={loss_d_val:.4f} r1={r1_val:.4f} "
                    f"lr={lr_scheduler.get_last_lr()[0]:.6f} Δt={since:.1f}s",
                    flush=True,
                )
                if swanlab_mod is not None:
                    swanlab_mod.log(
                        {
                            "train/loss_g": loss_g.item(),
                            "train/loss_latent": loss_latent.item(),
                            "train/loss_lpips": loss_lpips.item(),
                            "train/loss_g_adv": float(loss_g_adv),
                            "train/loss_ffl": float(loss_ffl),
                            "train/loss_d": loss_d_val,
                            "train/r1": r1_val,
                            "train/lr": lr_scheduler.get_last_lr()[0],
                            "train/epoch": float(epoch),
                        },
                        step=global_step,
                    )

            if rank == 0 and global_step % args.save_every == 0:
                ckpt_path = Path(args.checkpoint_dir) / f"model_step_{global_step}.pth"
                save_checkpoint(ckpt_path, generator, discriminator, opt_g, opt_d,
                                lr_scheduler, global_step, epoch, args)
                print(f"已保存 {ckpt_path}", flush=True)
                if val_ctx is not None and should_run_val(global_step, args):
                    run_onestep_val(args, device, raw_g, vae, val_ctx, global_step,
                                    swanlab_mod, prompt_embeds, sar_vae)
                    generator.train()

            if global_step >= args.num_train_steps:
                break
        epoch += 1

    if rank == 0:
        final = Path(args.checkpoint_dir) / f"model_step_{global_step}_final.pth"
        save_checkpoint(final, generator, discriminator, opt_g, opt_d,
                        lr_scheduler, global_step, epoch, args)
        print(f"最终 checkpoint: {final}", flush=True)


def main():
    args = parse_args()
    if args.resume and args.init_from_model:
        raise ValueError("--resume 与 --init-from-model 不能同时使用")

    is_distributed = args.local_rank != -1
    if is_distributed:
        torch.cuda.set_device(args.local_rank)
        device = torch.device("cuda", args.local_rank)
        dist.init_process_group(backend="nccl")
        rank = dist.get_rank()
    else:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        rank = 0

    set_seed(args.seed + rank)

    data_root = Path(args.data_root).resolve()
    if not data_root.is_dir():
        raise NotADirectoryError(data_root)
    Path(args.checkpoint_dir).mkdir(parents=True, exist_ok=True)

    dataset = SAROpticalDataset(
        root_dir=str(data_root), image_size=args.image_size,
        sar_representation="repeat3", normalize_mode="vae",
    )
    if len(dataset) == 0:
        raise RuntimeError("无训练样本")

    sampler = DistributedSampler(dataset) if is_distributed else None
    dataloader = DataLoader(
        dataset, batch_size=args.batch_size, shuffle=(sampler is None),
        sampler=sampler, num_workers=args.num_workers,
        pin_memory=torch.cuda.is_available(), drop_last=True,
    )

    if rank == 0:
        print("加载 VAE...", args.vae_model_id, flush=True)
    vae = load_frozen_vae(args.vae_model_id, device=device)
    sar_vae = load_custom_sar_vae(args.custom_sar_vae, device=device) if args.custom_sar_vae else None

    swanlab_mod = _init_swanlab(args, data_root, len(dataset)) if (args.use_swanlab and rank == 0) else None
    val_ctx = setup_val_context(args) if rank == 0 else None

    try:
        train_loop(args, device, data_root, dataset, dataloader, vae, swanlab_mod,
                   val_ctx, sar_vae=sar_vae, rank=rank,
                   is_distributed=is_distributed, sampler=sampler)
    finally:
        if swanlab_mod is not None and rank == 0:
            swanlab_mod.finish()
        if is_distributed:
            dist.destroy_process_group()


if __name__ == "__main__":
    main()
